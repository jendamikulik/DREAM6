#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""DREAM6 LOG BOUND LAB v1 -- experimental solver for the reserve problem.

    Q * B_h = sum_x P(x) delta_x * B_hx, B_h >= 0, sum B_h = 1.

This is a research LP solver, not a SAT solver or an asymptotic proof.
Default: unrestricted ordered histories, horizons 1..5, mean and tail objectives.
Run with --help; see README_CS.md for the mathematical contract and experiments.

Requires Python >= 3.10, NumPy, SciPy. No input attachments are needed at runtime.
Floating-point solutions are labelled numerical. Dyadic duals are repaired and
checked in exact integer arithmetic by the separate standard-library verifier.
An optional rational primal is published only if EVERY equation checks exactly.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
from fractions import Fraction as F
import csv
import gzip
import hashlib
import json
import math
from pathlib import Path
import platform
import sys
import time

VERSION = "DREAM6_LOG_BOUND_LAB_v1.1"
PN = (8, 16, 16, 16, 8)
QN = (7, 20, 10, 20, 7)
P = tuple(v / 64 for v in PN)
Q = tuple(v / 64 for v in QN)
KNOWN_B = {0: F(0), 1: F(3, 20), 2: F(43, 180),
           3: F(2801758, 9450045),
           4: F(144958044813242692, 420381282815550045)}
KAPPA = math.log(594184 / 543559) / (math.log(16) * math.log(524288 / 74273))
SCOPE_WARNING = ("Finite computations do not prove or disprove B_n=O(log n). "
                 "Tail-optimal and mean-optimal trees need not be the same.")


def log(message):
    print(time.strftime("[%H:%M:%S] ") + message, flush=True)


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    # Checkpoints are atomic and live in the requested results directory.
    tmp = path.with_name(path.name + ".tmp")
    with tmp.open("w", encoding="utf-8", newline="\n") as fh:
        json.dump(value, fh, ensure_ascii=False, indent=2, allow_nan=False)
        fh.write("\n")
    tmp.replace(path)


def write_gzip_json(path, value):
    tmp = Path(str(path) + ".tmp")
    with gzip.open(tmp, "wt", encoding="utf-8") as fh:
        json.dump(value, fh, separators=(",", ":"), allow_nan=False)
    tmp.replace(path)


def write_csv(path, rows):
    rows = list(rows)
    if not rows:
        return
    fields = list(dict.fromkeys(k for row in rows for k in row))
    with Path(path).open("w", encoding="utf-8-sig", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def dependencies():
    try:
        import numpy as np
        import scipy
        from scipy.optimize import linprog
        from scipy.sparse import coo_matrix
    except ImportError as exc:
        raise SystemExit("Missing dependency. Run: python -m pip install numpy scipy\n"
                         + str(exc))
    return np, scipy, linprog, coo_matrix


@dataclass
class Node:
    depth: int
    total: int
    suffix: tuple
    representative: str
    cap: int
    offset: int = 0
    conv_row: int = -1
    children: tuple = ()
    probability: float = 0.0
    tilted_probability: float = 0.0


def build_graph(n, root_cap, memory, max_nodes=500000):
    """All histories, or an explicitly RESTRICTED (time,sum,last-k) DAG.

    No averaging of unequal continuation laws is used. In the DAG the laws are
    required to be equal, so every feasible DAG unfolds to a valid full tree.
    """
    nodes = [Node(0, 0, (), "", root_cap, probability=1.0,
                  tilted_probability=1.0)]
    layers = [[0]]
    z = 1 / 16
    pz = sum(P[x] * z**x for x in range(5))
    for t in range(n):
        lookup = {}
        layer = []
        for index in layers[-1]:
            parent = nodes[index]
            children = []
            for x in range(5):
                suffix = parent.suffix + (x,)
                if memory is not None:
                    suffix = suffix[-memory:] if memory else ()
                total = parent.total + x
                key = (total, suffix)
                if key not in lookup:
                    if len(nodes) >= max_nodes:
                        raise ResourceLimit(f"graph exceeds --max-nodes={max_nodes}")
                    child_index = len(nodes)
                    lookup[key] = child_index
                    layer.append(child_index)
                    nodes.append(Node(t + 1, total, suffix,
                                      parent.representative + str(x),
                                      root_cap + 4 * (t + 1) - total))
                child_index = lookup[key]
                children.append(child_index)
                child = nodes[child_index]
                child.probability += parent.probability * P[x]
                child.tilted_probability += parent.tilted_probability * P[x] * z**x / pz
            parent.children = tuple(children)
        layers.append(layer)
    offset = 0
    row = len(nodes)
    for node in nodes:
        node.offset = offset
        offset += node.cap + 1
        if node.children:
            node.conv_row = row
            row += node.cap + 5
    return nodes, layers, offset, row


class ResourceLimit(RuntimeError):
    pass


def parse_contact(text):
    try:
        history, value = text.split("=", 1)
        history = history.replace(",", "").strip()
        if not history or any(x not in "01234" for x in history):
            raise ValueError()
        value = F(value)
        if value < 0:
            raise ValueError()
        return {"history": history, "mean": str(value)}
    except (ValueError, ZeroDivisionError):
        raise argparse.ArgumentTypeError("contact must be e.g. 4=43/180 or 4,4=3/20")


def resolve_history(nodes, history):
    index = 0
    for x in history:
        if not nodes[index].children:
            raise ValueError("contact is deeper than the horizon")
        index = nodes[index].children[int(x)]
    return index


def is_unrestricted(config):
    return (config["root_cap"] == 4 * config["n"]
            and (config["memory"] is None or config["memory"] >= config["n"])
            and not config["contacts"] and config["mean_budget"] is None
            and config["tail_cap"] is None and config["profile_lambda"] is None)


def scope(config):
    if is_unrestricted(config):
        return "unrestricted_B_n" if config["objective"] == "mean" else "unrestricted_A_n"
    return "restricted_finite_problem_only"


@dataclass
class Model:
    config: dict
    nodes: list
    layers: list
    mass_vars: int
    c: object
    aeq: object
    beq: object
    aub: object
    bub: object
    extra_eq: list
    extra_ub: list
    estimate: dict


def build_model(config, limits):
    np, _, _, coo_matrix = dependencies()
    n, cap = config["n"], config["root_cap"]
    explicit_depth = n - 1 if config.get("leaf_reduction", False) else n
    nodes, layers, mass_vars, base_rows = build_graph(
        explicit_depth, cap, config["memory"], limits["max_nodes"])
    nvar = mass_vars + (config["objective"] == "tail")
    extra_eq = []
    for contact in config["contacts"]:
        idx = resolve_history(nodes, contact["history"])
        node = nodes[idx]
        extra_eq.append(([(node.offset + j, j) for j in range(1, node.cap + 1)],
                         F(contact["mean"])))
    lam = config["profile_lambda"]
    if lam is not None:
        lam = F(lam)
        for j in range(cap + 1):
            value = lam / ((j + lam) * (j + lam + 1)) if j < cap else lam / (cap + lam)
            extra_eq.append(([(j, 1)], value))
    extra_ub = []
    if config.get("leaf_reduction", False):
        # A final output X~P with X <= S~Q*B exists iff F_S(s)<=F_P(s),
        # s=0,1,2,3. Quantile coupling reconstructs all five terminal laws.
        # This is exact elimination, not a relaxation or a support approximation.
        for idx in layers[-1]:
            node = nodes[idx]
            for s in range(4):
                terms = [(node.offset + j, sum(QN[:s - j + 1]))
                         for j in range(min(s, node.cap) + 1)]
                extra_ub.append((terms, F(sum(PN[:s + 1]))))
    if config["objective"] == "tail" or config["tail_cap"] is not None:
        for j in range(1, cap + 1):
            terms = [(k, j) for k in range(j, cap + 1)]
            if config["objective"] == "tail":
                terms.append((mass_vars, -1))
                rhs = F(0)
            else:
                rhs = F(config["tail_cap"])
            extra_ub.append((terms, rhs))
    if config["objective"] == "tail" and config["tail_cap"] is not None:
        extra_ub.append(([(mass_vars, 1)], F(config["tail_cap"])))
    if config["mean_budget"] is not None:
        extra_ub.append(([(j, j) for j in range(1, cap + 1)], F(config["mean_budget"])))
    nnz = mass_vars + sum(5 * (node.cap + 1) + sum(nodes[c].cap + 1 for c in node.children)
                         for node in nodes if node.children)
    nnz += sum(len(terms) for terms, _ in extra_eq)
    ub_nnz = sum(len(terms) for terms, _ in extra_ub)
    estimate = {"nodes": len(nodes), "variables": nvar,
                "equality_rows": base_rows + len(extra_eq),
                "inequality_rows": len(extra_ub), "nonzeros": nnz + ub_nnz,
                "matrix_storage_estimate_MiB": round((nnz + ub_nnz) * 36 / 2**20, 1),
                "note": "Storage estimate excludes optimizer factorization; peak RAM can be much larger."}
    if nvar > limits["max_vars"] or nnz + ub_nnz > limits["max_nnz"]:
        raise ResourceLimit(f"model size {estimate}; increase --max-vars/--max-nnz explicitly")
    if limits.get("dry_run"):
        return estimate
    if limits.get("certificate_only"):
        # A larger support may be needed to CHECK a dual, without solving or
        # allocating the corresponding large sparse LP.
        c = np.zeros(nvar)
        if config["objective"] == "tail":
            c[mass_vars] = 1
        else:
            c[:cap + 1] = np.arange(cap + 1)
        beq = np.zeros(base_rows + len(extra_eq))
        beq[:len(nodes)] = 1
        for k, (_, rhs) in enumerate(extra_eq):
            beq[base_rows + k] = float(rhs)
        return Model(config, nodes, layers, mass_vars, c, None, beq, None, None,
                     extra_eq, extra_ub, estimate)
    rr = np.empty(nnz, dtype=np.int64)
    cc = np.empty(nnz, dtype=np.int64)
    dd = np.empty(nnz, dtype=float)
    cursor = 0

    def block(rows, columns, value):
        nonlocal cursor
        length = len(columns)
        rr[cursor:cursor + length] = rows
        cc[cursor:cursor + length] = columns
        dd[cursor:cursor + length] = value
        cursor += length

    for i, node in enumerate(nodes):
        j = np.arange(node.cap + 1, dtype=np.int64)
        block(i, node.offset + j, 1)
        if node.children:
            for y in range(5):
                block(node.conv_row + j + y, node.offset + j, QN[y])
            for x, child_idx in enumerate(node.children):
                child = nodes[child_idx]
                k = np.arange(child.cap + 1, dtype=np.int64)
                block(node.conv_row + k + x, child.offset + k, -PN[x])
    beq = np.zeros(base_rows + len(extra_eq))
    beq[:len(nodes)] = 1
    for k, (terms, rhs) in enumerate(extra_eq):
        for col, value in terms:
            block(base_rows + k, [col], value)
        beq[base_rows + k] = float(rhs)
    assert cursor == nnz
    aeq = coo_matrix((dd, (rr, cc)), shape=(len(beq), nvar)).tocsr()
    rows, columns, values = [], [], []
    for row, (terms, _) in enumerate(extra_ub):
        for col, value in terms:
            rows.append(row)
            columns.append(col)
            values.append(value)
    aub = (coo_matrix((values, (rows, columns)), shape=(len(extra_ub), nvar)).tocsr()
           if extra_ub else None)
    bub = np.array([float(rhs) for _, rhs in extra_ub]) if extra_ub else None
    c = np.zeros(nvar)
    if config["objective"] == "mean":
        c[:cap + 1] = np.arange(cap + 1)
    else:
        c[mass_vars] = 1
    return Model(config, nodes, layers, mass_vars, c, aeq, beq, aub, bub,
                 extra_eq, extra_ub, estimate)


def exact_reduced_costs(model, yi, vi, denominator):
    """Compute D*c - A^T*(D*y) - G^T*(D*v) using Python integers."""
    rc = [int(c) * denominator for c in model.c]
    for i, node in enumerate(model.nodes):
        for j in range(node.cap + 1):
            rc[node.offset + j] -= yi[i]
        if node.children:
            for j in range(node.cap + 1):
                rc[node.offset + j] -= sum(QN[y] * yi[node.conv_row + j + y] for y in range(5))
            for x, child_idx in enumerate(node.children):
                child = model.nodes[child_idx]
                for j in range(child.cap + 1):
                    rc[child.offset + j] += PN[x] * yi[node.conv_row + j + x]
    first = len(model.beq) - len(model.extra_eq)
    for i, (terms, _) in enumerate(model.extra_eq):
        for col, value in terms:
            rc[col] -= value * yi[first + i]
    for i, (terms, _) in enumerate(model.extra_ub):
        for col, value in terms:
            rc[col] -= value * vi[i]
    return rc


def make_dual_certificate(model, result, path, bits=40, integer_dual=None):
    """Round duals, then repair EVERY block using its normalization multiplier.

    Every mass block sums to one. Subtracting its negative minimum reduced cost
    from A^T y is achieved by lowering that block's normalization multiplier.
    This gives a valid exact dual even when the numerical dual has tiny errors.
    """
    scale = 1 << bits
    if integer_dual is None:
        yi = [round(float(v) * scale) for v in result.eqlin.marginals]
        vi = [min(0, round(float(v) * scale)) for v in result.ineqlin.marginals]
    else:
        yi, vi = map(list, integer_dual)
    if model.config["objective"] == "tail":
        # Tail rows have coefficient -1 at the nonnegative auxiliary variable A.
        # Preserve dual sign and enforce its reduced cost, including an A cap row.
        rc = exact_reduced_costs(model, yi, vi, scale)
        if rc[-1] < 0:
            rows = [i for i, (terms, _) in enumerate(model.extra_ub)
                    if (model.mass_vars, -1) in terms]
            total = -sum(vi[i] for i in rows)
            allowed = total + rc[-1]
            if allowed < 0:
                raise ArithmeticError("cannot repair auxiliary dual column")
            for i in rows:
                vi[i] = -((-vi[i] * allowed) // total)
    rc = exact_reduced_costs(model, yi, vi, scale)
    correction = 0
    for i, node in enumerate(model.nodes):
        minimum = min(rc[node.offset:node.offset + node.cap + 1])
        if minimum < 0:
            yi[i] += minimum
            correction -= minimum
    repaired = exact_reduced_costs(model, yi, vi, scale)
    if min(repaired) < 0 or any(v > 0 for v in vi):
        raise ArithmeticError("exact dual repair failed")
    value = F(sum(yi[:len(model.nodes)]), scale)
    first = len(yi) - len(model.extra_eq)
    value += sum((rhs * F(yi[first + i], scale)
                  for i, (_, rhs) in enumerate(model.extra_eq)), F(0))
    value += sum((rhs * F(vi[i], scale)
                  for i, (_, rhs) in enumerate(model.extra_ub)), F(0))
    cert = {"format": "reserve-dyadic-dual-v1", "version": VERSION,
            "config": model.config, "scope": scope(model.config),
            "denominator": str(scale), "y_length": len(yi), "v_length": len(vi),
            "y": [[i, str(v)] for i, v in enumerate(yi) if v],
            "v": [[i, str(v)] for i, v in enumerate(vi) if v],
            "objective_lower_bound": str(value),
            "normalization_repair_loss": str(F(correction, scale))}
    write_gzip_json(path, cert)
    return {"status": "EXACT_DUAL_LOWER_BOUND", "scope": scope(model.config),
            "rational": str(value), "value": float(value),
            "repair_loss": float(F(correction, scale)), "file": Path(path).name}


def lift_dual_to_full_support(model, old_path, new_path, max_vars):
    """Discover on small root support; verify the lower bound on full 0..4n.

    Old multipliers are placed at the same history and coefficient s. Both zero
    and constant extensions are tried; all columns are checked and repaired.
    A weak lifted bound is reported honestly; support optimality is never assumed.
    """
    cfg = model.config
    if (cfg["root_cap"] >= 4 * cfg["n"] or cfg["contacts"]
            or cfg["tail_cap"] is not None or cfg["mean_budget"] is not None
            or cfg["profile_lambda"] is not None
            or (cfg["memory"] is not None and cfg["memory"] < cfg["n"] )):
        return {"status": "NOT_APPLICABLE", "reason": "requires only a root-support restriction and full histories"}
    new_config = {**cfg, "root_cap": 4 * cfg["n"]}
    try:
        expanded = build_model(new_config, {"max_nodes": 500000,
                                            "max_vars": max_vars,
                                            "max_nnz": 100000000,
                                            "certificate_only": True})
    except ResourceLimit as exc:
        return {"status": "RESOURCE_LIMIT_NOT_CERTIFIED", "message": str(exc)}
    with gzip.open(old_path, "rt", encoding="utf-8") as fh:
        cert = json.load(fh)
    old_y = [0] * cert["y_length"]
    old_v = [0] * cert["v_length"]
    for i, value in cert["y"]:
        old_y[i] = int(value)
    for i, value in cert["v"]:
        old_v[i] = int(value)
    yi, vi = [0] * len(expanded.beq), [0] * len(expanded.extra_ub)
    yi[:len(model.nodes)] = old_y[:len(model.nodes)]
    for old, new in zip(model.nodes, expanded.nodes):
        if old.children:
            yi[new.conv_row:new.conv_row + old.cap + 5] = old_y[old.conv_row:old.conv_row + old.cap + 5]
    # Final CDF rows occur first; then root tail rows j=1..cap, if requested.
    leaf_rows = 4 * len(model.layers[-1]) if cfg.get("leaf_reduction", False) else 0
    vi[:leaf_rows] = old_v[:leaf_rows]
    if cfg["objective"] == "tail":
        vi[leaf_rows:leaf_rows + cfg["root_cap"]] = old_v[leaf_rows:]
    answer = make_dual_certificate(expanded, None, new_path, integer_dual=(yi, vi))
    with gzip.open(new_path, "rt", encoding="utf-8") as fh:
        best_file = json.load(fh)
    variants = {"zero_padding": answer["value"]}
    yi_constant = list(yi)
    for old, new in zip(model.nodes, expanded.nodes):
        if old.children:
            tail_value = old_y[old.conv_row + old.cap + 4]
            for s in range(old.cap + 5, new.cap + 5):
                yi_constant[new.conv_row + s] = tail_value
    candidate = make_dual_certificate(expanded, None, new_path, integer_dual=(yi_constant, vi))
    variants["constant_padding"] = candidate["value"]
    if F(candidate["rational"]) >= F(answer["rational"]):
        answer = candidate
        selected = "constant_padding"
    else:
        write_gzip_json(new_path, best_file)
        selected = "zero_padding"
    if answer["value"] < 0:
        answer = make_dual_certificate(expanded, None, new_path,
                                       integer_dual=([0] * len(yi), [0] * len(vi)))
        selected = "trivial_nonnegative_bound"
    answer["extension_trials"] = variants
    answer["selected_extension"] = selected
    answer["discovered_with_root_cap"] = cfg["root_cap"]
    answer["verified_with_root_cap"] = 4 * cfg["n"]
    return answer


def check_primal_fractions(model, values):
    if len(values) != len(model.c) or any(v < 0 for v in values):
        return False
    for node in model.nodes:
        law = values[node.offset:node.offset + node.cap + 1]
        if sum(law) != 1:
            return False
        if node.children:
            conv = [F(0)] * (node.cap + 5)
            for j, mass in enumerate(law):
                if mass:
                    for y in range(5):
                        conv[j + y] += QN[y] * mass
            for x, idx in enumerate(node.children):
                child = model.nodes[idx]
                for j in range(child.cap + 1):
                    conv[j + x] -= PN[x] * values[child.offset + j]
            if any(conv):
                return False
    for terms, rhs in model.extra_eq:
        if sum((a * values[i] for i, a in terms), F(0)) != rhs:
            return False
    for terms, rhs in model.extra_ub:
        if sum((a * values[i] for i, a in terms), F(0)) > rhs:
            return False
    return True


def try_primal_certificate(model, result, path, max_vars):
    if len(result.x) > max_vars:
        return {"status": "NOT_ATTEMPTED_SIZE", "max_vars": max_vars}
    # Failure of reconstruction says nothing about mathematical feasibility.
    for cap in (100, 10000, 1000000, 10000000, 1000000000):
        values = [F(float(v)).limit_denominator(cap) for v in result.x]
        if check_primal_fractions(model, values):
            value = sum((int(c) * v for c, v in zip(model.c, values)), F(0))
            cert = {"format": "reserve-rational-primal-v1", "version": VERSION,
                    "config": model.config, "length": len(values),
                    "u": [[i, str(v)] for i, v in enumerate(values) if v],
                    "objective_upper_bound": str(value)}
            write_gzip_json(path, cert)
            return {"status": "EXACT_FEASIBLE_UPPER_BOUND", "rational": str(value),
                    "value": float(value), "file": Path(path).name}
    return {"status": "NO_EXACT_PRIMAL_RECONSTRUCTED"}


def numerical_audit(model, vector, result, tolerance):
    np, _, _, _ = dependencies()
    eq = float(np.max(np.abs(model.aeq @ vector - model.beq)))
    ub = (float(max(0, np.max(model.aub @ vector - model.bub)))
          if model.aub is not None else 0.0)
    negative = float(max(0, -np.min(vector)))
    mean_error = 0.0
    for node in model.nodes:
        if not node.children:
            continue
        mean = float(np.arange(node.cap + 1) @ vector[node.offset:node.offset + node.cap + 1])
        childmean = 0.0
        for x, ci in enumerate(node.children):
            child = model.nodes[ci]
            childmean += P[x] * float(np.arange(child.cap + 1) @
                                     vector[child.offset:child.offset + child.cap + 1])
        mean_error = max(mean_error, abs(mean - childmean))
    dual_error = None
    if result.success:
        rc = model.c - model.aeq.T @ result.eqlin.marginals
        if model.aub is not None:
            rc -= model.aub.T @ result.ineqlin.marginals
        dual_error = float(max(0, -np.min(rc)))
    return {"equation_max_abs_residual": eq, "inequality_max_violation": ub,
            "negative_mass_max": negative, "fan_mean_max_abs_residual": mean_error,
            "dual_max_violation": dual_error, "audit_tolerance": tolerance,
            "numerically_feasible": max(eq, ub, negative) <= tolerance,
            "exact_primal": False}


def law_summary(law):
    np, _, _, _ = dependencies()
    j = np.arange(len(law))
    tail = np.cumsum(law[::-1])[::-1]
    return {"mean": float(j @ law),
            "tail_A": float(np.max(j[1:] * tail[1:])) if len(law) > 1 else 0.0,
            "positive_atoms_above_1e-10": int(np.sum(law > 1e-10)),
            "mass_at_cap": float(law[-1])}


def analytic_lower(n):
    # The finite-horizon formula from Appendix A, evaluated numerically.
    # This output is never called an exact certificate.
    best = 0.0
    for z in (1 / 64, 1 / 32, 1 / 16, 1 / 8, 1 / 4, 1 / 2):
        p = sum(P[x] * z**x for x in range(5))
        q = sum(Q[x] * z**x for x in range(5))
        c = math.log(p / q) / -math.log(z)
        for t in range(1, min(n, max(32, int(4 * math.log(n + 1) / -math.log(p)) + 1)) + 1):
            pt = p**t
            value = t * c * -math.expm1((n // t) * math.log1p(-pt))
            best = max(best, value)
    return best


def baselines(n):
    # The n=5 bound is quoted from the supplied PDF; no n=5 witness was in its ZIP.
    upper = {k: float(v) for k, v in KNOWN_B.items()}
    upper[5] = 0.3783157
    candidates = [((n // k) * v + upper[n % k], f"concatenation_of_supplied_depth_{k}")
                  for k, v in upper.items() if k > 0]
    candidates.append((4 * (4096 + 2465 * n)**0.25, "critical_reserve_note_Appendix_B"))
    u, source = min(candidates)
    return {"analytic_lower_numeric": analytic_lower(n),
            "analytic_upper_numeric": u, "upper_source": source,
            "kappa0": KAPPA, "source_bounds_reverified_here": False}


def diagnostics(model, vector, folder, reference_values):
    np, _, _, _ = dependencies()
    root = vector[:model.config["root_cap"] + 1]
    tail = np.cumsum(root[::-1])[::-1]
    write_csv(folder / "root_tail.csv", [
        {"j": j, "probability": float(root[j]), "survival_ge_j": float(tail[j]),
         "j_times_survival": float(j * tail[j]),
         "cumulative_mean_to_j": float(np.dot(np.arange(j + 1), root[:j + 1]))}
        for j in range(len(root))])
    means = []
    node_rows = []
    for i, node in enumerate(model.nodes):
        law = vector[node.offset:node.offset + node.cap + 1]
        stats = law_summary(law)
        means.append(stats["mean"])
        remaining = model.config["n"] - node.depth
        ref = reference_values.get(remaining)
        node_rows.append({"node": i, "depth": node.depth,
                          "representative_history": "h:" + node.representative,
                          "sum_x": node.total, "suffix": "h:" + "".join(map(str, node.suffix)),
                          "history_or_state_probability": node.probability,
                          "tilted_probability_z_1_16": node.tilted_probability,
                          **stats, "remaining": remaining,
                          "reference_B_numeric": ref,
                          "mean_minus_reference": stats["mean"] - ref if ref is not None else None,
                          "weighted_mean": node.probability * stats["mean"]})
    write_csv(folder / "nodes.csv", node_rows)
    fan_rows = []
    for i, node in enumerate(model.nodes):
        if not node.children:
            continue
        r = model.config["n"] - node.depth
        ref = reference_values.get(r - 1)
        for x, ci in enumerate(node.children):
            fan_rows.append({"parent": i, "child": ci, "x": x,
                             "parent_mean": means[i], "child_mean": means[ci],
                             "P_x_times_child_mean": P[x] * means[ci],
                             "defect_using_reference": means[ci] - ref if ref is not None else None,
                             "weighted_defect_using_reference": P[x] * (means[ci] - ref) if ref is not None else None})
    write_csv(folder / "fans.csv", fan_rows)
    layer_rows = []
    pz = sum(P[x] * (1 / 16)**x for x in range(5))
    qz = sum(Q[x] * (1 / 16)**x for x in range(5))
    root_pgf = sum(float(v) * (1 / 16)**j for j, v in enumerate(root))
    for t, layer in enumerate(model.layers):
        m = sum(model.nodes[i].probability * means[i] for i in layer)
        tm = sum(model.nodes[i].tilted_probability * means[i] for i in layer)
        actual_pgf = 0.0
        for i in layer:
            node = model.nodes[i]
            law = vector[node.offset:node.offset + node.cap + 1]
            actual_pgf += node.tilted_probability * sum(float(v) * (1 / 16)**j for j, v in enumerate(law))
        expected_pgf = (qz / pz)**t * root_pgf
        ranked = sorted(layer, key=lambda i: means[i], reverse=True)
        rare_costs = {}
        for mass in (0.001, 0.01, 0.1):
            remaining_mass, contribution = mass, 0.0
            for i in ranked:
                take = min(remaining_mass, model.nodes[i].probability)
                contribution += take * means[i]
                remaining_mass -= take
                if remaining_mass <= 0:
                    break
            rare_costs[f"mean_share_in_highest_mean_{mass:g}_probability"] = contribution / m if m > 0 else 0.0
        layer_rows.append({"depth": t, "states": len(layer), "ordinary_mean": m,
                           "tilted_mean_z_1_16": tm, "max_conditional_mean": max(means[i] for i in layer),
                           "tilted_PGF": actual_pgf, "PGF_identity_rhs": expected_pgf,
                           "PGF_identity_abs_residual": abs(actual_pgf - expected_pgf), **rare_costs})
    write_csv(folder / "layers.csv", layer_rows)
    # Compare histories with the same count vector: laws here may differ.
    groups = {}
    for i, node in enumerate(model.nodes):
        if model.config["memory"] is not None and node.depth > model.config["memory"]:
            continue  # a representative of a merged state does not describe all of it
        key = tuple(node.representative.count(str(x)) for x in range(5))
        groups.setdefault(key, []).append(i)
    order_rows = []
    for key, indices in groups.items():
        if len(indices) < 2:
            continue
        lo, hi = min(indices, key=lambda i: means[i]), max(indices, key=lambda i: means[i])
        a, b = model.nodes[lo], model.nodes[hi]
        la = vector[a.offset:a.offset + a.cap + 1]
        lb = vector[b.offset:b.offset + b.cap + 1]
        order_rows.append({"counts": str(key), "depth": a.depth,
                           "low_history": "h:" + a.representative, "high_history": "h:" + b.representative,
                           "mean_spread": means[hi] - means[lo], "total_variation_of_selected_pair": float(np.sum(np.abs(la - lb)) / 2),
                           "interpretation": "one optimizer; positive spread is not forced on the optimal face"})
    order_rows.sort(key=lambda r: r["mean_spread"], reverse=True)
    write_csv(folder / "order_effects.csv", order_rows)
    # Exact-current parametrization, evaluated on the numerical solution.
    current_rows, coefficient_rows = [], []
    for i in model.layers[0] + (model.layers[1] if len(model.layers) >= 2 else []):
        node = model.nodes[i]
        if not node.children:
            continue
        size = node.cap + 6
        parent = np.zeros(size)
        parent[:node.cap + 1] = vector[node.offset:node.offset + node.cap + 1]
        d = np.convolve(parent, [1, -3, 3, -1])[:size] / 64
        a = []
        for x, ci in enumerate(node.children):
            child = model.nodes[ci]
            law = np.zeros(size)
            law[:child.cap + 1] = vector[child.offset:child.offset + child.cap + 1]
            ax = P[x] * (law - parent)
            if x == 0:
                ax += d
            elif x == 1:
                ax -= d
            a.append(ax)
        currents = [None] * 4
        currents[3] = -a[4]
        for k in (2, 1, 0):
            currents[k] = np.r_[0, currents[k + 1][:-1]] - a[k + 1]
        closure = float(np.max(np.abs(a[0] - np.r_[0, currents[0][:-1]])))
        for k, current in enumerate(currents):
            current_rows.append({"parent": i, "current": k, "total_mass": float(current.sum()),
                                 "L1": float(np.abs(current).sum()), "first_moment": float(np.arange(size) @ current),
                                 "closure_max_abs_residual": closure})
            coefficient_rows.extend({"parent": i, "current": k, "j": j, "coefficient": float(v)}
                                    for j, v in enumerate(current))
    write_csv(folder / "currents.csv", current_rows)
    write_csv(folder / "current_coefficients.csv", coefficient_rows)
    return {**law_summary(root), "explicit_law_depth": len(model.layers) - 1,
            "last_step_uses_exact_quantile_elimination": model.config.get("leaf_reduction", False),
            "max_layer_mean_drift": max(abs(r["ordinary_mean"] - means[0]) for r in layer_rows),
            "max_PGF_identity_residual": max(r["PGF_identity_abs_residual"] for r in layer_rows)}


def run_one(config, folder, args, reference_values):
    np, scipy, linprog, _ = dependencies()
    folder.mkdir(parents=True, exist_ok=True)
    old = folder / "result.json"
    if args.resume and old.exists():
        cached = json.loads(old.read_text(encoding="utf-8"))
        if (cached.get("version") == VERSION and cached.get("config") == config
                and cached.get("status") == "NUMERIC_OPTIMUM"
                and (not args.lift_dual or "lifted_dual_certificate" in cached)):
            log(f"resume {folder.name}: completed result reused")
            return cached
    # Do not leave a stale witness next to a failed rerun.
    for name in ("dual_certificate.json.gz", "primal_certificate.json.gz", "witness.npz",
                 "unrestricted_dual_certificate.json.gz",
                 "root_tail.csv", "nodes.csv", "fans.csv", "layers.csv", "order_effects.csv",
                 "currents.csv", "current_coefficients.csv"):
        (folder / name).unlink(missing_ok=True)
    started = time.monotonic()
    # Merged history graphs have many dependent equalities. In the tested HiGHS
    # version presolve can fail or spend far longer than its solve time limit on
    # these DAGs. Solve their original sparse system directly.
    use_presolve = not args.no_presolve and (config["memory"] is None or config["memory"] >= config["n"])
    summary = {"version": VERSION, "config": config, "scope": scope(config),
               "status": "BUILDING", "warning": SCOPE_WARNING,
               "environment": {"python": platform.python_version(), "numpy": np.__version__,
                               "scipy": scipy.__version__, "platform": platform.platform()},
               "solver_options": {"method": args.method, "time_limit": args.time_limit,
                                  "presolve": use_presolve,
                                  "solver_tolerance": args.solver_tolerance,
                                  "audit_tolerance": args.audit_tolerance},
               "baselines": baselines(config["n"])}
    write_json(old, summary)
    try:
        model = build_model(config, vars(args))
    except ResourceLimit as exc:
        summary.update(status="RESOURCE_LIMIT_NOT_SOLVED", message=str(exc))
        write_json(old, summary)
        return summary
    summary["model"] = model.estimate
    summary["build_seconds"] = time.monotonic() - started
    summary["status"] = "SOLVING"
    write_json(old, summary)
    log(f"{folder.name}: {len(model.c):,} variables, {len(model.beq):,} equalities; solving")
    solve_start = time.monotonic()
    result = linprog(model.c, A_eq=model.aeq, b_eq=model.beq, A_ub=model.aub,
                     b_ub=model.bub, bounds=(0, None), method=args.method,
                     options={"time_limit": args.time_limit, "presolve": use_presolve,
                              "primal_feasibility_tolerance": args.solver_tolerance,
                              "dual_feasibility_tolerance": args.solver_tolerance,
                              "ipm_optimality_tolerance": args.solver_tolerance,
                              "disp": args.solver_log})
    summary.update(solve_seconds=time.monotonic() - solve_start,
                   optimizer_status=int(result.status), optimizer_message=result.message,
                   iterations=int(result.nit) if result.nit is not None else None)
    status_names = {0: "NUMERIC_OPTIMUM", 1: "LIMIT_NOT_SOLVED",
                    2: "NUMERIC_INFEASIBLE_NOT_EXACT_CERTIFICATE",
                    3: "NUMERIC_UNBOUNDED_MODEL_OR_NUMERICAL_ERROR", 4: "NUMERICAL_FAILURE"}
    summary["status"] = status_names.get(result.status, "UNKNOWN")
    if result.x is not None and np.all(np.isfinite(result.x)):
        audit = numerical_audit(model, result.x, result, args.audit_tolerance)
        summary["audit"] = audit
        if not audit["numerically_feasible"]:
            summary["status"] = "NUMERICAL_AUDIT_FAILED"
        if audit["numerically_feasible"]:
            # Preserve the raw vector: never clip or renormalize a witness silently.
            np.savez_compressed(folder / "witness.npz", u=result.x,
                                offsets=np.array([v.offset for v in model.nodes]),
                                caps=np.array([v.cap for v in model.nodes]),
                                config_json=json.dumps(config), version=VERSION)
            summary["objective_numeric"] = float(model.c @ result.x)
            summary["root"] = diagnostics(model, result.x, folder, reference_values)
            if result.success:
                summary["dual_certificate"] = make_dual_certificate(model, result, folder / "dual_certificate.json.gz")
                if args.lift_dual:
                    summary["lifted_dual_certificate"] = lift_dual_to_full_support(
                        model, folder / "dual_certificate.json.gz",
                        folder / "unrestricted_dual_certificate.json.gz", args.lift_dual_max_vars)
                summary["primal_certificate"] = try_primal_certificate(
                    model, result, folder / "primal_certificate.json.gz", args.exact_primal_max_vars)
                summary["numeric_objective_minus_exact_lower"] = summary["objective_numeric"] - summary["dual_certificate"]["value"]
                if summary["primal_certificate"]["status"] == "EXACT_FEASIBLE_UPPER_BOUND":
                    summary["exact_interval"] = {"lower": summary["dual_certificate"]["rational"],
                                                 "upper": summary["primal_certificate"]["rational"]}
    summary["total_seconds"] = time.monotonic() - started
    write_json(old, summary)
    log(f"{folder.name}: {summary['status']}; objective={summary.get('objective_numeric')}")
    return summary


def aggregate_results(out, summaries):
    np, _, _, _ = dependencies()
    rows = []
    for result in summaries:
        cfg = result["config"]
        n = cfg["n"]
        value = result.get("objective_numeric")
        mean = result.get("root", {}).get("mean")
        rows.append({"n": n, "objective": cfg["objective"], "memory": cfg["memory"],
                     "scope": result["scope"], "status": result["status"],
                     "objective_numeric": value, "root_mean": mean,
                     "root_tail_A": result.get("root", {}).get("tail_A"),
                     "mean_over_log_n_plus_1": mean / math.log(n + 1) if mean is not None else None,
                     "mean_over_n_quarter": mean / n**0.25 if mean is not None else None,
                     "exact_lower": result.get("dual_certificate", {}).get("rational"),
                     "exact_unrestricted_lower_from_lift": result.get("lifted_dual_certificate", {}).get("rational"),
                     "exact_upper": result.get("primal_certificate", {}).get("rational"),
                     "seconds": result.get("total_seconds")})
    write_csv(out / "summary.csv", rows)
    write_json(out / "summary.json", {"version": VERSION, "warning": SCOPE_WARNING, "runs": summaries})
    # Differences use only comparable, unrestricted, mean-optimal runs.
    vals = {r["config"]["n"]: r["objective_numeric"] for r in summaries
            if r["scope"] == "unrestricted_B_n" and r["status"] == "NUMERIC_OPTIMUM"}
    scale_rows = []
    for n, value in sorted(vals.items()):
        scale_rows.append({"n": n, "B_numeric": value,
                           "B_n_minus_B_n_minus_1": value - vals[n - 1] if n - 1 in vals else None,
                           "n_times_increment": n * (value - vals[n - 1]) if n - 1 in vals else None,
                           "B_2n_minus_B_n": vals[2 * n] - value if 2 * n in vals else None,
                           "loglog_slope_n_to_2n": math.log(vals[2 * n] / value) / math.log(2) if 2 * n in vals and value > 0 else None})
    write_csv(out / "scales.csv", scale_rows)
    fit = {"warning": "Descriptive fits to small finite data, not evidence of a proved asymptotic order.",
           "minimum_points": 4, "sample_count": len(vals), "models": []}
    if len(vals) >= 4:
        x = np.array(sorted(vals), dtype=float)
        y = np.array([vals[int(n)] for n in x])
        for label, f in [("a+b*log(n+1)", np.log1p(x)),
                         ("a+b*log(n+1)^2", np.log1p(x)**2),
                         ("a+b*n^(1/4)", x**0.25),
                         ("a+b*n", x)]:
            a = np.column_stack([np.ones_like(x), f])
            coeff = np.linalg.lstsq(a, y, rcond=None)[0]
            train = np.linalg.lstsq(a[:-1], y[:-1], rcond=None)[0]
            fit["models"].append({"model": label, "intercept": float(coeff[0]),
                                   "coefficient": float(coeff[1]),
                                   "in_sample_RMSE": float(np.sqrt(np.mean((a @ coeff - y)**2))),
                                   "last_horizon_prediction_error": float(a[-1] @ train - y[-1])})
    write_json(out / "growth_fits.json", fit)


def replay_audit(folder, tolerance=1e-7):
    np, _, _, _ = dependencies()
    folder = Path(folder)
    with np.load(folder / "witness.npz", allow_pickle=False) as data:
        config = json.loads(str(data["config_json"]))
        values = data["u"].copy()
    model = build_model(config, {"max_nodes": 500000, "max_vars": 5000000,
                                 "max_nnz": 100000000})
    class Dummy:
        success = False
    result = numerical_audit(model, values, Dummy(), tolerance)
    write_json(folder / "replayed_audit.json", result)
    print(json.dumps(result, indent=2))
    return 0 if result["numerically_feasible"] else 1


def parser():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--horizons", type=int, nargs="+", default=[1, 2, 3, 4, 5])
    p.add_argument("--objective", choices=["mean", "tail", "both"], default="both")
    p.add_argument("--out", type=Path, default=Path("log_bound_results"))
    p.add_argument("--memory", type=int, default=None, help="restrict laws to (time,sum,last-k); omitted = full history")
    p.add_argument("--root-cap", type=int, default=None, help="default 4*n is lossless; smaller cap is a restricted experiment")
    p.add_argument("--tail-cap", type=str, help="add exact rational A upper cap, e.g. 1/2")
    p.add_argument("--mean-budget", type=str, help="add exact rational root mean upper cap")
    p.add_argument("--profile-lambda", type=str, help="fix root to clipped lambda/((j+lambda)(j+lambda+1)) profile")
    p.add_argument("--contact", action="append", type=parse_contact, default=[], help="additional conditional-mean equality, e.g. 4=43/180")
    p.add_argument("--time-limit", type=float, default=120, help="HiGHS time limit per LP, seconds")
    p.add_argument("--method", choices=["highs", "highs-ds", "highs-ipm"], default="highs")
    p.add_argument("--explicit-leaves", action="store_true", help="disable exact last-generation elimination (for cross-checking)")
    p.add_argument("--solver-tolerance", type=float, default=1e-9)
    p.add_argument("--audit-tolerance", type=float, default=1e-7)
    p.add_argument("--max-vars", type=int, default=1000000)
    p.add_argument("--max-nnz", type=int, default=15000000)
    p.add_argument("--max-nodes", type=int, default=200000)
    p.add_argument("--exact-primal-max-vars", type=int, default=10000, help="attempt exact rational reconstruction only below this size; 0 disables")
    p.add_argument("--lift-dual", action="store_true", help="also verify a small-support dual on full root support 0..4n")
    p.add_argument("--lift-dual-max-vars", type=int, default=5000000, help="limit for exact support-extension checking, without a large LP solve")
    p.add_argument("--dry-run", action="store_true", help="report sizes without allocating sparse matrices or solving")
    p.add_argument("--resume", action="store_true", help="reuse completed runs with identical mathematical configuration")
    p.add_argument("--no-presolve", action="store_true")
    p.add_argument("--solver-log", action="store_true")
    p.add_argument("--audit", type=Path, help="recheck saved witness.npz in a run directory")
    return p


def main(argv=None):
    p = parser()
    args = p.parse_args(argv)
    if args.audit:
        return replay_audit(args.audit, args.audit_tolerance)
    if any(n < 1 for n in args.horizons):
        p.error("horizons must be positive")
    if args.memory is not None and args.memory < 0:
        p.error("memory must be nonnegative")
    if args.root_cap is not None and args.root_cap < 0:
        p.error("root cap must be nonnegative")
    if not math.isfinite(args.time_limit) or args.time_limit <= 0:
        p.error("time limit must be positive and finite")
    if not 1e-10 <= args.solver_tolerance <= 1e-4:
        p.error("solver tolerance must lie between 1e-10 and 1e-4")
    if not 0 < args.audit_tolerance < 1:
        p.error("audit tolerance must lie between 0 and 1")
    for name in ("max_nodes", "max_vars", "max_nnz", "lift_dual_max_vars"):
        if getattr(args, name) < 1:
            p.error(name + " must be positive")
    if args.exact_primal_max_vars < 0:
        p.error("exact primal size must be nonnegative")
    for name in ("tail_cap", "mean_budget", "profile_lambda"):
        value = getattr(args, name)
        if value is not None:
            try:
                rational = F(value)
            except (ValueError, ZeroDivisionError):
                p.error(name + " must be a rational number")
            if rational < 0 or (name == "profile_lambda" and rational == 0):
                p.error(name + " must be nonnegative (lambda strictly positive)")
            setattr(args, name, str(rational))
    summaries = []
    references = {n: float(v) for n, v in KNOWN_B.items()}
    args.out.mkdir(parents=True, exist_ok=True)
    log(VERSION + ": " + SCOPE_WARNING)
    objectives = ["mean", "tail"] if args.objective == "both" else [args.objective]
    try:
        for n in sorted(set(args.horizons)):
            for objective in objectives:
                leaf_reduction = (not args.explicit_leaves and
                                  (args.memory is None or args.memory >= n) and
                                  all(len(c["history"]) < n for c in args.contact))
                config = {"n": n, "root_cap": args.root_cap if args.root_cap is not None else 4 * n,
                          "memory": args.memory, "objective": objective, "tail_cap": args.tail_cap,
                          "mean_budget": args.mean_budget, "profile_lambda": args.profile_lambda,
                          "contacts": args.contact, "leaf_reduction": leaf_reduction}
                digest = hashlib.sha256(json.dumps(config, sort_keys=True).encode()).hexdigest()[:10]
                name = f"n{n:03d}_{objective}_" + ("full" if args.memory is None else f"memory{args.memory}") + "_" + digest
                if args.dry_run:
                    try:
                        print(json.dumps({"config": config, "size": build_model(config, vars(args))}, indent=2))
                    except ResourceLimit as exc:
                        print(json.dumps({"config": config, "resource_limit": str(exc)}, indent=2))
                    continue
                result = run_one(config, args.out / name, args, references)
                summaries.append(result)
                if result["scope"] == "unrestricted_B_n" and result["status"] == "NUMERIC_OPTIMUM":
                    references[n] = result["objective_numeric"]
                aggregate_results(args.out, summaries)
    except KeyboardInterrupt:
        log("Interrupted. Finished runs are saved; unfinished LP has no verdict. Use --resume.")
        return 130
    except (ValueError, ArithmeticError) as exc:
        log(f"ERROR: {exc}")
        return 1
    if not args.dry_run:
        log(f"Results: {args.out.resolve()}")
    return 0 if all(r["status"] == "NUMERIC_OPTIMUM" for r in summaries) else 2


if __name__ == "__main__":
    raise SystemExit(main())
