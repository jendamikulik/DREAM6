# DREAM6 LOG BOUND LAB

Výzkumný solver pro otázku, zda **B_n = O(log n)** v přiloženém modelu rezervy.
Hledá konečné stromy, jejich kritické ocasy a překážky pokračování. Výsledkem jsou
číselná data, celé uložené zákony, diagnostika a samostatně ověřitelné certifikáty.
Konečný experiment sám nerozhodne asymptotickou otázku.

## Spuštění

Python 3.10 nebo novější:

```powershell
python -m pip install -r requirements.txt
python DREAM6_LOG_BOUND_LAB_v1.py
```

Bez parametrů proběhnou horizonty 1 až 5 pro oba cíle. Výsledky se uloží do
`log_bound_results`. Časový limit je 120 sekund na jeden LP. Při jeho dosažení
se uloží `LIMIT_NOT_SOLVED` a program pokračuje; tento stav není důkaz neexistence.

Na Windows lze použít i připravený spouštěč. Vyhledá Python, případně zdejší
Python dodávaný s aplikací Codex. Závislosti instaluje pouze do složky balíčku:

```powershell
.\RUN_WINDOWS.ps1 -InstallDependencies
# Při dalších spuštěních:
.\RUN_WINDOWS.ps1
# Předání parametrů:
.\RUN_WINDOWS.ps1 -SolverArgs @('--horizons','6','--method','highs-ipm','--time-limit','600')
```

Přiložené `research_results` obsahují již provedené pokusy. Pro nové běhy použijte
vlastní `--out`, aby zůstaly zachované. Skript nepotřebuje původní PDF, ZIP ani SAT skripty.

## Dvě různé optimalizační otázky

Pro P=(8,16,16,16,8)/64 a Q=(7,20,10,20,7)/64 hledáme pravděpodobnosti b[h,j]:

```
b[h,j] >= 0,  sum_j b[h,j] = 1
sum_y Q(y)*b[h,s-y] = sum_x P(x)*b[hx,s-x]
```

Záporné indexy mají hmotnost nula. Rovnice platí v každém vnitřním uzlu a pro
každý příslušný koeficient s. Nepředepisuje se nulová koncová rezerva. Rovnice
mají kauzální realizaci s čerstvými nezávislými vstupy Q a výstupy iid P.
Podmínka iid se nevynucuje po dodatečném podmínění skrytým stavem.

* `--objective mean` minimalizuje `sum_j j*b[root,j]`, tedy B_n v neomezeném režimu.
* `--objective tail` minimalizuje **A_n = min_tree max_{1<=j<=4n} j*Pr(J_0>=j)**.
  Proměnná A je společná všem kořenovým ocasovým nerovnostem. To přímo hledá
  konečné realizace kritéria z PDF; nejde o dodatečný fit ocasu jednoho řešení.
* `--objective both` provede oba pokusy samostatně.

Kořenová podpora 0..4n je beze ztráty pro oba cíle: oříznutí počáteční rezervy
snižuje střední hodnotu i všechny ocasy a zachovává realizovatelnost konečného stromu.
V uzlu h délky t je podpora `0..(4n+4t-sum(h))`. Celé pořadí historie zůstává zachováno.

Rovnoměrně omezená ocasová konstanta v přesné nekonečné konstrukci by dala
`B_n <= A*H_(4n)`. Solver nevynucuje, aby nezávisle optimalizované stromy pro
různá n tvořily jednu kompatibilní nekonečnou rodinu. Rostoucí A_n ve finitním
vzorku nevyvrací logaritmickou mez; tato cesta je postačující, její nutnost pro
obecné B_n=O(log n) není předpokládána.

## Přesná redukce poslední generace

Pro poslední krok stačí spojit `S~Q*B_h` s `X~P` tak, aby X<=S. To je možné
právě tehdy, když

```
Pr(S <= s) <= Pr(X <= s), s = 0,1,2,3.
```

Pro s>=4 je pravá strana 1. Čtyři lineární nerovnosti tedy přesně nahradí
všech pět koncových zákonů. Monotónní kvantilové spojení je následně obnoví.
Funkce `terminal_children` v ověřovači umí tuto obnovu přesně v racionální aritmetice.

Pro n=5 redukce zmenší 119 136 proměnných na 22 261. Nejde o aproximaci.
`--explicit-leaves` zachová všechny koncové zákony pro kontrolní porovnání.
Redukce se automaticky vypíná pro skutečně slučované historie nebo kontakt
v koncovém uzlu, aby se nezměnil význam omezení.

## Pokusy, které mají přinést nové informace

### Větší horizont a přírůstky

```powershell
python DREAM6_LOG_BOUND_LAB_v1.py --horizons 1 2 3 4 5 6 --method highs-ipm --time-limit 600 --out larger --resume
```

V tomto prostředí byl `highs-ipm` na šestém horizontu podstatně rychlejší než
výchozí volba `highs`. `--time-limit` je limit optimalizátoru; sestavení,
kontrola certifikátů a zápis mají vlastní čas a nejsou jím omezeny.

`scales.csv` obsahuje B_n-B_(n-1), n krát tento přírůstek a B_(2n)-B_n,
pokud jsou obě potřebná n skutečně vypočtená. Poslední veličina odpovídá
postačující podmínce z PDF; její zdánlivá stabilita pro několik n není důkaz.
`growth_fits.json` porovnává log(n+1), log(n+1)^2, n^(1/4) a n s volným
konstantním členem. Zvlášť uvádí chybu predikce posledního horizontu.
Fit nedostává označení „správná asymptotika“.

### Menší kořenová podpora a kontrola na celé podpoře

```powershell
python DREAM6_LOG_BOUND_LAB_v1.py --horizons 5 6 7 --objective mean --root-cap 2 --lift-dual --method highs-ipm --time-limit 600 --out support2
```

Samotné `--root-cap 2` řeší omezený problém. `--lift-dual` přenese jeho
duální multiplikátory do modelu s plnou kořenovou podporou 0..4n, zkusí
nulové i konstantní doplnění a **přesně zkontroluje všechny nové sloupce**. Případné
porušení opraví snížením duálních normalizačních multiplikátorů. Vzniklý
`unrestricted_dual_certificate.json.gz` již může dát dolní mez pro B_n.
Přenesená mez může být slabá; pokud obě varianty dávají zápornou mez, použije
se triviální duál s mezí nula a neúspěšné hodnoty zůstanou v diagnostice.
Tato možnost neprohlašuje omezenou podporu
za optimální. Kontrola velkého duálu vyžaduje paměť, ale neřeší velký LP.

Porovnávejte jeho přesnou dolní mez s nalezenou střední hodnotou. Horní
mez je přesně certifikovaná pouze tehdy, když se podaří i rekonstrukce
racionálního primálu. Malý numerický rozdíl je užitečný vodítkem, není
náhradou chybějícího primálního certifikátu.

### Cena kritického ocasu při omezeném průměru

```powershell
python DREAM6_LOG_BOUND_LAB_v1.py --horizons 5 --objective tail --mean-budget 2/5 --out tail_budget
python DREAM6_LOG_BOUND_LAB_v1.py --horizons 5 6 --objective mean --tail-cap 3/10 --method highs-ipm --time-limit 600 --out tail_cap
```

První pokus hledá nejmenší A při střední rezervě nejvýše 0,4. Druhý zkoumá
proveditelnost A<=0,3 a nejmenší průměr za této podmínky. Používají přesné
racionální hodnoty zadaných omezení. To umožňuje zkoumat kompromis mezi
průměrem a kritickým ocasem, nikoli jen libovolnou volbu jednoho optimálního stromu.

### Test konkrétního kritického profilu

```powershell
python DREAM6_LOG_BOUND_LAB_v1.py --horizons 3 4 5 --objective mean --profile-lambda 1/2 --out profile
```

Kořen je pevně `lambda/((j+lambda)(j+lambda+1))`, pro j<4n; ve 4n je
zbytek `lambda/(4n+lambda)`. Je to přesně distribuce min(J,4n), nikoli
useknutý a přenormalizovaný ocas. Zákony potomků zůstávají volné.
Neúspěch konkrétního lambda nevylučuje jiné profily ani obecnou logaritmickou mez.

### Pořadí historie a omezená paměť

```powershell
python DREAM6_LOG_BOUND_LAB_v1.py --horizons 4 8 16 --memory 0 --objective mean --out memory0
python DREAM6_LOG_BOUND_LAB_v1.py --horizons 4 8 16 --memory 2 --objective mean --method highs-ipm --time-limit 600 --out memory2
```

`--memory k` vyžaduje stejný zákon pro historie se stejnou délkou, součtem
a posledními k symboly. Výchozí režim žádné takové slučování neprovádí.
Každé proveditelné řešení tohoto DAG lze rozvinout na celý strom. Jeho
hodnota je ale optimum **omezené rodiny**, a růst této hodnoty není dolní
mez pro neomezené B_n. To je zvlášť důležité pro k=0: výzkumná poznámka
přímo popisuje překážku pro reprezentace, které zahazují pořadí.

U slučovaných DAG se automaticky vypíná předzpracování HiGHS (`presolve`):
v tomto prostředí na jejich závislých rovnicích chybovalo. Původní řídký
systém lze řešit přímo; tato změna nijak nemění matematické omezení.

### Kontakty

```powershell
python DREAM6_LOG_BOUND_LAB_v1.py --horizons 5 --objective mean --contact 4=144958044813242692/420381282815550045 --out contact5
```

Přidá rovnost E[B_(4)]=B_4 a změří cenu tohoto požadavku. Další kontakty
lze přidat opakováním přepínače, například `--contact 4,4=43/180`.
Existence kontaktu v jednom numerickém optimu nedokazuje kontakt na celé
optimální stěně. Solver takový závěr automaticky nedělá.

## Co číst ve výsledcích

| Soubor | Informace |
|---|---|
| `summary.csv`, `summary.json` | Cíl, rozsah platnosti, stav, hodnoty, certifikované meze, časy |
| `scales.csv`, `growth_fits.json` | Přírůstky a popisné porovnání růstových tvarů |
| `result.json` v jednotlivém běhu | Rozměry LP, verze knihoven, tolerance, rezidua, stav ověření |
| `witness.npz` | Neupravovaný numerický vektor a přesné indexování zákonů |
| `root_tail.csv` | Každý kořenový atom, ocas Pr(J>=j), součin j*Pr(J>=j) |
| `nodes.csv`, `fans.csv` | Podmíněné střední rezervy, váhy větví a srovnání s dostupnými B_r |
| `layers.csv` | Obyčejné a nakloněné průměry, kontrola PGF identity, podíl ceny ve vzácných větvích |
| `order_effects.csv` | Rozdíly mezi vybranými permutacemi stejné historie v jednom řešení |
| `currents.csv`, `current_coefficients.csv` | Podepsané proudy H_0,...,H_3 z poznámky pro první dvě explicitní generace |
| `*_certificate.json.gz` | Samostatně přesně ověřitelné duální nebo primální svědky |

Soubory k prázdným diagnostikám nevznikají. Při redukci posledního kroku
`nodes.csv` obsahuje zákony do hloubky n-1; konečná generace je reprezentována
kvantilovým pravidlem. U sdíleného stavu DAG je uvedena celková pravděpodobnost
všech historií tohoto stavu. `representative_history` je jen jeden jeho zástupce.

Průměrný zákon uvnitř optimální stěny není unikátní. Změna metody LP může
změnit proudy, průměry potomků, tvar ocasově optimálního kořene i diagnostiku
pořadí, přestože optimum zůstává stejné. Pole `mean_minus_reference` používá
dostupné numerické/známé B_r; není samo o sobě certifikátem nuceného defektu.

## Přesnost a nezávislá kontrola

```powershell
python verify_log_bound.py log_bound_results --recursive
python DREAM6_LOG_BOUND_LAB_v1.py --audit log_bound_results\KONKRETNI_SLOZKA_BEHU
python -m unittest -v test_log_bound.py
```

Ověřovač používá pouze standardní knihovnu, `int` a `Fraction`. Znovu
sestaví koeficientové rovnice přímo z definice. Nenačítá kód solveru.

* `NUMERIC_OPTIMUM`: optimalizátor uspěl a vektor prošel numerickým auditem.
* `EXACT_DUAL_LOWER_BOUND` / `EXACT_DUAL_VERIFIED`: dolní mez z přesně
  splněných duálních nerovností; vždy čtěte i `scope`.
* `EXACT_FEASIBLE_UPPER_BOUND` / `EXACT_PRIMAL_VERIFIED`: racionální
  zákony splňují všechny rovnosti a nerovnosti přesně.
* `NO_EXACT_PRIMAL_RECONSTRUCTED`: numerický primál nebyl povýšen na důkaz.
* `NUMERIC_INFEASIBLE_NOT_EXACT_CERTIFICATE`: numerický optimalizátor oznámil
  neproveditelnost; není to přesný Farkasův certifikát.

Duální multiplikátory se zaokrouhlí na společný jmenovatel 2^40. Je-li
v bloku b[h,.] nejmenší redukovaná cena záporná, sníží se příslušný
normalizační multiplikátor. Protože celý blok má součet 1, vznikne platná
duální mez s explicitně evidovanou ztrátou. U cíle A se zvlášť ohlídá jeho
nezáporná pomocná proměnná. Všechny sloupce se poté zkontrolují přesně.

Primál se zkouší rekonstruovat racionální aproximací pro několik limitů
jmenovatelů. Soubor vznikne pouze při přesné shodě každé rovnice. Selhání
rekonstrukce se neinterpretuje jako neproveditelnost. Přepínač
`--exact-primal-max-vars` omezuje tuto doplňkovou práci.

## Výpočetní meze a pokračování

Počet úplných historií stále roste exponenciálně. Poslední generace se
eliminuje přesně, ale tím nevzniká polynomiální řešení celé otázky.
Před větším během použijte například:

```powershell
python DREAM6_LOG_BOUND_LAB_v1.py --horizons 7 8 --dry-run
python DREAM6_LOG_BOUND_LAB_v1.py --horizons 7 --root-cap 2 --dry-run
```

Limity `--max-vars`, `--max-nnz` a `--max-nodes` chrání před nechtěným
sestavením obrovského modelu. Odhad paměti v diagnostice nezahrnuje
faktorizaci uvnitř optimalizátoru. `--resume` opětovně použije dokončené
výsledky se stejným matematickým zadáním; neobnovuje vnitřní stav přerušeného LP.

Pro další rozpoznávání vzoru má smysl vrátit `summary.json` společně s
adresáři zajímavých běhů. Samotné fitované exponenty zahodí většinu informace,
kvůli které tento solver vznikl.

## Podklady

Matematické zadání je převzato z dodaných čtyř PDF. Z novější
`critical_reserve_research_note.pdf` se přebírá i analytická horní mez
O(n^(1/4)); starší O(n) není uváděno jako nejlepší známý výsledek podkladů.
Zdrojové otisky jsou v `source_manifest.json`.

Dodaný veřejný ZIP obsahuje certifikáty horizontů 1 až 4. Nové certifikáty
z pátého horizontu, popsané v novějším PDF, v tomto ZIP nejsou. Solver jejich
existenci nezaměňuje za vlastní ověření: pátý horizont počítá znovu.
Výchozí analytické meze převzaté z PDF mají v JSON příznak
`source_bounds_reverified_here: false`.

SAT skripty sloužily jako příklady samostatného výzkumného programu s auditem.
Nejsou spouštěny ani importovány a jejich interní metodické pokyny nejsou
považovány za vaše zadání. Zde je použit přesný konečný LP model s numerickým
backendem [SciPy/HiGHS](https://docs.scipy.org/doc/scipy/reference/optimize.linprog-highs.html).
