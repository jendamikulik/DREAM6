# První výpočty solveru

Provedeno 6. září 2026. Python 3.12, NumPy 2.3.5, SciPy 1.18.1.

## Neomezené pořadí historie

Hodnoty v tabulce jsou **numerická optima**, zaokrouhlená pro přehled.
A_n označuje samostatné minimum `max_j j*Pr(J_0>=j)`; nemusí být dosažené
stromem s nejmenší střední rezervou.

| n | B_n numericky | A_n numericky |
|---|---:|---:|
| 1 | 0,150000000 | 0,127659574 |
| 2 | 0,238888889 | 0,203309693 |
| 3 | 0,296480916 | 0,248139392 |
| 4 | 0,344825164 | 0,274705140 |
| 5 | 0,378315691 | 0,290447806 |
| 6 | 0,403037620 | nedopočteno |

První čtyři hodnoty B_n souhlasí se známými racionálními hodnotami v podkladech.
Pátá leží v intervalu uvedeném v novějším PDF. Šestý horizont je nový výpočet
tohoto solveru, s plnou kořenovou podporou 0..24 a beze slučování historií.

Pro šestý horizont se nezávisle a přesně ověřila dolní mez

```
B_6 >= 443144529797 / 1099511627776 > 0.40303760.
```

Nalezený numerický primál má hodnotu 0,4030376200024787. Největší reziduum
rovnice je přibližně 6,13e-13. Přesný racionální primál pro tento horizont
nebyl rekonstruován, takže tento numerický údaj zde není vydáván za přesný
horní certifikát ani za přesnou hodnotu B_6. Kompletní vektor a jeho nový
audit jsou v příslušné složce `research_results`.

Kořen jednoho nalezeného řešení pro n=5 i n=6 má kladnou hmotnost i v atomu 2.
Omezení kořene na atomy 0 a 1 by proto nemělo být bez ověření přeneseno
z prvních čtyř horizontů do dalších pokusů.

## Kontrolní pokusy

* Po přidání E[B_(4)]=B_4 na horizontu 5 vyšlo numericky 0,38123379866143.
  Přesně ověřená dolní mez tohoto omezeného problému je větší než 0,3812337.
  To souhlasí s popsaným selháním kontaktu v podkladech.
* Pro n=4 při vynucené závislosti zákonů jen na délce a součtu historie
  vyšlo přibližně 2,173838217. S přidáním posledního symbolu do stavu vyšlo
  1,750483520. Neomezený strom má přibližně 0,344825164. Tato optima platí
  pro různé třídy; první dvě hodnoty nejsou dolní meze pro neomezené B_4.
* Kořenová podpora 0..2 numericky reprodukovala hodnoty pro n=5,6 a zrychlila
  výpočet. Dvě jednoduchá doplnění jejího duálu na celou podporu ale nedala
  užitečnou neomezenou mez. Uložený přenesený certifikát proto dává jen 0;
  tento pokus není certifikátem optimálnosti malé podpory.

## Co zůstalo nedopočtené

Ocasová úloha pro n=6 skončila i s metodou `highs-ipm` na limitu 180 sekund.
Horizon 7 s kořenovou podporou 0..2 skončil na stejném limitu. Paměťové
varianty horizontu 8 skončily na limitu 30 sekund. Tyto stavy jsou v JSON
zachované a neznamenají neproveditelnost.

V prvních pokusech chybovalo předzpracování HiGHS u DAG s omezenou pamětí.
Finální solver je pro tyto DAG automaticky vypíná. Kontrolní výpočet n=4
pak uspěl na původním systému rovnic. Výchozí plný strom touto změnou
omezen ani sloučen není.

## Ověření

Prošlo všech **14 testů** a **22 souborů s přesnými certifikáty**. Počet
certifikátů zahrnuje různé cíle, omezené problémy a dva triviální přenesené
duály; není to počet nově určených hodnot B_n. Podrobnosti jsou v
`test_log.txt` a `verification_log.txt`.

Testy zahrnují jinou kauzální formulaci s tokovými proměnnými pro n=1,2,
porovnání úplné a redukované poslední generace, známé hodnoty B_1,...,B_4,
obnovu koncových zákonů v přesné aritmetice a odmítnutí poškozených svědků.
Byl také ověřen Windows spouštěč v režimu odhadu rozměrů.

Tato data jsou podkladem pro hledání vzoru. Nerozhodují, zda B_n=O(log n).
Nejvhodnější další data jsou větší konečné horizonty, kompromis mezi
omezeným průměrem a ocasovou konstantou a konkrétní zákony potomků,
které dovolují nebo blokují pokračování.
