param(
    [switch]$InstallDependencies,
    [string[]]$SolverArgs = @()
)
$ErrorActionPreference = 'Stop'
$runtimePrefix = @()
$runtimeCommand = Get-Command py -ErrorAction SilentlyContinue
if ($runtimeCommand) {
    $runtimePath = $runtimeCommand.Source
    $runtimePrefix = @('-3')
} else {
    $runtimeCommand = Get-Command python -ErrorAction SilentlyContinue
    if ($runtimeCommand) {
        $runtimePath = $runtimeCommand.Source
    } else {
        $runtimePath = Join-Path $env:USERPROFILE '.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
        if (-not (Test-Path -LiteralPath $runtimePath)) {
            throw 'Python 3.10+ nebyl nalezen. Nainstalujte Python a spustte tento soubor znovu.'
        }
    }
}
$localDependencies = Join-Path $PSScriptRoot 'python_deps'
$originalPythonPath = $env:PYTHONPATH
$env:PYTHONPATH = $localDependencies + [IO.Path]::PathSeparator + $originalPythonPath
try {
    if ($InstallDependencies) {
        & $runtimePath @runtimePrefix -m pip install --only-binary=:all: --target $localDependencies -r (Join-Path $PSScriptRoot 'requirements.txt')
        if ($LASTEXITCODE -ne 0) { throw 'Instalace zavislosti selhala.' }
    }
    & $runtimePath @runtimePrefix -c 'import numpy, scipy'
    if ($LASTEXITCODE -ne 0) {
        throw 'Chybi NumPy nebo SciPy. Spustte: .\RUN_WINDOWS.ps1 -InstallDependencies'
    }
    Write-Host ('Python: ' + $runtimePath)
    Push-Location -LiteralPath $PSScriptRoot
    try {
        & $runtimePath @runtimePrefix (Join-Path $PSScriptRoot 'DREAM6_LOG_BOUND_LAB_v1.py') @SolverArgs
        $solverExitCode = $LASTEXITCODE
    } finally {
        Pop-Location
    }
} finally {
    $env:PYTHONPATH = $originalPythonPath
}
exit $solverExitCode
