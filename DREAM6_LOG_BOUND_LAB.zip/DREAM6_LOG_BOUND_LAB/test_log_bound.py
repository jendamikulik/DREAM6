#!/usr/bin/env python3
"""Regression and soundness tests. Run: python -m unittest -v test_log_bound.py"""
from fractions import Fraction as F
import gzip
import json
from pathlib import Path
import tempfile
import unittest

import numpy as np
from scipy.optimize import linprog
from scipy.sparse import coo_matrix

import DREAM6_LOG_BOUND_LAB_v1 as lab
import verify_log_bound as verifier


LIMITS = {"max_nodes": 200000, "max_vars": 1000000, "max_nnz": 15000000}


def config(n, objective="mean", **changes):
    result = {"n": n, "root_cap": 4 * n, "memory": None,
              "objective": objective, "tail_cap": None, "mean_budget": None,
              "profile_lambda": None, "contacts": [], "leaf_reduction": True}
    result.update(changes)
    return result


def solve(cfg):
    model = lab.build_model(cfg, LIMITS)
    result = linprog(model.c, A_eq=model.aeq, b_eq=model.beq,
                     A_ub=model.aub, b_ub=model.bub, bounds=(0, None), method="highs",
                     options={"primal_feasibility_tolerance": 1e-9,
                              "dual_feasibility_tolerance": 1e-9})
    return model, result


def independent_occupancy_value(n):
    """Small reference model with fresh-input flows, not conditional-law rows."""
    from itertools import product
    mu, flow = {}, {}
    costs = []
    for t in range(n + 1):
        for h in product(range(5), repeat=t):
            for j in range(4 * n + 4 * t + 1):
                mu[t, h, j] = len(costs)
                costs.append(j if t == 0 else 0)
    for t in range(n):
        for h in product(range(5), repeat=t):
            for j in range(4 * n + 4 * t + 1):
                for y in range(5):
                    for x in range(5):
                        if j + y >= x:
                            flow[t, h, j, y, x] = len(costs)
                            costs.append(0)
    rr, cc, dd, rhs = [], [], [], []

    def row(terms, b=0):
        k = len(rhs)
        rhs.append(b)
        for col, value in terms:
            rr.append(k)
            cc.append(col)
            dd.append(value)
    row([(idx, 1) for (t, _, _), idx in mu.items() if t == 0], 1)
    for t in range(n):
        for h in product(range(5), repeat=t):
            for j in range(4 * n + 4 * t + 1):
                for y in range(5):
                    terms = [(mu[t, h, j], -lab.Q[y])]
                    terms += [(flow[t, h, j, y, x], 1) for x in range(5) if (t, h, j, y, x) in flow]
                    row(terms)
            for x in range(5):
                for jp in range(4 * n + 4 * (t + 1) + 1):
                    terms = [(mu[t + 1, h + (x,), jp], 1)]
                    for y in range(5):
                        j = jp + x - y
                        key = (t, h, j, y, x)
                        if key in flow:
                            terms.append((flow[key], -1))
                    row(terms)
                terms = [(mu[t + 1, h + (x,), jp], 1) for jp in range(4 * n + 4 * (t + 1) + 1)]
                terms += [(mu[t, h, j], -lab.P[x]) for j in range(4 * n + 4 * t + 1)]
                row(terms)
    a = coo_matrix((dd, (rr, cc)), shape=(len(rhs), len(costs))).tocsr()
    result = linprog(costs, A_eq=a, b_eq=rhs, bounds=(0, None), method="highs")
    if not result.success:
        raise AssertionError(result.message)
    return result.fun


class ReserveTests(unittest.TestCase):
    def test_known_values_and_independent_verifier(self):
        with tempfile.TemporaryDirectory() as temp:
            for n in range(1, 5):
                with self.subTest(n=n):
                    model, result = solve(config(n))
                    self.assertTrue(result.success, result.message)
                    self.assertAlmostEqual(result.fun, float(lab.KNOWN_B[n]), places=9)
                    path = Path(temp) / f"dual{n}.json.gz"
                    cert = lab.make_dual_certificate(model, result, path)
                    checked = verifier.verify(path)
                    self.assertEqual(checked["status"], "EXACT_DUAL_VERIFIED")
                    self.assertLessEqual(F(cert["rational"]), lab.KNOWN_B[n])
                    self.assertLess(float(lab.KNOWN_B[n]) - cert["value"], 1e-7)

    def test_last_generation_elimination_is_lossless(self):
        for n in (1, 2, 3):
            for objective in ("mean", "tail"):
                with self.subTest(n=n, objective=objective):
                    _, reduced = solve(config(n, objective))
                    _, full = solve(config(n, objective, leaf_reduction=False))
                    self.assertTrue(reduced.success and full.success)
                    self.assertAlmostEqual(reduced.fun, full.fun, places=9)

    def test_against_independent_causal_occupancy_model(self):
        for n in (1, 2):
            _, result = solve(config(n))
            self.assertAlmostEqual(result.fun, independent_occupancy_value(n), places=9)

    def test_published_horizon_five_dimensions(self):
        _, _, variables, rows = lab.build_graph(5, 20, None)
        self.assertEqual((variables, rows), (119136, 29291))
        model = lab.build_model(config(5), {**LIMITS, "dry_run": True})
        self.assertEqual(model["variables"], 22261)
        self.assertEqual(model["inequality_rows"], 2500)

    def test_tail_primal_exact_and_terminal_lift(self):
        with tempfile.TemporaryDirectory() as temp:
            for n, expected in [(1, F(6, 47)), (2, F(86, 423))]:
                model, result = solve(config(n, "tail"))
                path = Path(temp) / f"primal{n}.json.gz"
                made = lab.try_primal_certificate(model, result, path, 10000)
                self.assertEqual(F(made["rational"]), expected)
                checked = verifier.verify(path)
                self.assertEqual(checked["status"], "EXACT_PRIMAL_VERIFIED")
                values = verifier.sparse_vector(verifier.read_json(path)["u"], len(model.c), F)
                for idx in model.layers[-1]:
                    node = model.nodes[idx]
                    law = values[node.offset:node.offset + node.cap + 1]
                    children = verifier.terminal_children(law)
                    left = [F(0)] * (len(law) + 4)
                    right = [F(0)] * len(left)
                    for j, mass in enumerate(law):
                        for y in range(5):
                            left[j + y] += mass * F(lab.QN[y], 64)
                    for x, child in enumerate(children):
                        for j, mass in enumerate(child):
                            right[j + x] += mass * F(lab.PN[x], 64)
                    self.assertEqual(left, right)

    def test_tail_cap_and_profile(self):
        _, bad = solve(config(1, tail_cap="1/10"))
        self.assertEqual(bad.status, 2)
        for objective in ("mean", "tail"):
            model, result = solve(config(2, objective, profile_lambda="1", tail_cap="1"))
            self.assertTrue(result.success, result.message)
            with tempfile.TemporaryDirectory() as temp:
                path = Path(temp) / "dual.json.gz"
                lab.make_dual_certificate(model, result, path)
                self.assertEqual(verifier.verify(path)["scope"], "restricted_finite_problem_only")

    def test_budget_and_contacts(self):
        model, result = solve(config(3, contacts=[{"history": "4", "mean": str(lab.KNOWN_B[2])}]))
        self.assertTrue(result.success, result.message)
        self.assertAlmostEqual(result.fun, float(lab.KNOWN_B[3]), places=9)
        tail, solution = solve(config(2, "tail", mean_budget="43/180"))
        self.assertTrue(solution.success, solution.message)
        self.assertAlmostEqual(solution.fun, float(lab.KNOWN_B[2]), places=8)
        with tempfile.TemporaryDirectory() as temp:
            for m, r in [(model, result), (tail, solution)]:
                path = Path(temp) / "dual.json.gz"
                lab.make_dual_certificate(m, r, path)
                self.assertEqual(verifier.verify(path)["status"], "EXACT_DUAL_VERIFIED")

    def test_history_compression_has_correct_scope(self):
        _, unrestricted = solve(config(3))
        model, compressed = solve(config(3, memory=0, leaf_reduction=False))
        self.assertTrue(compressed.success)
        self.assertGreaterEqual(compressed.fun + 1e-8, unrestricted.fun)
        self.assertEqual(lab.scope(model.config), "restricted_finite_problem_only")
        _, full_memory = solve(config(3, memory=3, leaf_reduction=False))
        self.assertAlmostEqual(full_memory.fun, unrestricted.fun, places=9)
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "dual.json.gz"
            lab.make_dual_certificate(model, compressed, path)
            self.assertEqual(verifier.verify(path)["scope"], "restricted_finite_problem_only")

    def test_dependent_dag_equations_without_presolve(self):
        model = lab.build_model(config(4, memory=1, leaf_reduction=False), LIMITS)
        result = linprog(model.c, A_eq=model.aeq, b_eq=model.beq, bounds=(0, None),
                         method="highs-ds", options={"presolve": False})
        self.assertTrue(result.success, result.message)
        self.assertGreater(result.fun, float(lab.KNOWN_B[4]))
        self.assertTrue(lab.numerical_audit(model, result.x, result, 1e-7)["numerically_feasible"])

    def test_no_reserve_and_small_support(self):
        _, no_reserve = solve(config(1, root_cap=0))
        self.assertEqual(no_reserve.status, 2)
        _, one = solve(config(3, root_cap=1))
        self.assertTrue(one.success)
        self.assertAlmostEqual(one.fun, float(lab.KNOWN_B[3]), places=9)

    def test_lifted_dual_rechecks_all_unrestricted_columns(self):
        model, result = solve(config(3, root_cap=1))
        with tempfile.TemporaryDirectory() as temp:
            old, new = Path(temp) / "old.json.gz", Path(temp) / "new.json.gz"
            lab.make_dual_certificate(model, result, old)
            lifted = lab.lift_dual_to_full_support(model, old, new, 1000000)
            self.assertEqual(lifted["scope"], "unrestricted_B_n")
            checked = verifier.verify(new)
            self.assertEqual(checked["scope"], "unrestricted_B_n")
            self.assertLessEqual(F(checked["lower_bound"]), lab.KNOWN_B[3])
            # Tail objective has a different number of inequalities after lifting.
            model, result = solve(config(2, "tail", root_cap=2))
            lab.make_dual_certificate(model, result, old)
            lab.lift_dual_to_full_support(model, old, new, 1000000)
            self.assertEqual(verifier.verify(new)["scope"], "unrestricted_A_n")

    def test_verifier_rejects_tampering(self):
        model, result = solve(config(1))
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "dual.json.gz"
            lab.make_dual_certificate(model, result, path)
            cert = verifier.read_json(path)
            cert["objective_lower_bound"] = "1"
            lab.write_gzip_json(path, cert)
            with self.assertRaises(ValueError):
                verifier.verify(path)
            path = Path(temp) / "primal.json.gz"
            lab.try_primal_certificate(model, result, path, 10000)
            cert = verifier.read_json(path)
            cert["u"][0][1] = "-1"
            lab.write_gzip_json(path, cert)
            with self.assertRaises(ValueError):
                verifier.verify(path)

    def test_certificate_repair_survives_bad_numerical_duals(self):
        model, result = solve(config(2, "tail", tail_cap="1"))
        result.eqlin.marginals += np.linspace(-0.01, 0.01, len(result.eqlin.marginals))
        result.ineqlin.marginals *= 2
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "dual.json.gz"
            lab.make_dual_certificate(model, result, path)
            self.assertEqual(verifier.verify(path)["status"], "EXACT_DUAL_VERIFIED")

    def test_resource_limit_and_raw_numerical_audit(self):
        with self.assertRaises(lab.ResourceLimit):
            lab.build_model(config(4), {**LIMITS, "max_vars": 10})
        model, result = solve(config(2))
        self.assertTrue(lab.numerical_audit(model, result.x, result, 1e-7)["numerically_feasible"])
        corrupted = result.x.copy()
        corrupted[0] += 0.01
        self.assertFalse(lab.numerical_audit(model, corrupted, result, 1e-7)["numerically_feasible"])


if __name__ == "__main__":
    unittest.main()
