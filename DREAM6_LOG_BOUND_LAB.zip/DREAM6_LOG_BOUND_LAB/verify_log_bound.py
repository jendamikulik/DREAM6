#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Independent EXACT certificate verifier; Python standard library only.

Rebuilds normalization, convolution and optional constraints from the problem.
Does not import DREAM6_LOG_BOUND_LAB_v1, NumPy, SciPy or an optimizer.

    python verify_log_bound.py results --recursive

An exact dual lower bound for a restricted problem is NOT a lower bound for B_n.
An exact feasible mean upper bound is an upper bound for B_n even if restricted.
The same distinction applies to the finite critical-tail optimum A_n.
"""
from __future__ import annotations

import argparse
from fractions import Fraction
import gzip
import json
from pathlib import Path

P64 = [8, 16, 16, 16, 8]
Q64 = [7, 20, 10, 20, 7]


def require(condition, message):
    if not condition:
        raise ValueError(message)


def reject_duplicates(pairs):
    out = {}
    for key, value in pairs:
        require(key not in out, f"duplicate JSON key {key}")
        out[key] = value
    return out


def read_json(path):
    opener = gzip.open if str(path).endswith(".gz") else open
    with opener(path, "rt", encoding="utf-8") as fh:
        return json.load(fh, object_pairs_hook=reject_duplicates)


def rebuild(config, max_columns=5000000, max_nodes=500000):
    n = config["n"]
    root_cap = config["root_cap"]
    memory = config["memory"]
    require(type(n) is int and n >= 1, "invalid horizon")
    require(type(root_cap) is int and 0 <= root_cap < max_columns, "invalid root cap")
    require(memory is None or (type(memory) is int and memory >= 0), "invalid memory")
    require(config["objective"] in ("mean", "tail"), "unknown objective")
    for name in ("tail_cap", "mean_budget", "profile_lambda"):
        if config[name] is not None:
            value = Fraction(config[name])
            require(value >= 0, f"negative {name}")
            if name == "profile_lambda":
                require(value > 0, "zero lambda")
    # State record: depth, sum, suffix; created in breadth-first lexicographic order.
    states = [(0, 0, ())]
    successors = []
    generation = [0]
    total_columns = root_cap + 1
    explicit_depth = n - 1 if config.get("leaf_reduction", False) else n
    require(not config.get("leaf_reduction", False) or
            (memory is None or memory >= n), "cannot eliminate shared DAG leaves")
    for depth in range(explicit_depth):
        next_generation, table = [], {}
        for i in generation:
            _, total, suffix = states[i]
            kids = []
            for x in range(5):
                word = suffix + (x,)
                if memory is not None:
                    word = word[-memory:] if memory else ()
                state = (depth + 1, total + x, word)
                if state not in table:
                    idx = len(states)
                    require(idx < max_nodes, "verifier node limit exceeded")
                    table[state] = idx
                    states.append(state)
                    next_generation.append(idx)
                    total_columns += root_cap + 4 * (depth + 1) - (total + x) + 1
                    require(total_columns <= max_columns, "verifier column limit exceeded")
                kids.append(table[state])
            successors.append(kids)
        generation = next_generation
    successors.extend([[] for _ in generation])
    caps = [root_cap + 4 * t - s for t, s, _ in states]
    starts, count = [], 0
    for cap in caps:
        starts.append(count)
        count += cap + 1
    require(count == total_columns, "internal indexing error")
    cost = [0] * count
    if config["objective"] == "tail":
        cost.append(1)
    else:
        cost[:root_cap + 1] = list(range(root_cap + 1))
    require(len(cost) <= max_columns, "verifier column limit exceeded")

    def equalities():
        for start, cap in zip(starts, caps):
            yield [(start + j, 1) for j in range(cap + 1)], Fraction(1)
        # Direct coefficient equations at EACH s, independently of the builder's
        # sparse-matrix assembly and its exact-dual repair implementation.
        for i, kids in enumerate(successors):
            if not kids:
                continue
            for s in range(caps[i] + 5):
                terms = []
                for y, q in enumerate(Q64):
                    j = s - y
                    if 0 <= j <= caps[i]:
                        terms.append((starts[i] + j, q))
                for x, child in enumerate(kids):
                    j = s - x
                    if 0 <= j <= caps[child]:
                        terms.append((starts[child] + j, -P64[x]))
                yield terms, Fraction(0)
        for contact in config["contacts"]:
            history = contact["history"]
            require(isinstance(history, str) and history and len(history) <= explicit_depth
                    and all(c in "01234" for c in history), "invalid contact history")
            idx = 0
            for c in history:
                idx = successors[idx][int(c)]
            yield [(starts[idx] + j, j) for j in range(1, caps[idx] + 1)], Fraction(contact["mean"])
        if config["profile_lambda"] is not None:
            lam = Fraction(config["profile_lambda"])
            for j in range(root_cap + 1):
                mass = (lam / ((j + lam) * (j + lam + 1)) if j < root_cap
                        else lam / (root_cap + lam))
                yield [(j, 1)], mass

    def inequalities():
        if config.get("leaf_reduction", False):
            for i in generation:
                for s in range(4):
                    terms = [(starts[i] + j, sum(Q64[y] for y in range(s - j + 1)))
                             for j in range(min(s, caps[i]) + 1)]
                    yield terms, Fraction(sum(P64[:s + 1]))
        if config["objective"] == "tail" or config["tail_cap"] is not None:
            for j in range(1, root_cap + 1):
                terms = [(k, j) for k in range(j, root_cap + 1)]
                if config["objective"] == "tail":
                    terms.append((count, -1))
                    rhs = Fraction(0)
                else:
                    rhs = Fraction(config["tail_cap"])
                yield terms, rhs
        if config["objective"] == "tail" and config["tail_cap"] is not None:
            yield [(count, 1)], Fraction(config["tail_cap"])
        if config["mean_budget"] is not None:
            yield [(j, j) for j in range(1, root_cap + 1)], Fraction(config["mean_budget"])

    unrestricted = (root_cap == 4 * n and (memory is None or memory >= n)
                    and not config["contacts"] and config["mean_budget"] is None
                    and config["tail_cap"] is None and config["profile_lambda"] is None)
    scope = ("unrestricted_B_n" if config["objective"] == "mean" else "unrestricted_A_n") if unrestricted else "restricted_finite_problem_only"
    rows = len(states) + sum(caps[i] + 5 for i in range(len(states)) if successors[i])
    rows += len(config["contacts"]) + (root_cap + 1 if config["profile_lambda"] is not None else 0)
    ub_rows = (root_cap if config["objective"] == "tail" or config["tail_cap"] is not None else 0)
    ub_rows += int(config["objective"] == "tail" and config["tail_cap"] is not None)
    ub_rows += int(config["mean_budget"] is not None)
    if config.get("leaf_reduction", False):
        ub_rows += 4 * len(generation)
    return cost, equalities, inequalities, scope, rows, ub_rows


def sparse_vector(entries, length, parser=int):
    require(type(length) is int and length >= 0, "bad vector length")
    out = [parser(0)] * length
    seen = set()
    for index, value in entries:
        require(type(index) is int and 0 <= index < length, "index out of range")
        require(index not in seen, "duplicate vector index")
        seen.add(index)
        out[index] = parser(value)
    return out


def terminal_children(law):
    """Reconstruct all five final laws by exact monotone quantile coupling.

    Input must be a probability vector of Fraction-compatible numbers satisfying
    the four final CDF constraints. This also provides executable semantics for
    a certificate that stores the tree only through depth n-1.
    """
    law = [Fraction(v) for v in law]
    require(law and min(law) >= 0 and sum(law) == 1, "invalid parent law")
    supply = [Fraction(0)] * (len(law) + 4)
    for j, mass in enumerate(law):
        for y in range(5):
            supply[j + y] += mass * Fraction(Q64[y], 64)
    p = [Fraction(v, 64) for v in P64]
    p_cdf = [Fraction(0)]
    for value in p:
        p_cdf.append(p_cdf[-1] + value)
    children = [[Fraction(0)] * (len(law) + 4 - x) for x in range(5)]
    left = Fraction(0)
    for s, mass in enumerate(supply):
        right = left + mass
        for x in range(5):
            overlap = max(Fraction(0), min(right, p_cdf[x + 1]) - max(left, p_cdf[x]))
            if overlap:
                require(s >= x, "final stochastic-dominance constraint failed")
                children[x][s - x] += overlap / p[x]
        left = right
    require(all(sum(child) == 1 for child in children), "terminal normalization failed")
    return children


def verify(path, max_columns=5000000, max_nodes=500000):
    cert = read_json(path)
    cost, eq, ub, scope, neq, nub = rebuild(cert["config"], max_columns, max_nodes)
    if cert["format"] == "reserve-dyadic-dual-v1":
        denominator = int(cert["denominator"])
        require(denominator > 0, "nonpositive denominator")
        require(cert["scope"] == scope, "false scope label")
        require(cert["y_length"] == neq and cert["v_length"] == nub, "dual dimension mismatch")
        y = sparse_vector(cert["y"], neq)
        v = sparse_vector(cert["v"], nub)
        require(all(k <= 0 for k in v), "inequality dual has wrong sign")
        reduced = [k * denominator for k in cost]
        value = Fraction(0)
        for i, (terms, rhs) in enumerate(eq()):
            value += rhs * y[i]
            if y[i]:
                for j, a in terms:
                    reduced[j] -= a * y[i]
        for i, (terms, rhs) in enumerate(ub()):
            value += rhs * v[i]
            if v[i]:
                for j, a in terms:
                    reduced[j] -= a * v[i]
        bad = next((j for j, rc in enumerate(reduced) if rc < 0), None)
        require(bad is None, f"negative exact reduced cost at column {bad}")
        value /= denominator
        require(value == Fraction(cert["objective_lower_bound"]), "wrong claimed dual objective")
        return {"status": "EXACT_DUAL_VERIFIED", "n": cert["config"]["n"],
                "objective": cert["config"]["objective"], "scope": scope,
                "lower_bound": str(value), "decimal_for_display_only": float(value),
                "columns": len(cost), "zero_reduced_costs": reduced.count(0)}
    if cert["format"] == "reserve-rational-primal-v1":
        require(cert["length"] == len(cost), "primal dimension mismatch")
        u = sparse_vector(cert["u"], len(cost), Fraction)
        require(all(k >= 0 for k in u), "negative primal variable")
        for i, (terms, rhs) in enumerate(eq()):
            require(sum((a * u[j] for j, a in terms), Fraction(0)) == rhs,
                    f"exact equality {i} failed")
        for i, (terms, rhs) in enumerate(ub()):
            require(sum((a * u[j] for j, a in terms), Fraction(0)) <= rhs,
                    f"exact inequality {i} failed")
        value = sum((c * x for c, x in zip(cost, u)), Fraction(0))
        require(value == Fraction(cert["objective_upper_bound"]), "wrong claimed primal objective")
        return {"status": "EXACT_PRIMAL_VERIFIED", "n": cert["config"]["n"],
                "objective": cert["config"]["objective"], "scope": scope,
                "upper_bound": str(value), "decimal_for_display_only": float(value),
                "columns": len(cost)}
    raise ValueError("unknown certificate format")


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("paths", type=Path, nargs="+")
    p.add_argument("--recursive", action="store_true")
    p.add_argument("--max-columns", type=int, default=5000000)
    p.add_argument("--max-nodes", type=int, default=500000)
    args = p.parse_args(argv)
    files = []
    for path in args.paths:
        if path.is_dir():
            files.extend(path.rglob("*_certificate.json.gz") if args.recursive
                         else path.glob("*_certificate.json.gz"))
        else:
            files.append(path)
    if not files:
        p.error("no certificate files found")
    failed = 0
    for path in sorted(set(files)):
        try:
            result = verify(path, args.max_columns, args.max_nodes)
            print(json.dumps({"file": str(path), **result}, ensure_ascii=False))
        except (ValueError, KeyError, TypeError, IndexError, OSError, ZeroDivisionError) as exc:
            failed += 1
            print(json.dumps({"file": str(path), "status": "REJECTED", "reason": str(exc)}))
    print(f"Verified {len(set(files)) - failed}; rejected {failed}. Exact arithmetic only.")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
