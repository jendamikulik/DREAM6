#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
DREAM6-ZR v0.17 — BACKWARD VIABILITY / FARKAS ORACLE
======================================================

Purpose
-------
Avoid the exponential finite-depth tree LP when deciding whether a root buffer
law can survive more levels.

Let E_0 be the leaf-admissible set. Recursively define

    E_{t+1} = { A : there exists one local coupling whose five child laws
                       all lie in E_t }.

Then a depth-r tree exists iff A_root in E_r.  This is exact: subtrees below
five children are conditionally independent once the child laws are fixed.

The local coupling is aggregated by s=j+y.  Variables are only

    F(s,x),   0 <= s <= M+4, 0 <= x <= 4, 0 <= s-x <= M,

45 variables for M=8.  The original Z(j,y,x,k) can be reconstructed from F
because k=s-x and all (j,y) with the same s have identical admissible x edges.

The oracle uses recursive cutting planes:
  * already-known valid cuts alpha.A <= beta for E_t are tested first;
  * a 45-variable local LP tests one-step feasibility against current E_{t-1}
    cuts;
  * recursively discovered child cuts are propagated upward;
  * if the local relaxation is infeasible, an always-feasible phase-I LP gives
    a Farkas/value-function separating cut for E_t.

E_1 is seeded with its independently closed four-facet H-representation.
Those four non-simplex facets were obtained from all 2^13 anti-diagonal
min-cuts; 187 of the 191 nontrivial subset inequalities are redundant on the
9-simplex.

Epistemic contract
------------------
* This script is a finite numerical polyhedral oracle, not a limit theorem.
* A phase-I deficit <= --boundary-tol may be accepted as a numerical-boundary
  witness. Such a run is explicitly labelled TOLERANCE_LEVEL, not exact.
* No O(log n) statement is made.
* The intended use is to obtain a cheap r=6 primal-feasibility anchor before
  running crossing-first separator certificates.
"""

from __future__ import annotations

import argparse
import itertools
import json
import math
import time
from collections import defaultdict
from pathlib import Path
from typing import Sequence

import numpy as np
from scipy.optimize import linprog
from scipy.sparse import coo_matrix

VERSION = "DREAM6_ZR_v0.19_PROOF_CARRYING_EXACT_DYADIC_FARKAS"

P = np.asarray([1 / 8, 1 / 4, 1 / 4, 1 / 4, 1 / 8], dtype=float)
Q = np.asarray([7 / 64, 5 / 16, 5 / 32, 5 / 16, 7 / 64], dtype=float)
B8 = np.asarray([
    0.53562333995590705,
    0.42450840479209673,
    0.039868255251995686,
], dtype=float)

M = 8
N = M + 1
SMAX = M + 4
EDGES = tuple(
    (s, x)
    for s in range(SMAX + 1)
    for x in range(5)
    if 0 <= s - x <= M
)
EIDX = {e: i for i, e in enumerate(EDGES)}
NE = len(EDGES)  # 45 for M=8

# R_A(s) = sum_j C[s,j] A(j) = (A*Q)(s)
CONV = np.zeros((SMAX + 1, N), dtype=float)
for s in range(SMAX + 1):
    for j in range(N):
        y = s - j
        if 0 <= y < len(Q):
            CONV[s, j] = float(Q[y])

# Local equality matrix for F(s,x): 13 source rows + columns x=0..3.
# The fifth x marginal is implied by total source mass 1 and sum P=1.
LOCAL_EQ = np.zeros((SMAX + 1 + 4, NE), dtype=float)
for s in range(SMAX + 1):
    for x in range(5):
        if (s, x) in EIDX:
            LOCAL_EQ[s, EIDX[(s, x)]] = 1.0
for x in range(4):
    for s in range(SMAX + 1):
        if (s, x) in EIDX:
            LOCAL_EQ[SMAX + 1 + x, EIDX[(s, x)]] = 1.0


def highs_options() -> dict:
    return {
        "dual_feasibility_tolerance": 1e-9,
        "primal_feasibility_tolerance": 1e-9,
        "ipm_optimality_tolerance": 1e-10,
    }


def build_antidiagonal_tree_lp(depth: int) -> dict:
    """Exact s=j+y aggregated tree LP, used only to obtain the r=5 root law."""
    internals = []
    for d in range(depth):
        internals.extend(itertools.product(range(5), repeat=d))
    internals = tuple(internals)
    leaves = tuple(itertools.product(range(5), repeat=depth))

    Foff = {h: N + i * NE for i, h in enumerate(internals)}
    nv = N + len(internals) * NE

    er, ec, ev, beq = [], [], [], []
    ur, uc, uv, bub = [], [], [], []

    def add_eq(entries, rhs):
        r = len(beq)
        for c, v in entries:
            if v != 0.0:
                er.append(r); ec.append(int(c)); ev.append(float(v))
        beq.append(float(rhs))

    def add_ub(entries, rhs):
        r = len(bub)
        for c, v in entries:
            if v != 0.0:
                ur.append(r); uc.append(int(c)); uv.append(float(v))
        bub.append(float(rhs))

    add_eq([(j, 1.0) for j in range(N)], 1.0)

    by_s = {
        s: [EIDX[(s, x)] for x in range(5) if (s, x) in EIDX]
        for s in range(SMAX + 1)
    }
    by_x = {
        x: [EIDX[(s, x)] for s in range(SMAX + 1) if (s, x) in EIDX]
        for x in range(5)
    }

    for h in internals:
        fo = Foff[h]
        for s in range(SMAX + 1):
            row = [(fo + i, 1.0) for i in by_s[s]]
            if h == ():
                for j in range(N):
                    y = s - j
                    if 0 <= y < len(Q):
                        row.append((j, -float(Q[y])))
            else:
                parent = h[:-1]
                xin = int(h[-1])
                pfo = Foff[parent]
                px = float(P[xin])
                row = [(c, px * v) for c, v in row]
                for j in range(N):
                    y = s - j
                    if 0 <= y < len(Q) and (j + xin, xin) in EIDX:
                        row.append((pfo + EIDX[(j + xin, xin)], -float(Q[y])))
            add_eq(row, 0.0)

        for x in range(5):
            add_eq([(fo + i, 1.0) for i in by_x[x]], float(P[x]))

    cdf = np.cumsum(B8)
    for h in leaves:
        parent = h[:-1]
        xin = int(h[-1])
        fo = Foff[parent]
        px = float(P[xin])
        add_ub([(fo + EIDX[(xin, xin)], 1.0)], px * float(cdf[0]))
        row = [(fo + EIDX[(xin, xin)], 1.0)]
        if (xin + 1, xin) in EIDX:
            row.append((fo + EIDX[(xin + 1, xin)], 1.0))
        add_ub(row, px * float(cdf[1]))

    Aeq = coo_matrix((ev, (er, ec)), shape=(len(beq), nv)).tocsr()
    Aub = coo_matrix((uv, (ur, uc)), shape=(len(bub), nv)).tocsr()
    obj = np.zeros(nv, dtype=float)
    obj[:N] = np.arange(N, dtype=float)
    return {
        "Aeq": Aeq, "beq": np.asarray(beq),
        "Aub": Aub, "bub": np.asarray(bub),
        "objective": obj, "bounds": [(0.0, None)] * nv,
        "nv": nv,
    }


def solve_reference_root(depth: int, time_limit: float) -> tuple[np.ndarray, float, dict]:
    lp = build_antidiagonal_tree_lp(depth)
    opts = highs_options()
    if time_limit > 0:
        opts["time_limit"] = float(time_limit)
    t0 = time.time()
    res = linprog(
        lp["objective"],
        A_ub=lp["Aub"], b_ub=lp["bub"],
        A_eq=lp["Aeq"], b_eq=lp["beq"],
        bounds=lp["bounds"],
        method="highs-ipm", options=opts,
    )
    sec = time.time() - t0
    if not res.success:
        raise RuntimeError(f"reference root solve failed: {res.message}")
    root = np.asarray(res.x[:N], dtype=float)
    return root, float(res.fun), {
        "depth": int(depth),
        "variables": int(lp["nv"]),
        "eq": int(lp["Aeq"].shape[0]),
        "ub": int(lp["Aub"].shape[0]),
        "seconds": float(sec),
        "objective": float(res.fun),
        "root": root.tolist(),
    }



from dataclasses import dataclass
from fractions import Fraction


def FQ(x) -> Fraction:
    if isinstance(x, Fraction):
        return x
    if isinstance(x, (int, np.integer)):
        return Fraction(int(x), 1)
    return Fraction.from_float(float(x))


def fq_pair(q: Fraction):
    return [str(q.numerator), str(q.denominator)]


def fq_from_pair(v):
    return Fraction(int(v[0]), int(v[1]))


P_EX = tuple(FQ(x) for x in P)
Q_EX = tuple(FQ(x) for x in Q)
B8_EX = tuple(FQ(x) for x in B8)


@dataclass
class CutRec:
    cid: str
    level: int
    alpha: np.ndarray
    beta: float
    label: str
    exact_alpha: tuple[Fraction, ...]
    exact_beta: Fraction
    proof: dict


class Oracle:
    """Proof-carrying backward viability oracle.

    Every generated cut is stored immutably in ``all_cuts``.  ``cache[level]``
    contains only the currently active cut IDs at that level.  A strengthened
    cut replaces the active ID but the old record remains available for any
    already-created ancestry edge.

    The exact proof object uses the exact binary64 rationals of the numerical
    dual multipliers, followed by an exact source-dual repair.  Hence every cut
    admitted to the cache is an exact rational Farkas consequence of its
    referenced child cuts for the exact dyadic data used by this program.
    """
    def __init__(self, args):
        self.args = args
        self.cache: dict[int, list[str]] = defaultdict(list)
        self.all_cuts: dict[str, CutRec] = {}
        self.stats = defaultdict(int)
        self.boundary_accepts = 0
        self.max_boundary_phi = 0.0
        self.total_cut_changes = 0
        self.next_id = defaultdict(int)
        self._seed_exact_levels()
        self._load_checkpoint()

    def _new_id(self, level: int) -> str:
        n = self.next_id[level]
        self.next_id[level] += 1
        return f"E{level}_C{n:06d}"

    def _put_seed(self, level: int, cid: str, alpha_ex, beta_ex, label: str, proof: dict):
        ae = tuple(FQ(x) for x in alpha_ex)
        be = FQ(beta_ex)
        rec = CutRec(
            cid=cid, level=level,
            alpha=np.asarray([float(x) for x in ae], float),
            beta=float(be), label=label,
            exact_alpha=ae, exact_beta=be, proof=proof,
        )
        self.all_cuts[cid] = rec
        self.cache[level].append(cid)
        self.next_id[level] = max(self.next_id[level], len(self.cache[level]))

    def _seed_exact_levels(self):
        c0 = B8_EX[0]
        c1 = B8_EX[0] + B8_EX[1]
        self._put_seed(
            0, "E0_CDF0",
            [1,0,0,0,0,0,0,0,0], c0, "E0_CDF0",
            {"type":"terminal_axiom", "meaning":"A0 <= B8[0]"},
        )
        self._put_seed(
            0, "E0_CDF1",
            [1,1,0,0,0,0,0,0,0], c1, "E0_CDF1",
            {"type":"terminal_axiom", "meaning":"A0+A1 <= B8[0]+B8[1]"},
        )
        # Four exact Hall/min-cut consequences of E0.  Their subset labels
        # encode the source anti-diagonals used in the finite cut.
        self._put_seed(
            1, "E1_R01",
            [Fraction(27,64),Fraction(7,64),0,0,0,0,0,0,0],
            P_EX[1]*c0 + P_EX[0]*c1,
            "E1_R01",
            {"type":"exact_hall_cut", "source_subset":[0,1],
             "capacity":"P1*c0 + P0*c1"},
        )
        self._put_seed(
            1, "E1_R0_4",
            [1,Fraction(57,64),Fraction(37,64),Fraction(27,64),Fraction(7,64),0,0,0,0],
            P_EX[0]+P_EX[1]+P_EX[2]+P_EX[3]*c1+P_EX[4]*c0,
            "E1_R0_4",
            {"type":"exact_hall_cut", "source_subset":[0,1,2,3,4],
             "capacity":"P0+P1+P2+P3*c1+P4*c0"},
        )
        self._put_seed(
            1, "E1_R0_5",
            [1,1,Fraction(57,64),Fraction(37,64),Fraction(27,64),Fraction(7,64),0,0,0],
            P_EX[0]+P_EX[1]+P_EX[2]+P_EX[3]+P_EX[4]*c1,
            "E1_R0_5",
            {"type":"exact_hall_cut", "source_subset":[0,1,2,3,4,5],
             "capacity":"P0+P1+P2+P3+P4*c1"},
        )
        self._put_seed(
            1, "E1_R11_12",
            [0,0,0,0,0,0,0,Fraction(7,64),Fraction(27,64)],
            P_EX[3]+P_EX[4],
            "E1_R11_12",
            {"type":"exact_hall_cut", "source_subset":[11,12],
             "capacity":"P3+P4"},
        )

    def _rec(self, cid: str) -> CutRec:
        return self.all_cuts[cid]

    def _rows(self, level: int):
        return [self._rec(cid) for cid in self.cache[level]]

    @staticmethod
    def _canon(alpha: np.ndarray, beta: float):
        n = max(float(np.max(np.abs(alpha))), 1e-15)
        return np.asarray(alpha, float) / n, float(beta) / n

    def _add_exact_cut(self, rec: CutRec) -> str:
        ca, cb = self._canon(rec.alpha, rec.beta)
        active = self.cache[rec.level]
        for i, cid in enumerate(active):
            old = self._rec(cid)
            xa, xb = self._canon(old.alpha, old.beta)
            if float(np.max(np.abs(xa-ca))) < float(self.args.cut_direction_tol):
                if cb < xb - float(self.args.cut_rhs_tol):
                    self.all_cuts[rec.cid] = rec
                    active[i] = rec.cid
                    self._cut_changed()
                    return "strengthened"
                return "duplicate"
        self.all_cuts[rec.cid] = rec
        active.append(rec.cid)
        self._cut_changed()
        return "added"

    def _cut_changed(self):
        self.total_cut_changes += 1
        n = int(self.args.checkpoint_every_cuts)
        if n > 0 and self.total_cut_changes % n == 0:
            self.save_checkpoint(status="IN_PROGRESS")

    def _load_checkpoint(self):
        p = Path(self.args.checkpoint)
        if not p.exists() or not self.args.resume:
            return
        try:
            obj = json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            return
        if obj.get("version") != VERSION:
            print(f"[checkpoint] ignored incompatible checkpoint version in {p}", flush=True)
            return
        # Replace generated levels by serialized immutable proof records.
        self.all_cuts = {}
        self.cache = defaultdict(list)
        self.next_id = defaultdict(int)
        for r in obj.get("all_cuts", []):
            rec = CutRec(
                cid=r["id"], level=int(r["level"]),
                alpha=np.asarray(r["alpha"], float), beta=float(r["beta"]),
                label=str(r["label"]),
                exact_alpha=tuple(fq_from_pair(x) for x in r["exact_alpha"]),
                exact_beta=fq_from_pair(r["exact_beta"]),
                proof=r.get("proof", {}),
            )
            self.all_cuts[rec.cid] = rec
            if rec.cid.startswith(f"E{rec.level}_C"):
                try:
                    n=int(rec.cid.rsplit("C",1)[1])+1
                    self.next_id[rec.level]=max(self.next_id[rec.level],n)
                except Exception:
                    pass
        for ks, ids in obj.get("active_cache", {}).items():
            self.cache[int(ks)] = list(ids)
        self.boundary_accepts = int(obj.get("boundary_accepts",0))
        self.max_boundary_phi = float(obj.get("max_boundary_phi",0.0))
        for k,v in obj.get("stats",{}).items(): self.stats[k]=int(v)
        print(f"[checkpoint] resumed exact proof ledger {p} cut-counts={self.cut_counts()}", flush=True)

    def cut_counts(self):
        return {str(k): len(v) for k,v in sorted(self.cache.items())}

    def _serialize_cut(self, rec: CutRec):
        return {
            "id":rec.cid, "level":rec.level,
            "alpha":rec.alpha.tolist(), "beta":rec.beta, "label":rec.label,
            "exact_alpha":[fq_pair(x) for x in rec.exact_alpha],
            "exact_beta":fq_pair(rec.exact_beta),
            "proof":rec.proof,
        }

    def save_checkpoint(self, status: str, extra: dict|None=None):
        data={
            "version":VERSION, "status":status,
            "active_cache":{str(k):list(v) for k,v in sorted(self.cache.items())},
            "all_cuts":[self._serialize_cut(r) for r in self.all_cuts.values()],
            "cut_counts":self.cut_counts(),
            "boundary_accepts":self.boundary_accepts,
            "max_boundary_phi":self.max_boundary_phi,
            "stats":{str(k):int(v) for k,v in self.stats.items()},
        }
        if extra: data.update(extra)
        Path(self.args.checkpoint).write_text(json.dumps(data,indent=2),encoding="utf-8")

    def _direct_cut(self, level: int, A: np.ndarray):
        rows=self._rows(level)
        if not rows: return None
        vals=[(float(r.alpha@A-r.beta),r) for r in rows]
        worst=max(vals,key=lambda z:z[0])
        if worst[0] > float(self.args.oracle_tol): return worst
        return None

    def _child_ub(self, child_recs):
        if not child_recs: return None,None,[]
        G=[];h=[];refs=[]
        for x in range(5):
            px=float(P[x])
            for rec in child_recs:
                row=np.zeros(NE,float)
                for k in range(N):
                    s=k+x
                    if (s,x) in EIDX: row[EIDX[(s,x)]]=rec.alpha[k]
                G.append(row);h.append(px*rec.beta);refs.append((x,rec.cid))
        return np.asarray(G),np.asarray(h),refs

    def _exact_local(self,A,child_recs):
        G,h,_=self._child_ub(child_recs)
        d=np.concatenate([CONV@A,P[:4]])
        return linprog(np.zeros(NE),A_ub=G,b_ub=h,A_eq=LOCAL_EQ,b_eq=d,
                       bounds=[(0,None)]*NE,method="highs",options=highs_options())

    def _phase1(self,A,child_recs):
        G,h,refs=self._child_ub(child_recs)
        ni=0 if G is None else int(G.shape[0]); neq=int(LOCAL_EQ.shape[0])
        nv=NE+2*neq+ni
        c=np.zeros(nv); c[NE:NE+2*neq]=1.0
        if ni: c[NE+2*neq:]=1.0
        Aeq=np.zeros((neq,nv)); Aeq[:,:NE]=LOCAL_EQ
        Aeq[:,NE:NE+neq]=np.eye(neq); Aeq[:,NE+neq:NE+2*neq]=-np.eye(neq)
        d=np.concatenate([CONV@A,P[:4]])
        if ni:
            Aub=np.zeros((ni,nv)); Aub[:,:NE]=G; Aub[:,NE+2*neq:]=-np.eye(ni); bub=h
        else: Aub=None;bub=None
        res=linprog(c,A_ub=Aub,b_ub=bub,A_eq=Aeq,b_eq=d,
                    bounds=[(0,None)]*nv,method="highs",options=highs_options())
        return res, refs

    def _make_exact_farkas_cut(self, level:int, A:np.ndarray, ph, refs, child_recs, phi:float):
        neq=int(LOCAL_EQ.shape[0])
        y=[FQ(v) for v in np.asarray(ph.eqlin.marginals,float)]
        pi_raw=np.asarray(ph.ineqlin.marginals,float)
        # Map child id -> exact record for fast lookup.
        cmap={r.cid:r for r in child_recs}
        pis=[]
        drop=float(getattr(self.args,"proof_pi_drop",0.0))
        for q,(x,cid) in zip(pi_raw,refs):
            q=float(q)
            if q < -drop:
                pis.append([int(x),cid,FQ(q)])
        # Exact reduced costs of the real transport variables F(s,x).
        def reduced(s,x):
            r=y[s]
            if x<4: r += y[SMAX+1+x]
            k=s-x
            for xx,cid,q in pis:
                if xx==x:
                    r += q*cmap[cid].exact_alpha[k]
            return r
        red=[]
        for s,x in EDGES: red.append(reduced(s,x))
        rmax=max([Fraction(0,1)]+red)
        # Exact repair: subtract rmax from every source equality multiplier.
        # Each F-edge sees exactly one source row, so all reduced costs become <=0.
        if rmax>0:
            for s in range(SMAX+1): y[s]-=rmax
        # Recheck exactly.
        red2=[]
        for s,x in EDGES:
            r=y[s]
            if x<4: r += y[SMAX+1+x]
            k=s-x
            for xx,cid,q in pis:
                if xx==x: r += q*cmap[cid].exact_alpha[k]
            red2.append(r)
        if max(red2)>0:
            raise RuntimeError("exact Farkas repair failed")
        # Parent cut alpha.A <= beta.
        alpha=[]
        for j in range(N):
            z=Fraction(0,1)
            for s in range(SMAX+1):
                yy=s-j
                if 0<=yy<len(Q_EX): z += Q_EX[yy]*y[s]
            alpha.append(z)
        const=sum(P_EX[x]*y[SMAX+1+x] for x in range(4))
        for x,cid,q in pis:
            const += q*P_EX[x]*cmap[cid].exact_beta
        beta=-const
        af=np.asarray([float(z) for z in alpha],float); bf=float(beta)
        cid=self._new_id(level)
        proof={
            "type":"exact_dyadic_farkas",
            "phase1_phi_float":float(phi),
            "generating_root_float":np.asarray(A,float).tolist(),
            "source_repair_delta":fq_pair(rmax),
            "y":[fq_pair(z) for z in y],
            "pi":[{"x":x,"child":cc,"value":fq_pair(q)} for x,cc,q in pis],
            "max_exact_reduced_cost":fq_pair(max(red2)),
            "parent_count":len({cc for _x,cc,_q in pis}),
            "nonzero_pi_count":len(pis),
        }
        rec=CutRec(cid=cid,level=level,alpha=af,beta=bf,
                   label=f"EXACT_FARKAS_E{level}_phi={phi:.3e}",
                   exact_alpha=tuple(alpha),exact_beta=beta,proof=proof)
        # Exact validity is already checked.  Also record separation at generation.
        proof["generating_violation_float"] = float(af@A-bf)
        return rec

    def verify_cut_exact(self,cid:str) -> tuple[bool,str]:
        rec=self._rec(cid)
        typ=rec.proof.get("type")
        if typ == "terminal_axiom":
            return True,"terminal axiom"
        if typ == "exact_hall_cut":
            S=set(int(z) for z in rec.proof.get("source_subset",[]))
            # LHS is exactly sum_{s in S} R_A(s).
            aa=[]
            for j in range(N):
                z=Fraction(0,1)
                for ss in S:
                    yy=ss-j
                    if 0<=yy<len(Q_EX): z += Q_EX[yy]
                aa.append(z)
            c0=B8_EX[0]; c1=B8_EX[0]+B8_EX[1]
            cap=Fraction(0,1)
            for x in range(5):
                K={ss-x for ss in S if 0<=ss-x<=M}
                if not K:
                    cx=Fraction(0,1)
                elif any(k>=2 for k in K):
                    cx=Fraction(1,1)
                elif K=={0}:
                    cx=c0
                else:
                    # {1} or {0,1}
                    cx=c1
                cap += P_EX[x]*cx
            if tuple(aa)!=rec.exact_alpha: return False,"Hall alpha mismatch"
            if cap!=rec.exact_beta: return False,"Hall capacity mismatch"
            return True,"exact Hall cut"
        if typ!="exact_dyadic_farkas": return False,"unknown proof type"
        y=[fq_from_pair(z) for z in rec.proof["y"]]
        pis=[(int(z["x"]),z["child"],fq_from_pair(z["value"])) for z in rec.proof["pi"]]
        cmap={cc:self._rec(cc) for _x,cc,_q in pis}
        for x,cc,q in pis:
            if q>0: return False,"positive pi"
            if self._rec(cc).level != rec.level-1: return False,"wrong child level"
        red=[]
        for s,x in EDGES:
            r=y[s]
            if x<4:r+=y[SMAX+1+x]
            k=s-x
            for xx,cc,q in pis:
                if xx==x:r+=q*cmap[cc].exact_alpha[k]
            red.append(r)
        if max(red)>0:return False,f"positive reduced cost {float(max(red))}"
        alpha=[]
        for j in range(N):
            z=Fraction(0,1)
            for s in range(SMAX+1):
                yy=s-j
                if 0<=yy<len(Q_EX):z+=Q_EX[yy]*y[s]
            alpha.append(z)
        const=sum(P_EX[x]*y[SMAX+1+x] for x in range(4))
        for x,cc,q in pis:const+=q*P_EX[x]*cmap[cc].exact_beta
        if tuple(alpha)!=rec.exact_alpha:return False,"alpha identity mismatch"
        if -const!=rec.exact_beta:return False,"beta identity mismatch"
        return True,"ok"

    def separate(self,level:int,A:np.ndarray,path=()):
        self.stats[f"calls_E{level}"]+=1; A=np.asarray(A,float)
        direct=self._direct_cut(level,A)
        if direct is not None:
            _v,r=direct; return False,(r.alpha,r.beta,r.label,r.cid)
        if level<=1:return True,None
        for _loop in range(int(self.args.max_local_loops)):
            self.stats[f"loops_E{level}"]+=1
            child=self._rows(level-1)
            res=self._exact_local(A,child);self.stats[f"exact_lp_E{level}"]+=1
            if not res.success:
                ph,refs=self._phase1(A,child);self.stats[f"phase1_E{level}"]+=1
                if not ph.success:
                    return None,{"status":"UNRESOLVED__PHASE1_FAILED","level":level,"path":list(path),"message":ph.message}
                phi=float(ph.fun)
                if phi<=float(self.args.boundary_tol):
                    self.boundary_accepts+=1;self.max_boundary_phi=max(self.max_boundary_phi,phi)
                    self.stats[f"boundary_accept_E{level}"]+=1;return True,None
                rec=self._make_exact_farkas_cut(level,A,ph,refs,child,phi)
                ok,msg=self.verify_cut_exact(rec.cid) if rec.cid in self.all_cuts else (True,"pre-add")
                # verify after temporarily registering immutable record
                if rec.cid not in self.all_cuts:self.all_cuts[rec.cid]=rec
                ok,msg=self.verify_cut_exact(rec.cid)
                if not ok:raise RuntimeError(f"exact cut verification failed: {msg}")
                # remove before dedupe add; _add_exact_cut will restore if used
                self.all_cuts.pop(rec.cid,None)
                how=self._add_exact_cut(rec);self.stats[f"cut_{how}_E{level}"]+=1
                if how=="duplicate":
                    # A duplicate direction may already exclude the point; return it.
                    d=self._direct_cut(level,A)
                    if d is not None:
                        _v,rr=d;return False,(rr.alpha,rr.beta,rr.label,rr.cid)
                    return None,{"status":"UNRESOLVED__EXACT_CUT_DUPLICATE_NOT_SEPARATING","level":level}
                return False,(rec.alpha,rec.beta,rec.label,rec.cid)
            F=np.asarray(res.x,float);restart=False
            for x in range(5):
                law=np.zeros(N,float)
                for k in range(N):
                    s=k+x
                    if (s,x) in EIDX:law[k]=F[EIDX[(s,x)]]/float(P[x])
                before=self.total_cut_changes
                ok,info=self.separate(level-1,law,path+(x,))
                if ok is None:return None,info
                if not ok:
                    # recursive oracle has already placed the proof-carrying cut in cache
                    if self.total_cut_changes>before:
                        restart=True;break
                    # direct existing child cut also means current local relaxation must restart
                    restart=True;break
            if restart:continue
            return True,None
        return None,{"status":"UNRESOLVED__LOCAL_CUT_LOOP_LIMIT","level":level,"path":list(path)}

def tight_master_options():
    return {
        "primal_feasibility_tolerance": 1e-10,
        "dual_feasibility_tolerance": 1e-10,
        "ipm_optimality_tolerance": 1e-10,
    }


def collect_target_outer_cuts(oracle: Oracle, target_level: int):
    """Root master uses ONLY cuts valid for E_target.

    E_t is a backward viability set with terminal condition applied after t
    remaining steps.  In general E_{t+1} is NOT a subset of E_t, so cuts from
    lower levels must never be imposed directly on the target root.  They are
    used only inside the recursive oracle to constrain child laws.
    """
    rows = []
    for cid in oracle.cache.get(int(target_level), []):
        r = oracle._rec(cid)
        rows.append((int(target_level), np.asarray(r.alpha, float), float(r.beta), str(r.label), r.cid))
    return rows


def solve_root_master(oracle: Oracle, target_level: int, method: str = "highs-ds"):
    rows = collect_target_outer_cuts(oracle, target_level)
    Aub = np.vstack([a for _lev, a, _b, _l, _cid in rows]) if rows else None
    bub = np.asarray([b for _lev, _a, b, _l, _cid in rows], float) if rows else None
    c = np.arange(N, dtype=float)
    res = linprog(
        c,
        A_ub=Aub, b_ub=bub,
        A_eq=np.ones((1, N), dtype=float), b_eq=np.asarray([1.0]),
        bounds=[(0.0, None)] * N,
        method=method, options=tight_master_options(),
    )
    if not res.success:
        return res, rows, None

    mu = np.asarray(res.ineqlin.marginals, dtype=float) if rows else np.zeros(0)
    lam = np.asarray(res.eqlin.marginals, dtype=float)
    lower = np.asarray(res.lower.marginals, dtype=float)
    upper = np.asarray(res.upper.marginals, dtype=float)
    A_mat = Aub if Aub is not None else np.zeros((0, N))
    stat = c - A_mat.T @ mu - np.ones(N) * lam[0] - lower + upper
    dual_value = float((bub @ mu if rows else 0.0) + lam[0])
    primal = float(res.fun)
    max_ub = float(max(0.0, np.max(A_mat @ res.x - bub))) if rows else 0.0
    eq_err = float(abs(np.sum(res.x) - 1.0))

    active = []
    if rows:
        slacks = np.asarray(res.ineqlin.residual, dtype=float)
        for (lev, a, b, label, cid), mui, slack in zip(rows, mu, slacks):
            w = -float(mui)
            if w > 1e-10:
                active.append({
                    "level": int(lev),
                    "label": label,
                    "cut_id": cid,
                    "weight": w,
                    "beta": float(b),
                    "alpha": np.asarray(a, float).tolist(),
                    "slack": float(slack),
                })

    audit = {
        "primal_value": primal,
        "dual_value": dual_value,
        "primal_dual_gap": float(primal - dual_value),
        "stationarity_inf": float(np.max(np.abs(stat))),
        "max_ub_violation": max_ub,
        "simplex_eq_error": eq_err,
        "lambda_simplex": float(lam[0]),
        "active_cut_count": len(active),
        "active_cuts": active,
    }
    return res, rows, audit



def exact_master_dual_certificate(oracle: Oracle, audit: dict):
    active = audit.get("active_cuts", []) if audit else []
    terms=[]
    for row in active:
        cid=row.get("cut_id")
        if cid is None:
            raise RuntimeError("active master cut missing proof ID")
        rec=oracle._rec(cid)
        w=FQ(float(row["weight"]))
        if w<0: raise RuntimeError("negative master weight")
        terms.append((w,rec))
    coord=[]
    for j in range(N):
        z=Fraction(j,1)
        for w,r in terms: z += w*r.exact_alpha[j]
        coord.append(z)
    lam=min(coord) if coord else Fraction(0,1)
    lb=lam-sum((w*r.exact_beta for w,r in terms),Fraction(0,1))
    roots=[r.cid for _w,r in terms]
    # ancestry closure and exact verification
    seen=set(); stack=list(roots); bad=[]
    while stack:
        cid=stack.pop()
        if cid in seen: continue
        seen.add(cid)
        ok,msg=oracle.verify_cut_exact(cid)
        if not ok: bad.append([cid,msg])
        rec=oracle._rec(cid)
        if rec.proof.get("type")=="exact_dyadic_farkas":
            for pr in rec.proof.get("pi",[]): stack.append(pr["child"])
    return {
        "valid": len(bad)==0,
        "active_cut_ids": roots,
        "ancestry_cut_count": len(seen),
        "bad_nodes": bad,
        "lambda_exact": fq_pair(lam),
        "lower_bound_exact": fq_pair(lb),
        "lambda_decimal": float(lam),
        "lower_bound_decimal": float(lb),
        "coordinate_slacks_exact": [fq_pair(z-lam) for z in coord],
        "weights_exact": [
            {"cut_id":r.cid,"weight":fq_pair(w),"weight_decimal":float(w)}
            for w,r in terms
        ],
    }

def main():
    ap = argparse.ArgumentParser(description="DREAM6-ZR v0.18 root cutting-plane scale-gap decider")
    ap.add_argument("--reference-depth", type=int, default=5)
    ap.add_argument("--target-depth", type=int, default=6)
    ap.add_argument("--reference-time-limit", type=float, default=180.0)
    ap.add_argument("--oracle-tol", type=float, default=2e-8)
    ap.add_argument("--boundary-tol", type=float, default=1e-8)
    ap.add_argument("--farkas-padding", type=float, default=1e-10)
    ap.add_argument("--cut-direction-tol", type=float, default=1e-7)
    ap.add_argument("--cut-rhs-tol", type=float, default=1e-9)
    ap.add_argument("--proof-pi-drop", type=float, default=0.0)
    ap.add_argument("--max-local-loops", type=int, default=2000)
    ap.add_argument("--checkpoint-every-cuts", type=int, default=25)
    ap.add_argument("--checkpoint", default="v018_scale_gap.checkpoint.json")
    ap.add_argument("--resume", action="store_true")
    ap.add_argument("--max-master-iterations", type=int, default=200)
    ap.add_argument("--scale-gap-tol", type=float, default=1e-8)
    ap.add_argument("--master-method", default="highs-ds", choices=["highs", "highs-ds", "highs-ipm"])
    ap.add_argument("--out", default="v018_scale_gap.json")
    args = ap.parse_args()

    print("="*124)
    print("DREAM6-ZR v0.19  PROOF-CARRYING EXACT-DYADIC FARKAS DECIDER")
    print("="*124)
    print(f"reference depth              : {args.reference_depth}")
    print(f"target viability depth       : {args.target_depth}")
    print(f"root dimension               : {N}")
    print(f"local variables per oracle   : {NE}")
    print(f"oracle / boundary tol        : {args.oracle_tol:g} / {args.boundary_tol:g}")
    print(f"master method                : {args.master_method}")
    print("="*124, flush=True)

    root5, value5, ref = solve_reference_root(args.reference_depth, args.reference_time_limit)
    print(
        f"[reference r={args.reference_depth}] v={value5:.15e} "
        f"vars={ref['variables']} eq={ref['eq']} ub={ref['ub']} sec={ref['seconds']:.3f}",
        flush=True,
    )

    oracle = Oracle(args)
    iterations = []
    final_status = "UNRESOLVED"
    final_master = None
    final_audit = None
    final_candidate = None
    final_member = None
    final_member_info = None
    final_boundary_delta = None

    for it in range(1, int(args.max_master_iterations) + 1):
        mres, rows, audit = solve_root_master(oracle, int(args.target_depth), args.master_method)
        if not mres.success:
            final_status = "UNRESOLVED__ROOT_MASTER_FAILED"
            iterations.append({"iteration": it, "master_success": False, "message": mres.message})
            break

        A = np.asarray(mres.x, dtype=float)
        lb = float(audit["dual_value"])
        before_cuts = oracle.total_cut_changes
        before_boundary = oracle.boundary_accepts
        t0 = time.time()
        ok, info = oracle.separate(int(args.target_depth), A)
        sec = time.time() - t0
        cut_delta = int(oracle.total_cut_changes - before_cuts)
        boundary_delta = int(oracle.boundary_accepts - before_boundary)

        rec = {
            "iteration": it,
            "master_lower_bound": lb,
            "master_primal": float(audit["primal_value"]),
            "candidate": A.tolist(),
            "oracle_member": None if ok is None else bool(ok),
            "oracle_seconds": float(sec),
            "new_cut_changes": cut_delta,
            "new_boundary_accepts": boundary_delta,
            "cut_counts": oracle.cut_counts(),
            "master_audit": audit,
        }
        iterations.append(rec)
        print(
            f"[master {it:03d}] LB={lb:.15e} oracle={ok} sec={sec:.3f} "
            f"newcuts={cut_delta} boundary+={boundary_delta} cuts={oracle.cut_counts()}",
            flush=True,
        )

        oracle.save_checkpoint(
            status=f"MASTER_{it}",
            extra={"last_master_iteration": rec},
        )

        if ok is None:
            final_status = "UNRESOLVED__ORACLE"
            final_member_info = info
            break
        if ok is True:
            final_master = mres
            final_audit = audit
            final_candidate = A
            final_member = True
            final_member_info = info
            final_boundary_delta = boundary_delta
            final_status = (
                "ROOT_MASTER_CANDIDATE_IN_TARGET_E__TOLERANCE_LEVEL"
                if boundary_delta > 0
                else "ROOT_MASTER_CANDIDATE_IN_TARGET_E__NUMERIC_EXACT_LP"
            )
            break
        if cut_delta == 0:
            # With tight master tolerances this should not happen.  Never spin on a
            # duplicate/direct cut and never interpret it as mathematical failure.
            final_status = "UNRESOLVED__ORACLE_REJECTED_WITHOUT_NEW_CUT"
            final_member_info = {
                "oracle_info": str(info),
                "candidate": A.tolist(),
                "master_audit": audit,
            }
            break
    else:
        final_status = "UNRESOLVED__MASTER_ITERATION_LIMIT"

    # Always solve once more with every generated cut so the reported lower bound
    # uses the final outer approximation, even if the last oracle call added a cut.
    fres, frows, faudit = solve_root_master(oracle, int(args.target_depth), args.master_method)
    if fres.success:
        final_lb = float(faudit["dual_value"])
        final_master_primal = float(faudit["primal_value"])
        final_root = np.asarray(fres.x, float)
    else:
        final_lb = None
        final_master_primal = None
        final_root = None

    scale_gap_lb = None if final_lb is None else float(final_lb - value5)
    exact_master_cert = exact_master_dual_certificate(oracle, faudit) if (fres.success and faudit is not None) else None
    positive_gap = bool(
        scale_gap_lb is not None and scale_gap_lb > float(args.scale_gap_tol)
    )

    if positive_gap:
        verdict = "NUMERIC_FARKAS_POSITIVE_SCALE_GAP_LOWER_BOUND"
    elif final_lb is not None:
        verdict = "NO_POSITIVE_SCALE_GAP_CERTIFIED"
    else:
        verdict = "UNRESOLVED__NO_FINAL_MASTER_BOUND"

    payload = {
        "version": VERSION,
        "parameters": vars(args),
        "reference": ref,
        "reference_value": float(value5),
        "reference_root": root5.tolist(),
        "iterations": iterations,
        "cut_counts": oracle.cut_counts(),
        "boundary_accepts_total": int(oracle.boundary_accepts),
        "max_boundary_phi": float(oracle.max_boundary_phi),
        "oracle_termination_status": final_status,
        "final_outer_master": {
            "success": bool(fres.success),
            "lower_bound_dual": final_lb,
            "primal_value": final_master_primal,
            "candidate_root": None if final_root is None else final_root.tolist(),
            "audit": faudit,
        },
        "scale_gap_lower_bound": scale_gap_lb,
        "exact_target_lower_bound_certificate": exact_master_cert,
        "positive_scale_gap_above_tolerance": positive_gap,
        "exact_proof_cut_count": len(oracle.all_cuts),
        "final_readout": verdict,
        "epistemic_contract": {
            "finite_numerical_Farkas_certificate_only": True,
            "root_master_uses_only_target_level_outer_cuts": True,
            "master_dual_value_is_reported_as_lower_bound": True,
            "boundary_accept_is_exact_certificate": False,
            "positive_gap_does_not_require_final_candidate_membership": True,
            "no_limit_theorem": True,
            "no_O_log_n_claim": True,
        },
    }
    Path(args.out).write_text(json.dumps(payload, indent=2), encoding="utf-8")
    oracle.save_checkpoint(status=verdict, extra={"result_file": args.out})

    print("="*124)
    print("FINAL ROOT CUTTING-PLANE LEDGER")
    print("="*124)
    print(f"reference v_{args.reference_depth}             : {value5:.15e}")
    print(f"target outer lower bound     : {final_lb if final_lb is not None else 'UNRESOLVED'}")
    print(f"scale-gap lower bound        : {scale_gap_lb if scale_gap_lb is not None else 'UNRESOLVED'}")
    if exact_master_cert is not None:
        print(f"exact dyadic target LB       : {exact_master_cert['lower_bound_decimal']:.15e}")
        print(f"exact ancestry cuts          : {exact_master_cert['ancestry_cut_count']} valid={exact_master_cert['valid']}")
    if faudit is not None:
        print(f"master primal-dual gap       : {faudit['primal_dual_gap']:.3e}")
        print(f"master stationarity inf      : {faudit['stationarity_inf']:.3e}")
        print(f"active dual cuts             : {faudit['active_cut_count']}")
        print(f"lambda simplex               : {faudit['lambda_simplex']:.15e}")
        for i, rec in enumerate(faudit['active_cuts'], 1):
            print(
                f"  dual[{i}] level={rec['level']} weight={rec['weight']:.15e} "
                f"beta={rec['beta']:.15e} label={rec['label']}"
            )
    print(f"oracle termination           : {final_status}")
    print(f"cut counts                   : {oracle.cut_counts()}")
    print(f"VERDICT                      : {verdict}")
    print("WROTE", Path(args.out).resolve())
    print("CHECKPOINT", Path(args.checkpoint).resolve())


if __name__ == "__main__":
    main()
