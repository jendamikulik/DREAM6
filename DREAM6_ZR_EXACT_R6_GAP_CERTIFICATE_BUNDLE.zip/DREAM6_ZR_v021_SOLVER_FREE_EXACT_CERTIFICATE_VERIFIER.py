#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""DREAM6-ZR v0.21 -- solver-free exact certificate verifier.

Uses only Python standard-library integer/rational arithmetic.  It verifies:
  1) the exact dyadic Farkas ancestry supporting the E6 lower bound;
  2) the exact rational depth-5 primal tree supporting the v5 upper bound;
  3) the strict rational inequality lower(E6) > upper(depth5).

No NumPy, SciPy, HiGHS, LP solver, or floating-point decision is used for
certificate validity.  Floats are used only for human-readable printing after
all exact Fraction comparisons are complete.
"""
from __future__ import annotations
import argparse
import itertools
import json
from fractions import Fraction
from pathlib import Path

VERSION = "DREAM6_ZR_v0.21_SOLVER_FREE_EXACT_CERTIFICATE_VERIFIER"
M=8; N=9; SMAX=12
P=(Fraction(1,8),Fraction(1,4),Fraction(1,4),Fraction(1,4),Fraction(1,8))
Q=(Fraction(7,64),Fraction(5,16),Fraction(5,32),Fraction(5,16),Fraction(7,64))
# Exact binary64 values used by v0.15--v0.20.
B8=tuple(Fraction.from_float(x) for x in (
    0.53562333995590705,
    0.42450840479209673,
    0.039868255251995686,
))
EDGES=tuple((s,x) for s in range(SMAX+1) for x in range(5) if 0<=s-x<=M)

def QP(v): return Fraction(int(v[0]),int(v[1]))
def pair(q): return [str(q.numerator),str(q.denominator)]
def hist_key(h): return ",".join(str(x) for x in h)

def verify_hall(rec):
    S=set(int(z) for z in rec['proof']['source_subset'])
    alpha=[]
    for j in range(N):
        z=Fraction(0)
        for s in S:
            y=s-j
            if 0<=y<len(Q): z+=Q[y]
        alpha.append(z)
    c0=B8[0]; c1=B8[0]+B8[1]
    beta=Fraction(0)
    for x in range(5):
        K={s-x for s in S if 0<=s-x<=M}
        if not K: cap=Fraction(0)
        elif any(k>=2 for k in K): cap=Fraction(1)
        elif K=={0}: cap=c0
        else: cap=c1
        beta+=P[x]*cap
    return tuple(alpha),beta

def verify_lower(path):
    obj=json.loads(Path(path).read_text(encoding='utf-8'))
    cuts={r['id']:r for r in obj['cuts']}
    exact={}
    # Order by level so child records are ready first.
    for cid,rec in sorted(cuts.items(),key=lambda kv:(int(kv[1]['level']),kv[0])):
        level=int(rec['level']); ae=tuple(QP(z) for z in rec['exact_alpha']); be=QP(rec['exact_beta'])
        typ=rec.get('proof',{}).get('type')
        if typ=='exact_hall_cut':
            aa,bb=verify_hall(rec)
            assert aa==ae, f'{cid}: Hall alpha mismatch'
            assert bb==be, f'{cid}: Hall beta mismatch'
        elif typ=='terminal_axiom':
            pass
        elif typ=='exact_dyadic_farkas':
            y=[QP(z) for z in rec['proof']['y']]
            pis=[]
            for p in rec['proof'].get('pi',[]):
                q=QP(p['value']); child=p['child']; x=int(p['x'])
                assert q<=0, f'{cid}: positive pi'
                assert child in exact, f'{cid}: missing child {child}'
                assert int(cuts[child]['level'])==level-1, f'{cid}: child level mismatch'
                pis.append((x,child,q))
            # exact reduced costs L^T y + G^T pi <= 0
            for s,x in EDGES:
                r=y[s]
                if x<4: r+=y[SMAX+1+x]
                k=s-x
                for xx,child,q in pis:
                    if xx==x: r+=q*exact[child][0][k]
                assert r<=0, f'{cid}: positive exact reduced cost {r}'
            aa=[]
            for j in range(N):
                z=Fraction(0)
                for s in range(SMAX+1):
                    yy=s-j
                    if 0<=yy<len(Q): z+=Q[yy]*y[s]
                aa.append(z)
            const=sum(P[x]*y[SMAX+1+x] for x in range(4))
            for x,child,q in pis: const+=q*P[x]*exact[child][1]
            bb=-const
            assert tuple(aa)==ae, f'{cid}: Farkas alpha identity mismatch'
            assert bb==be, f'{cid}: Farkas beta identity mismatch'
        else:
            raise AssertionError(f'{cid}: unsupported proof type {typ!r}')
        exact[cid]=(ae,be)
    # Exact master dual.
    terms=[]
    for t in obj['master_terms']:
        w=QP(t['weight']); cid=t['cut']; assert w>=0 and cid in exact
        terms.append((w,cid))
    coords=[]
    for j in range(N):
        z=Fraction(j)
        for w,cid in terms: z+=w*exact[cid][0][j]
        coords.append(z)
    lam=min(coords)
    lb=lam-sum((w*exact[cid][1] for w,cid in terms),Fraction(0))
    stored=QP(obj['exact_lower_bound'])
    assert lb==stored, 'stored exact lower bound mismatch'
    return {'lower':lb,'cut_count':len(cuts),'active_terms':len(terms),'lambda':lam}

def parse_flow_map(raw):
    out={}
    for k,v in raw.items():
        s,x=(int(z) for z in k.split(','));out[s,x]=QP(v)
    return out

def conv(A,s):
    z=Fraction(0)
    for j in range(N):
        y=s-j
        if 0<=y<len(Q):z+=A[j]*Q[y]
    return z

def verify_upper(path):
    obj=json.loads(Path(path).read_text(encoding='utf-8'))
    depth=int(obj['depth']); assert depth==5
    root=tuple(QP(z) for z in obj['root'])
    assert len(root)==N and all(z>=0 for z in root) and sum(root)==1
    cost=sum(Fraction(j)*root[j] for j in range(N))
    assert cost==QP(obj['exact_cost']), 'root cost mismatch'
    rawflows=obj['flows']
    laws={():root}
    internal_count=0
    for d in range(depth):
        for h in itertools.product(range(5),repeat=d):
            A=laws[h]; key=hist_key(h)
            assert key in rawflows, f'missing flow for {h}'
            F=parse_flow_map(rawflows[key]); internal_count+=1
            assert set(F)==set(EDGES), f'{h}: wrong edge set'
            assert all(q>=0 for q in F.values()), f'{h}: negative flow'
            # source anti-diagonal masses
            for s in range(SMAX+1):
                lhs=sum((F[s,x] for x in range(5) if (s,x) in F),Fraction(0))
                rhs=conv(A,s)
                assert lhs==rhs, f'{h}: source row {s} mismatch'
            # fixed output marginal P
            for x in range(5):
                lhs=sum((F[s,x] for s in range(SMAX+1) if (s,x) in F),Fraction(0))
                assert lhs==P[x], f'{h}: x marginal {x} mismatch'
            for x in range(5):
                child=tuple(F.get((k+x,x),Fraction(0))/P[x] for k in range(N))
                assert all(z>=0 for z in child) and sum(child)==1
                laws[h+(x,)]=child
    c0=B8[0];c1=B8[0]+B8[1];min_slack=None
    for h in itertools.product(range(5),repeat=depth):
        A=laws[h]
        s0=c0-A[0];s1=c1-A[0]-A[1]
        assert s0>=0 and s1>=0, f'leaf violation {h}'
        for z in (s0,s1): min_slack=z if min_slack is None else min(min_slack,z)
    stored_slack=QP(obj['min_leaf_slack'])
    assert min_slack==stored_slack, 'stored min leaf slack mismatch'
    return {'upper':cost,'internal_count':internal_count,'leaf_count':5**depth,'min_leaf_slack':min_slack}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--lower',required=True)
    ap.add_argument('--upper',required=True)
    ap.add_argument('--out',default='v021_exact_verification.json')
    args=ap.parse_args()
    lo=verify_lower(args.lower);up=verify_upper(args.upper);gap=lo['lower']-up['upper']
    assert gap>0, f'NONPOSITIVE EXACT GAP: {gap}'
    result={
      'version':VERSION,'verdict':'EXACT_RATIONAL_FINITE_SCALE_GAP_VERIFIED',
      'lower_exact':pair(lo['lower']),'lower_decimal':float(lo['lower']),
      'upper_exact':pair(up['upper']),'upper_decimal':float(up['upper']),
      'gap_exact':pair(gap),'gap_decimal':float(gap),
      'lower_certificate_cuts':lo['cut_count'],'master_active_terms':lo['active_terms'],
      'upper_internal_nodes':up['internal_count'],'upper_leaves':up['leaf_count'],
      'min_leaf_slack_exact':pair(up['min_leaf_slack']),'min_leaf_slack_decimal':float(up['min_leaf_slack']),
      'solver_free':True,'arithmetic':'fractions.Fraction / integer arithmetic only',
      'data_contract':'P,Q exact rationals; B8 exact binary64 dyadics used by DREAM6-ZR scripts',
    }
    Path(args.out).write_text(json.dumps(result,indent=2),encoding='utf-8')
    print('='*104)
    print('DREAM6-ZR v0.21 SOLVER-FREE EXACT CERTIFICATE VERIFIER')
    print('='*104)
    print('lower E6 :',float(lo['lower']))
    print('upper r5 :',float(up['upper']))
    print('exact gap:',float(gap))
    print('Farkas cuts:',lo['cut_count'],'master terms:',lo['active_terms'])
    print('r5 internal nodes:',up['internal_count'],'leaves:',up['leaf_count'])
    print('min leaf slack:',float(up['min_leaf_slack']))
    print('VERDICT: EXACT_RATIONAL_FINITE_SCALE_GAP_VERIFIED')
    print('WROTE',Path(args.out).resolve())
if __name__=='__main__':main()
