DREAM6-ZR exact finite-scale certificate
=======================================

Solver-free verification:

python .\DREAM6_ZR_v021_SOLVER_FREE_EXACT_CERTIFICATE_VERIFIER.py ^
  --lower .\target_exact_replay.json ^
  --upper .\exact_r5_primal.json ^
  --out .\v021_exact_verification.json

Expected verdict:
  EXACT_RATIONAL_FINITE_SCALE_GAP_VERIFIED

Exact certified comparison (dyadic B8 instance used by DREAM6-ZR code):
  v6 >= 0.6112592379601707...
  v5 <= 0.6110876318189729...
  v6-v5 >= 0.00017160614119786501... > 0

The verifier uses only Python standard-library fractions.Fraction for all
load-bearing checks.  No NumPy, SciPy, HiGHS, or optimization call is used.
