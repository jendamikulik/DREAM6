# QZR: oprava s plánovaným slovem a využitím hustotní rezervy

26. září 2026. Konstrukční pracovní výsledek.

**Rozsah:** Níže jsou dokázány dvě konstrukční věty a uvedeny konečné stromy
ověřené přesnými celočíselnými toky. Logaritmická horní mez pro všechny
horizonty zde dokázána není. Chybějící odhad je výslovně uveden v oddílu 7.

Pracujeme s
\[
P=(8,16,16,16,8)/64,\qquad Q=(7,20,10,20,7)/64.
\]
Zdrojové přírůstky jsou čerstvé a mají zákon \(Q\). Rezerva se fyzicky mění
podle \(J'=J+Y-X\) a nesmí být záporná. Pomocné soukromé značky lze
integrovat do podmíněného přechodového jádra; neumožňují čtení budoucího zdroje.

## 1. Oprava předplaceným součtem slova

Nechť \(A\) je skutečný kauzální nezáporný protokol délky \(N\) z kořene
\(B\), se zákonem veřejných slov \(R\). Pišme
\[
p(u)=\prod_{t=1}^N P_{u_t},\quad L(u)=R(u)/p(u),\quad
M>1,\quad L(u)\le M.
\]
Definujme
\[
\eta=M^{-1},\quad\varepsilon=1-M^{-1},\qquad
D(u)=\frac{Mp(u)-R(u)}{M-1}.
\]
Toto je pravděpodobnostní zákon celých slov. Nejde o samotný zákon součtu.

**Konstrukce.** Před načtením zdroje vylosujeme nezávisle
\(J\sim B\), \(I\sim\mathrm{Bernoulli}(\varepsilon)\) a \(U\sim D\).
Položme \(S(U)=\sum U_t\). Pro celé \(K\ge0\) předplatíme
\[
\widetilde J_0=J+I\bigl(S(U)+K\bigr).
\]
Na větvi \(I=0\) běží \(A\). Na větvi \(I=1\) postupně zveřejňujeme
předem naplánované písmeno \(U_t\), přičemž skutečné \(Y_t\) nadále
losujeme čerstvě z \(Q\).

Na označené větvi pro každý prefix délky \(t\)
\[
\widetilde J_t
=J+K+\sum_{i=t+1}^N U_i+\sum_{i=1}^tY_i\ge0.
\]
Celý veřejný zákon je přesně
\[
\eta R+\varepsilon D=P^{\otimes N}.
\]
To současně dokazuje správnost všech veřejných prefixů. Všechny zdrojové
přírůstky jsou nezávislé na počátečním plánu; kauzalita a čerstvost se zachovají.

**Přesná cena navíc:**
\[
\Delta_N
=\varepsilon\,\mathbb E_D S(U)+K\varepsilon
=2N-\frac{\mathbb E_R S(X)}{M}+K(1-M^{-1}).
\tag{1}
\]
Poslední výraz je cena dodané rezervy, nikoli rozdíl dvou nekonečných
středních hodnot. Pro konečné kořeny je rovněž rozdílem jejich středních hodnot.

Na označené větvi má konečná rezerva, podmíněně na libovolném veřejném slově,
**tentýž zákon**
\[
C_{N,K}=\delta_K*B*Q^{*N}.
\tag{2}
\]
Je to důsledek identity \(\widetilde J_N=J+K+\sum Y_i\).

## 2. Přesné rozložení každého listu

Označme \(A_u\) skutečný konečný zákon rezervy pomocného protokolu
podmíněný slovem \(u\), pokud \(R(u)>0\). List opraveného stromu je
\[
\widetilde B_u
=\frac{L(u)}{M}A_u+
\left(1-\frac{L(u)}{M}\right)C_{N,K}.
\tag{3}
\]
Při \(R(u)=0\) první člen chybí. Hmotnost opravné složky je tedy přesná
hustotní rezerva \(1-L(u)/M\); není předpokládána její uniformní kladnost.
Je-li \(L(u)\le M-\sigma\) všude, činí alespoň \(\sigma/M\).

## 3. Bezpečná složka může deficit odečítat

Nechť \(H\) je podporován na \([4s,\infty)\). Z takového kořene lze
realizovat **libovolný** zákon slov délky \(s\): slovo se naplánuje předem,
skutečný čerstvý zdroj se přijímá a rezerva nemůže být záporná.

Pro každý zákon \(A\) a \(a\in[0,1]\) platí
\[
\boxed{\Gamma_s(aA+(1-a)H)\le\max\{1,a\Gamma_s(A)\}.}
\tag{4}
\]

Důkaz: z \(A\) zvolme pomocný zákon slov \(R_A\le gP^{\otimes s}\).
Položme \(T=\max(1,ag)\). Pro \(a<1\) má
\[
E=\frac{TP^{\otimes s}-aR_A}{T-a}
\]
nezáporné koeficienty a jednotkovou hmotnost. Realizujme jej z bezpečné
složky. Protože \(1-a\le T-a\), je celkový zákon
\(aR_A+(1-a)E\le TP^{\otimes s}\).
Pro \(T=1\) nastává přesná rovnost s \(P^{\otimes s}\).
Případ \(a=1\) je bezprostřední; případné infimum v \(\Gamma_s\) se ošetří limitou.

Zvolíme-li v oddílu 1 \(K=4s\), dostaneme z (3) a (4)
\[
\boxed{
\Gamma_s(\widetilde B_u)-1
\le\frac{[L(u)(\Gamma_s(A_u)-1)-(M-L(u))]_+}{M}.
}
\tag{5}
\]
To je přesné použití hustotní rezervy: člen \(M-L(u)\) smí rušit budoucí
deficit. Není nutné odhadovat oba příspěvky odděleně a tuto rezervu zahodit.
Podmínka \(L(u)\Gamma_s(A_u)\le M\) stačí k exactnímu pokračování listu.
Tento vzorec sám nedokazuje, že lze požadovaná \(L(u),A_u\) vždy zkonstruovat.

## 4. Dyadická aplikace a cena

Nechť máme exactní strom hloubky \(n\) z \(B\) a z jeho listů pomocná
pokračování délky \(n\) s hustotami \(L_h(v)\le M\).
Celý pomocný zákon délky \(2n\) je \(R(hv)=p(h)R_h(v)\).
Opravný zákon je \(D(hv)=p(h)D_h(v)\); jeho první polovina má tedy zákon
\(P^{\otimes n}\) a střední součet \(2n\).

Na opravné větvi se **předem naplánuje i první polovina slova**. Není nutné
znát, kterou historii by vytvořil původní strom: tato označená větev jej
nahradí vlastním plánem se správným zákonem prvních \(n\) výstupů.
Tím se odstraní nelegální předplacení závislé na budoucí skutečné historii.

Pro \(N=2n\), \(s=2n\), \(K=8n\) máme
\[
\Delta_{2n}\le(2n+4n+8n)(1-M^{-1})
=14n(1-M^{-1}).
\tag{6}
\]
Při \(M=1+a/n\) je cena menší než \(14a\). V každém listu je společná
bezpečná složka \(\delta_{8n}*B*Q^{*2n}\), která zvládne libovolné další
slovo délky \(2n\), s přesnou hmotností \(1-L_h(v)/M\).

Bez přídavku \(K\) stojí tato varianta nejvýše \(6n(1-M^{-1})\) a vrací
společnou složku \(B*Q^{*2n}\). Ta není univerzálně bezpečná pro libovolný
výstupní zákon, ale patří do \(K_{8n}\). Ověření: pro
\(\mu=(17\delta_0+3\delta_1)/20\) platí \(\mu\in K_1\) a
\(Q\succeq_{st}\mu^{*4}\). Příslušné CDF mezery jsou přesně
\[
F_P-F_{Q*\mu}=(41/1280,0,9/128,1/32),
\]
\[
F_{\mu^{*4}}-F_Q=(66021,74977,65583,17419)/160000.
\]
Nezávislé konkatenace a monotónní přidání rezervy dávají tvrzení.

## 5. Skutečně sestrojené konečné protokoly

Pro konstrukční hledání ponechává pomocný protokol větve 1 a 3 beze změny.
Přesná redukce je
\[
Q=\tfrac12\widehat Q+\tfrac14\delta_1+\tfrac14\delta_3,
\quad P=\tfrac12\widehat P+\tfrac14\delta_1+\tfrac14\delta_3,
\]
\[
\widehat Q=(7,4,10,4,7)/32,\qquad
\widehat P=(1,0,2,0,1)/4.
\]
Není třeba zaměňovat fyzický zdroj za \(\widehat Q\): aktivní transportní
tabulka s hmotností 1/2 a dvě nehybné tabulky mají dohromady přesně sloupcový
zákon \(Q*B\). Podmínění podle aktuálního součtu rezervy a čerstvého zdroje
dává přípustný původní kauzální kernel.

LP je pouze vyhledávač. Jeho přechody jsou následně nahrazeny nezápornými
celočíselnými čítači se společným jmenovatelem \(2^{48}\). Kořen má přesný
dyadický zákon. Ověřovač znovu spočítá skutečné toky, nikoli LP reziduum.
Poté použije větu z oddílu 1 s \(K=0\).

| Hloubka | Prokázaná horní mez ceny zkonstruovaného protokolu |
|---:|---:|
| 2 | 0.742945326278671 |
| 4 | 0.784128125275142 |
| 6 | 0.796560032679673 |
| 7 | 0.799387314415792 |
| 8 | 0.803060009432245 |

Všechna čísla jsou zaokrouhlena směrem nahoru. Nejsou vydávána za optima
původní úlohy. Pro hloubku 8 se kontroluje 9841 uzlů a 6561 aktivních listů.
Hustotní nadbytek je menší než \(4.265\cdot10^{-12}\), přesná cena plánované
opravy menší než \(6.8192\cdot10^{-11}\).

Hustota každého původního veřejného slova je hustotou jeho aktivního
podslova. Hustoty aktivních prefixů tvoří martingal pod \(\widehat P\),
takže maximum na aktivních listech majorizuje i všechna původní slova
délky \(n\) s libovolným počtem nehybných písmen. Toto je důvod, proč
3-ární certifikát ověřuje celý původní 5-ární veřejný strom.

Při zbývajícím horizontu \(r\) je virtuální rezerva \(4r\) bezpečná.
Fyzický přebytek se nemusí zahazovat: realizace jej nese dál. Bezpečná
část zde používá předem zvolený výstupní zákon, takže všechny kontrolované
přechody jsou kauzální. Ověřovač nikdy nenormalizuje useknutý chvost.

## 6. Konkrétní logaritmický kandidát s certifikovaným začátkem

Definujme
\[
V(0)=0,\quad V(1)=7/8,\quad
V(j)=\frac{1}{8(j-1)j}\quad(j\ge2).
\]
Potom
\[
\Pr(V\ge j)=\frac1{8(j-1)}\ (j\ge2),\qquad
\mathbb E\min(V,L)=1+\tfrac18 H_{L-1}.
\tag{7}
\]
Z opraveného kořene certifikátu hloubky 8 po saturaci na 32 vypočítal
ověřovač přesně
\[
\max_{2\le j\le32}(j-1)\Pr(J_0\ge j)
<0.087593943196432<1/8.
\]
Tedy \(\operatorname{Law}(\min(V,32))\) stochasticky dominuje tomuto
kořeni a patří do \(K_8\). Jde o certifikovaný konečný výsledek.

Použitá saturace obecného kořene je legitimní: na události původní rezervy
alespoň \(4n\) lze její původní podmíněný zákon výstupního slova naplánovat
předem a realizovat ze zásoby \(4n\). Nezaměňuje se tento podmíněný zákon
automaticky za \(P^{\otimes n}\). Monotónní zvětšení kořene poté zachovává
kauzální realizaci.

Kdyby se tento kořen podařilo uzavřít pro všechny hloubky, plynulo by
\(\mathcal B_n\le1+\frac18 H_{4n-1}=\frac18\log n+O(1)\).
**To zde dokázáno není.** Výsledek pro hloubku 8 se neextrapoluje.

## 7. Přesná neuzavřená část

Je třeba zkonstruovat pomocné fany tak, aby na všech skutečných listech
a při každém zdvojení současně platila požadovaná malá hustota a odhad
součinu \(L(u)\Gamma_s(A_u)\). Rovnice (5) ukazuje, že je správné
optimalizovat
\[
\bigl[L(u)(\Gamma_s(A_u)-1)-(M-L(u))\bigr]_+,
\]
tedy budoucí deficit po odečtení nevyužité hustotní rezervy.

Bez tohoto uniformního kroku nedávají (6) ani konečné certifikáty důkaz
\(O(\log n)\). Nemáme důkaz, že popsaný mechanismus na všech škálách selže;
nemáme ani důkaz, že se vždy podaří uzavřít.

## Reprodukce

Použijte běžný Python, nikoli režim `-O`, který vypíná kontrolní assertions.
Ověření nepotřebuje NumPy ani SciPy:

```sh
python -S certify_active_tree.py active_n8.certificate.json
```

Stejně lze ověřit ostatní JSON certifikáty. Znovuvyhledání LP vyžaduje
NumPy a SciPy; osmý horizont byl nalezen metodou `highs-ipm`:

```python
from active_tree_lp import solve
solve(8, method='highs-ipm', limit=120)
```

Převod nalezeného kandidáta na samostatný certifikát:

```sh
python certify_active_tree.py work/active_n8.npz
```

Ověřovač při načtení JSON nepoužívá vložený report jako důkaz. Všechny
toky, hustoty, ceny a stochastickou majorizaci vypočítává znovu.
