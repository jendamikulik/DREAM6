"""Indexing shared by the LP constructor and the independent integer verifier."""
X=(0,2,4)

def layout(n):
    nodes=[];off=0
    for d in range(n+1):
        for _ in range(3**d):
            r=n-d;N=4*r;b=off;off+=N+1;fs=[]
            if r:
                for s in range(N+4):
                    for z,x in enumerate(X):
                        if x<=s:fs.append((s,z,off));off+=1
            nodes.append(dict(d=d,r=r,b=b,fs=fs,child=[]))
    for i,node in enumerate(nodes):
        if node['r']:node['child']=[3*i+1,3*i+2,3*i+3]
    return nodes,off
