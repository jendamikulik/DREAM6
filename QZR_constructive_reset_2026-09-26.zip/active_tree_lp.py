import numpy as np
from scipy.sparse import coo_matrix
from scipy.optimize import linprog
import time,json,sys
P=np.array([1,2,1],float)/4
Q=np.array([7,4,10,4,7],float)/32
X=(0,2,4)

def layout(n):
    # All reserve >=4r is a safe state. Its excess need not be discarded
    # physically; it can be tracked separately in an implementation.
    nodes=[]; off=0
    for d in range(n+1):
        for idx in range(3**d):
            r=n-d; N=4*r
            b=off;off+=N+1
            fs=[]
            if r:
                for s in range(N+4):
                    for z,x in enumerate(X):
                        if x<=s:
                            fs.append((s,z,off));off+=1
            nodes.append(dict(d=d,r=r,b=b,fs=fs,child=[]))
    for i,node in enumerate(nodes):
        if node['r']:node['child']=[3*i+1,3*i+2,3*i+3]
    return nodes,off

def solve(n, root=None, limit=120, tag='', method='highs'):
    nodes,off=layout(n)
    row=[];col=[];data=[];rhs=[]
    def eq(terms,b):
        rid=len(rhs);rhs.append(b)
        for c,v in terms:
            if v:row.append(rid);col.append(c);data.append(v)
    for i,node in enumerate(nodes):
        r,b=node['r'],node['b'];N=4*r
        eq([(b+j,1) for j in range(N+1)],1)
        if not r:continue
        bys=[[] for _ in range(N+4)]
        bykid=[[[] for _ in range(N-3)] for z in X]
        for s,z,v in node['fs']:
            bys[s].append((v,1))
            bykid[z][min(s-X[z],N-4)].append((v,1))
        for s in range(N+4):
            terms=bys[s]+[(b+s-y,-Q[y]) for y in range(5) if 0<=s-y<N]
            eq(terms,0)
        for z,ci in enumerate(node['child']):
            cb=nodes[ci]['b']
            for k in range(N-3):
                terms=bykid[z][k]+[(cb+k,-P[z])]
                if k==N-4:terms.append((b+N,P[z]))
                eq(terms,0)
    if root is not None:
        for j,v in enumerate(root):eq([(nodes[0]['b']+j,1)],v)
    A=coo_matrix((data,(row,col)),shape=(len(rhs),off)).tocsr()
    obj=np.zeros(off)
    if root is None:obj[:4*n+1]=np.arange(4*n+1)
    print('n',n,'nodes',len(nodes),'vars',off,'eq',len(rhs),flush=True)
    start=time.time()
    res=linprog(obj,A_eq=A,b_eq=np.array(rhs),bounds=(0,None),method=method,
                options={'time_limit':limit,'primal_feasibility_tolerance':1e-9,
                         'dual_feasibility_tolerance':1e-9})
    print('status',res.status,'cost',res.fun,'seconds',time.time()-start,flush=True)
    if res.x is not None:
        print('residual',np.max(np.abs(A@res.x-rhs)), 'root',res.x[:4*n+1],flush=True)
        from pathlib import Path
        Path('work').mkdir(exist_ok=True)
        np.savez_compressed('work/active%s_n%d.npz'%(tag,n),x=res.x,n=n,cost=res.fun)
    return res,nodes

if __name__=='__main__':
    for n in map(int,sys.argv[1:] or [1,2,3,4,5,6,7,8]):
        res,nodes=solve(n)
        if not res.success:break
