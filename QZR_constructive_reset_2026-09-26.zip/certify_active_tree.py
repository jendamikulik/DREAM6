"""Turn floating LP policies into exact finite-horizon QZR certificates.
No LP feasibility or floating-point residual is trusted by the verifier.
Only exact integer transition counts and exact forward probability flow
are used to certify the final (density-repaired) protocol.
"""
import json,math,sys
from fractions import Fraction as F
from pathlib import Path
from active_layout import layout,X
QNUM=(7,4,10,4,7)
PNUM=(1,2,1)
BITS=48
UNIT=1<<BITS

def apportion(a):
    import numpy as np
    a=np.maximum(np.asarray(a,dtype=float),0)
    if not a.sum():
        out=[0]*len(a);out[0]=UNIT;return out
    q=a/a.sum()*UNIT
    out=[int(v) for v in np.floor(q)]
    diff=UNIT-sum(out)
    # The integer result is the definition of the policy; approximation
    # accuracy influences cost only, never correctness of verification.
    out[int(np.argmax(a))]+=diff
    assert min(out)>=0 and sum(out)==UNIT
    return out

def generate(filename):
    import numpy as np
    data=np.load(filename);n=int(data['n']);x=data['x']
    nodes,_=layout(n)
    root_kind='H2' if '_H2_' in str(filename) else 'rounded_optimum'
    if root_kind=='H2':
        fs=[F(0)]+[F(2,(j+1)*(j+2)) for j in range(1,4*n)]+[F(2,4*n+1)]
        den=math.lcm(*(f.denominator for f in fs))
        root=[f.numerator*(den//f.denominator) for f in fs]
    else:
        den=UNIT;root=apportion(x[:4*n+1])
    policies=[]
    for node in nodes:
        if not node['r']:policies.append(None);continue
        bys=[[] for _ in range(4*node['r']+4)]
        for s,z,v in node['fs']:bys[s].append((z,v))
        pol=[]
        for s,cells in enumerate(bys):
            weights=apportion([x[v] for z,v in cells])
            vec=[0,0,0]
            for (z,v),w in zip(cells,weights):vec[z]=w
            pol.append(vec)
        policies.append(pol)
    cert=dict(format='QZR-active-exact-v1',n=n,bits=BITS,
              root_kind=root_kind,root_denominator=den,root_counts=root,
              policies=policies)
    report=verify(cert)
    cert['reported_bound']=report
    out=Path(str(filename).replace('.npz','.certificate.json'))
    out.write_text(json.dumps(cert,separators=(',',':')))
    print(json.dumps(report,indent=2),flush=True)
    return out,report

def upper_decimal(f,digits=15):
    scale=10**digits
    num=-((-f.numerator*scale)//f.denominator)
    return f'{num//scale}.{num%scale:0{digits}d}'

def verify(cert):
    n,bits=cert['n'],cert['bits'];unit=1<<bits
    nodes,_=layout(n);policies=cert['policies']
    assert len(policies)==len(nodes)
    root=cert['root_counts'];rden=cert['root_denominator']
    assert len(root)==4*n+1 and min(root)>=0 and sum(root)==rden
    measures=[None]*len(nodes);measures[0]=root
    target_exponents=[0]*len(nodes)
    # Common denominator of all leaf density ratios.
    density_den=rden << ((bits+4)*n)
    max_density_num=density_den
    max_word=None
    level_sum_counts=[[0]*(4*d+1) for d in range(n+1)]
    output_sums=[0]*len(nodes)
    for i,node in enumerate(nodes):
        r=node['r'];a=measures[i];assert a is not None
        level_sum_counts[node['d']][output_sums[i]]+=sum(a)
        if not r:
            density_num=a[0] << (target_exponents[i]-n)
            if density_num>max_density_num:
                max_density_num=density_num;max_word=i
            continue
        N=4*r;pol=policies[i]
        assert len(pol)==N+4
        mu=[0]*(N+4)
        for j,mass in enumerate(a[:-1]):
            for y,w in enumerate(QNUM):mu[j+y]+=mass*w
        kids=[[0]*(N-3) for _ in range(3)]
        for s,vec in enumerate(pol):
            assert len(vec)==3 and min(vec)>=0 and sum(vec)==unit
            for z,(x,w) in enumerate(zip(X,vec)):
                if x>s:assert w==0
                elif w:kids[z][min(s-x,N-4)]+=mu[s]*w
        for z in range(3):kids[z][-1]+=a[-1]*PNUM[z]*(1<<(bits+3))
        assert sum(map(sum,kids))==sum(a)*(1<<(bits+5))
        for z,ci in enumerate(node['child']):
            measures[ci]=kids[z]
            target_exponents[ci]=target_exponents[i]+(1 if z==1 else 2)
            output_sums[ci]=output_sums[i]+X[z]
        measures[i]=None
    M=F(max_density_num,density_den)
    epsilon=(M-1)/M
    base=F(sum(j*v for j,v in enumerate(root)),rden)
    cost=base+4*n*epsilon
    # Exact sum law of the ORIGINAL five-letter auxiliary protocol.
    # Idle letters 1,3 each have probability 1/4; the active clock is fair.
    Rsum=[F(0)]*(4*n+1)
    for k in range(n+1):
        den_k=rden << ((bits+5)*k)
        for s,num in enumerate(level_sum_counts[k]):
            if not num:continue
            for l in range(n-k+1):
                at=s+(n-k)+2*l
                Rsum[at]+=F(num*math.comb(n,k)*math.comb(n-k,l),
                            den_k*(1<<(2*n-k)))
    assert sum(Rsum)==1
    Psum=[F(1)]
    for _ in range(n):
        nxt=[F(0)]*(len(Psum)+4)
        for s,v in enumerate(Psum):
            for x,w in enumerate((8,16,16,16,8)):nxt[s+x]+=v*F(w,64)
        Psum=nxt
    # This is epsilon times the sum distribution of the correction word.
    repair=[p-r/M for p,r in zip(Psum,Rsum)]
    assert min(repair)>=0 and sum(repair)==epsilon
    planned_extra=sum(s*v for s,v in enumerate(repair))
    assert planned_extra==2*n-sum(s*v for s,v in enumerate(Rsum))/M
    # The repaired initial law, saturated at the safe budget 4n.
    multiplier=repair.copy();multiplier[0]+=1/M
    repaired=[F(0)]*(4*n+1)
    for j,v in enumerate(root):
        if not v:continue
        for s,w in enumerate(multiplier):
            repaired[min(j+s,4*n)]+=F(v,rden)*w
    assert sum(repaired)==1 and min(repaired)>=0
    tail=F(0);envelope=F(0)
    for j in range(4*n,1,-1):
        tail+=repaired[j]
        envelope=max(envelope,(j-1)*tail)
    report=dict(n=n,root_kind=cert['root_kind'],nodes=len(nodes),
                leaves=3**n,base_cost_upper=upper_decimal(base),
                density_excess_upper=upper_decimal(M-1),
                prepaid_extra_upper=upper_decimal(4*n*epsilon),
                exact_protocol_cost_upper=upper_decimal(cost),
                planned_word_extra_upper=upper_decimal(planned_extra),
                planned_protocol_cost_upper=upper_decimal(base+planned_extra),
                shifted_harmonic_coefficient_upper=upper_decimal(envelope),
                shifted_harmonic_one_eighth_dominates=(envelope<=F(1,8)),
                M_numerator=str(M.numerator),M_denominator=str(M.denominator),
                worst_leaf_node=max_word,
                status='VERIFIED_BY_EXACT_INTEGER_FLOW')
    return report

if __name__=='__main__':
    for filename in sys.argv[1:]:
        if filename.endswith('.json'):
            report=verify(json.loads(Path(filename).read_text()))
            print(json.dumps(report,indent=2))
        else:generate(filename)
