# Independent audit report

Date: 2026-09-04

Two logically separate verification routes were run.

1. The original exact verifier rebuilt the LP through the solver's model builder, converted the known dyadic coefficients to exact `Fraction`s, and verified all rational primal/dual certificates.
2. A new standalone verifier (`verify_exact.py`) was then written from the mathematical LP equations alone.  It does **not** import the solver or SciPy, does not call an optimizer, and uses exact standard-library `Fraction` arithmetic throughout.

Both routes passed.

## Standalone model sizes

| horizon | variables | equality rows |
|---:|---:|---:|
| 1 | 155 | 76 |
| 2 | 2,229 | 891 |
| 3 | 18,703 | 7,006 |
| 4 | 131,177 | 47,621 |

## Baseline primal/dual checks

All primal equations hold exactly; all primal variables are nonnegative; primal objectives equal the claimed rational \(\mathcal B_n\).  All baseline dual reduced costs are nonnegative exactly and the dual objective equals the same \(\mathcal B_n\).

Exact reduced-cost audit:

| certificate | zero reduced costs | positive reduced costs | negative reduced costs | smallest positive reduced cost |
|---|---:|---:|---:|---:|
| baseline n=1 | 137 | 18 | 0 | 13/20 |
| baseline n=2 | 2,178 | 51 | 0 | 13/20 |
| baseline n=3 | 18,193 | 510 | 0 | 38416/1050005 |
| baseline n=4 | 129,110 | 2,067 | 0 | 1916723864480768/420381282815550045 |

## Whole-optimal-face secondary dual checks

The following exact secondary duals have no negative reduced cost and attain the exact dual objective needed to upper-bound the conditional mean by the lower-horizon optimum:

| horizon | history | certified upper bound | zero rc | positive rc | negative rc | smallest positive rc |
|---:|---|---|---:|---:|---:|---:|
| 3 | (4) | E[B_(4)] <= B_2 | 18,269 | 434 | 0 | 8 |
| 4 | (4) | E[B_(4)] <= B_3 | 129,843 | 1,334 | 0 | 1078784/3330009 |
| 4 | (4,4) | E[B_(4,4)] <= B_2 | 129,201 | 1,976 | 0 | 577922752/23310063 |

Subtree feasibility gives the reverse inequalities, hence equality for every global optimum.

## Audit conclusion

The published JSON witnesses are valid exact certificates for the finite LP stated in `README.md`.  Therefore the exact values \(\mathcal B_1,\ldots,\mathcal B_4\) and the three whole-optimal-face forced-contact claims follow by rational primal/dual weak duality.

This conclusion is independent of the floating-point HiGHS solution from which the witnesses were originally discovered.
