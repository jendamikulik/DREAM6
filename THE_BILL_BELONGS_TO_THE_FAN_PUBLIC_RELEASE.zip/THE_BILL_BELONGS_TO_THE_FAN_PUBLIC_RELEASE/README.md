# The Bill Belongs to the Fan, Not the Path — public QED release

This is the complete public package for the finite-horizon forced-contact result.
It contains the paper, a one-page QED statement, exact rational primal/dual
certificates, and an independent standalone verifier.

## Start here

- `paper/THE_BILL_BELONGS_TO_THE_FAN_ONE_PAGE_QED.pdf` — one-page theorem + proof.
- `paper/THE_BILL_BELONGS_TO_THE_FAN_QED.pdf` — fuller paper.
- `AUDIT_REPORT.md` — independent exact-certificate audit.
- `verify_exact.py` — standalone verifier, Python standard library only.
- `certificates/` — exact rational JSON witnesses.
- `SHA256SUMS.txt` — hashes of all release files except the manifest itself.

## Certified claims

For

\[
P=(1/8,1/4,1/4,1/4,1/8),\qquad
Q=(7/64,5/16,5/32,5/16,7/64),
\]

the exact finite-horizon optima are

\[
\mathcal B_1=\frac3{20},\qquad
\mathcal B_2=\frac{43}{180},
\]
\[
\mathcal B_3=\frac{2801758}{9450045},\qquad
\mathcal B_4=\frac{144958044813242692}{420381282815550045}.
\]

On the **entire optimal face** the certificates prove

\[
n=3:\qquad \Delta_{(4)}=0,
\]

and

\[
n=4:\qquad \Delta_{(4)}=\Delta_{(4,4)}=0.
\]

Combined with the analytic identity

\[
\sum_{|g|=s}P(g)\Delta_{hg}
=\Delta_h+\mathcal B_r-\mathcal B_{r-s},
\]

this yields the forced counterfactual-fan accounting statement: at each
certified contact, the selected continuation carries zero excess and the
marginal bill is carried by the sibling fan.

## Verify everything

Python 3.10+ is sufficient. No SciPy, HiGHS, or external optimizer is used.

Windows PowerShell:

```powershell
python .\verify_exact.py --cert-dir .\certificates
```

Linux/macOS:

```bash
python3 ./verify_exact.py --cert-dir ./certificates
```

Expected final line:

```text
ALL EXACT CERTIFICATES VERIFIED. QED for the stated finite-horizon claims.
```

The verifier reconstructs the occupancy LP independently from the mathematical
specification, parses witness entries as `fractions.Fraction`, and checks exact
primal feasibility, nonnegativity, primal objectives, dual reduced-cost
inequalities, dual objectives, and the whole-optimal-face secondary duals.
There is no numerical tolerance in the certificate check.

## Exact LP being certified

For horizon \(n\), define

\[
\mu_{t,j,h}=\Pr(J_t=j,X_{1:t}=h),
\]

and

\[
\nu_{t,j,h,y,x}
=\Pr(J_t=j,X_{1:t}=h,Y_{t+1}=y,X_{t+1}=x).
\]

The nonnegative variables satisfy:

1. root normalization
   \[
   \sum_j\mu_{0,j,\varnothing}=1;
   \]
2. fresh input
   \[
   \sum_x\nu_{t,j,h,y,x}=Q(y)\mu_{t,j,h};
   \]
3. exact buffer flow, with \(j'=j+y-x\ge0\),
   \[
   \mu_{t+1,j',hx}
   =\sum_{j,y:\,j+y-x=j'}\nu_{t,j,h,y,x};
   \]
4. exact iid output
   \[
   \sum_{j'}\mu_{t+1,j',hx}
   =P(x)\sum_j\mu_{t,j,h}.
   \]

The objective is

\[
\min\sum_jj\mu_{0,j,\varnothing}=\mathbb E J_0.
\]

For horizon \(n\), root reserve above \(4n\) is unnecessary at optimum:
condition on such a root atom and shift that component down to \(4n\); the
buffer can decrease by at most \(4n\) over \(n\) steps, so nonnegativity and
the joint \((X,Y)\)-law are preserved while the initial mean strictly falls.
Thus the certified LP is finite.

## Trust boundary

The result certified here is finite-horizon. It does **not** prove forced
contacts for every \(n\), uniqueness of every optimal conditional law, or an
asymptotic law for \(\mathcal B_n\).
