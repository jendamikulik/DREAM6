@echo off
python verify_exact.py --cert-dir certificates
pause
