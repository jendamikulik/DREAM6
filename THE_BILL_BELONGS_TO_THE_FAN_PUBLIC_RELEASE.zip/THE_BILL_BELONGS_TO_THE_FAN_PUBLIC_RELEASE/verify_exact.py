#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
DREAM6 FAN -- standalone exact certificate verifier
===================================================

Purpose
-------
Independently verifies the published rational primal/dual certificates for the
finite-horizon quartic zero-repair LP.  This file intentionally does NOT import
the solver and does NOT call an optimizer.  The LP is rebuilt directly from the
mathematical specification using only Python's standard library and exact
fractions.

Certified statements
--------------------
  B1 = 3/20
  B2 = 43/180
  B3 = 2801758/9450045
  B4 = 144958044813242692 / 420381282815550045

and, on the entire optimal face,
  n=3:  E[B_(4)]   = B2,
  n=4:  E[B_(4)]   = B3,
  n=4:  E[B_(4,4)] = B2.

The last three facts follow by an exact dual upper bound on each conditional
mean, combined with the elementary subtree lower bound E[B_h] >= B_remaining.

Dependencies: Python >= 3.10, standard library only.
"""
from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from fractions import Fraction as F
from itertools import product
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

VALUES = (0, 1, 2, 3, 4)
P = (F(1,8), F(1,4), F(1,4), F(1,4), F(1,8))
Q = (F(7,64), F(5,16), F(5,32), F(5,16), F(7,64))

EXACT_B = {
    0: F(0),
    1: F(3,20),
    2: F(43,180),
    3: F(2801758,9450045),
    4: F(144958044813242692,420381282815550045),
}

CONTACTS = (
    (3, (4,),   2, "secondary_n3_h4_exact.json"),
    (4, (4,),   3, "secondary_n4_h4_exact.json"),
    (4, (4,4),  2, "secondary_n4_h44_exact.json"),
)


def reject_duplicate_keys(pairs):
    d = {}
    for k, v in pairs:
        if k in d:
            raise ValueError(f"duplicate JSON key: {k!r}")
        d[k] = v
    return d


def load_json(path: Path):
    with path.open("r", encoding="utf-8") as fh:
        return json.load(fh, object_pairs_hook=reject_duplicate_keys)


def rat(pair) -> F:
    if not (isinstance(pair, list) and len(pair) == 2):
        raise TypeError(f"expected [numerator, denominator], got {pair!r}")
    num, den = int(pair[0]), int(pair[1])
    if den == 0:
        raise ValueError("zero denominator")
    return F(num, den)


@dataclass
class ExactModel:
    n: int
    mu: Dict[Tuple[int,int,Tuple[int,...]], int]
    nu: Dict[Tuple[int,int,Tuple[int,...],int,int], int]
    rows: List[List[Tuple[int,F]]]
    rhs: List[F]
    c: List[F]
    jmax: Tuple[int,...]

    @property
    def nvar(self): return len(self.c)
    @property
    def nrow(self): return len(self.rows)


def build_exact_model(n: int) -> ExactModel:
    """Build the finite occupancy LP directly in rational arithmetic."""
    if not 1 <= n <= 4:
        raise ValueError("publication verifier supports n=1..4")

    # WLOG root support 0..4n; in t steps buffer can rise by at most 4t.
    j0max = 4*n
    jmax = tuple(j0max + 4*t for t in range(n+1))

    mu = {}
    nu = {}
    c: List[F] = []

    def newvar(cost=F(0)):
        idx = len(c); c.append(F(cost)); return idx

    # IMPORTANT: this ordering is the public certificate index convention.
    for t in range(n+1):
        for h in product(VALUES, repeat=t):
            for j in range(jmax[t]+1):
                mu[(t,j,h)] = newvar(F(j) if t == 0 else F(0))

    for t in range(n):
        for h in product(VALUES, repeat=t):
            for j in range(jmax[t]+1):
                for y in VALUES:
                    for x in VALUES:
                        jp = j+y-x
                        if 0 <= jp <= jmax[t+1]:
                            nu[(t,j,h,y,x)] = newvar()

    rows: List[List[Tuple[int,F]]] = []
    rhs: List[F] = []

    # Root normalization.
    rows.append([(mu[(0,j,())], F(1)) for j in range(j0max+1)])
    rhs.append(F(1))

    # Fresh Y: sum_x nu(t,j,h,y,x) = Q(y) mu(t,j,h).
    for t in range(n):
        for h in product(VALUES, repeat=t):
            for j in range(jmax[t]+1):
                for y in VALUES:
                    rr = []
                    for x in VALUES:
                        idx = nu.get((t,j,h,y,x))
                        if idx is not None:
                            rr.append((idx,F(1)))
                    rr.append((mu[(t,j,h)], -Q[y]))
                    rows.append(rr); rhs.append(F(0))

    # Flow: mu(t+1,j',hx) = sum_{j,y: j+y-x=j'} nu(t,j,h,y,x).
    # Generate predecessor lists locally to avoid importing any solver code.
    for t in range(n):
        pred: Dict[Tuple[int,Tuple[int,...]], List[int]] = {}
        for h in product(VALUES, repeat=t):
            for j in range(jmax[t]+1):
                for y in VALUES:
                    for x in VALUES:
                        idx = nu.get((t,j,h,y,x))
                        if idx is None: continue
                        jp = j+y-x
                        key = (jp, h+(x,))
                        pred.setdefault(key, []).append(idx)
        for h2 in product(VALUES, repeat=t+1):
            for jp in range(jmax[t+1]+1):
                rr = [(mu[(t+1,jp,h2)], F(1))]
                rr.extend((idx,F(-1)) for idx in pred.get((jp,h2), ()))
                rows.append(rr); rhs.append(F(0))

    # IID P output: mass(hx)=P(x) mass(h).
    for t in range(n):
        for h in product(VALUES, repeat=t):
            for x in VALUES:
                rr = [(mu[(t+1,jp,h+(x,))], F(1)) for jp in range(jmax[t+1]+1)]
                rr.extend((mu[(t,j,h)], -P[x]) for j in range(jmax[t]+1))
                rows.append(rr); rhs.append(F(0))

    return ExactModel(n,mu,nu,rows,rhs,c,jmax)


def read_sparse_map(d, key, limit, *, allow_empty=True) -> Dict[int,F]:
    raw = d.get(key, {})
    if not isinstance(raw, dict):
        raise TypeError(f"{key} must be an object")
    out = {}
    for ks, pair in raw.items():
        j = int(ks)
        if not (0 <= j < limit):
            raise IndexError(f"{key} index {j} outside 0..{limit-1}")
        v = rat(pair)
        if v == 0:
            raise ValueError(f"{key}[{j}] is explicitly zero; certificates must be canonical sparse maps")
        out[j] = v
    if not allow_empty and not out:
        raise ValueError(f"empty {key}")
    return out


def dot_sparse(vec: Dict[int,F], coeff: List[F]) -> F:
    return sum((v*coeff[j] for j,v in vec.items()), F(0))


def verify_primal(cert_dir: Path, m: ExactModel) -> Dict[int,F]:
    d = load_json(cert_dir / f"primal_n{m.n}_exact.json")
    if d.get("type") != "primal" or int(d.get("n",-1)) != m.n:
        raise AssertionError("wrong primal certificate metadata")
    B = F(int(d["B_num"]), int(d["B_den"]))
    if B != EXACT_B[m.n]: raise AssertionError((m.n,B,EXACT_B[m.n]))
    x = read_sparse_map(d,"x",m.nvar,allow_empty=False)
    if any(v < 0 for v in x.values()): raise AssertionError("negative primal variable")

    for r,(terms,b) in enumerate(zip(m.rows,m.rhs)):
        s = sum((a*x.get(j,F(0)) for j,a in terms),F(0))
        if s != b:
            raise AssertionError(f"n={m.n} primal row {r}: {s} != {b}")
    obj = dot_sparse(x,m.c)
    if obj != B: raise AssertionError(f"n={m.n} primal objective {obj} != {B}")
    return x


def transpose_times_sparse_y(m: ExactModel, y: Dict[int,F]) -> Dict[int,F]:
    aty: Dict[int,F] = {}
    for r,yr in y.items():
        for j,a in m.rows[r]:
            v = aty.get(j,F(0)) + a*yr
            if v: aty[j]=v
            elif j in aty: del aty[j]
    return aty


def dual_objective(m: ExactModel, y: Dict[int,F]) -> F:
    return sum((m.rhs[r]*yr for r,yr in y.items()), F(0))


def verify_baseline_dual(cert_dir: Path, m: ExactModel):
    d = load_json(cert_dir / f"baseline_n{m.n}_dual_exact.json")
    if d.get("type") != "baseline_dual" or int(d.get("n",-1)) != m.n:
        raise AssertionError("wrong baseline dual metadata")
    B=F(int(d["B_num"]),int(d["B_den"]))
    if B != EXACT_B[m.n]: raise AssertionError((m.n,B,EXACT_B[m.n]))
    y=read_sparse_map(d,"y",m.nrow)
    aty=transpose_times_sparse_y(m,y)
    for j,cj in enumerate(m.c):
        rc=cj-aty.get(j,F(0))
        if rc < 0:
            raise AssertionError(f"n={m.n} baseline dual infeasible col {j}: rc={rc}")
    dobj=dual_objective(m,y)
    if dobj != B: raise AssertionError(f"n={m.n} baseline dual objective {dobj} != {B}")


def p_history(h: Tuple[int,...]) -> F:
    z=F(1)
    for x in h: z*=P[x]
    return z


def secondary_q(m: ExactModel, h: Tuple[int,...]) -> Dict[int,F]:
    ph=p_history(h); t=len(h); q={}
    for j in range(1,m.jmax[t]+1):
        q[m.mu[(t,j,h)]] = -F(j)/ph  # min -E[B_h]
    return q


def conditional_mean(m: ExactModel, x: Dict[int,F], h: Tuple[int,...]) -> F:
    ph=p_history(h); t=len(h)
    mass=sum((x.get(m.mu[(t,j,h)],F(0)) for j in range(m.jmax[t]+1)),F(0))
    if mass != ph: raise AssertionError(f"conditional mass at {h}: {mass} != {ph}")
    num=sum((F(j)*x.get(m.mu[(t,j,h)],F(0)) for j in range(m.jmax[t]+1)),F(0))
    return num/ph


def verify_secondary(cert_dir: Path, m: ExactModel, h: Tuple[int,...], remaining: int, fname: str):
    d=load_json(cert_dir/fname)
    if d.get("type") != "secondary_dual" or int(d.get("n",-1)) != m.n or tuple(d.get("history",())) != h:
        raise AssertionError("wrong secondary certificate metadata")
    Bn=F(int(d["Bn_num"]),int(d["Bn_den"]))
    target=F(int(d["target_num"]),int(d["target_den"]))
    if Bn != EXACT_B[m.n] or target != EXACT_B[remaining]:
        raise AssertionError("wrong secondary target metadata")
    y=read_sparse_map(d,"y",m.nrow)
    lam=rat(d["lambda"])
    aty=transpose_times_sparse_y(m,y)
    q=secondary_q(m,h)
    for j,cj in enumerate(m.c):
        rc=q.get(j,F(0))-aty.get(j,F(0))-lam*cj
        if rc < 0:
            raise AssertionError(f"secondary n={m.n} h={h} col={j}: rc={rc}")
    dobj=dual_objective(m,y)+lam*Bn
    if dobj != -target:
        raise AssertionError(f"secondary n={m.n} h={h}: dual obj {dobj} != {-target}")


def main() -> int:
    ap=argparse.ArgumentParser()
    ap.add_argument("--cert-dir",type=Path,required=True)
    args=ap.parse_args(); cert=args.cert_dir
    print("DREAM6 FAN -- STANDALONE EXACT CERTIFICATE AUDIT")
    print("stdlib only; no solver import; no optimizer; exact Fraction arithmetic")
    print("-"*78)
    models={}; primals={}
    for n in range(1,5):
        m=build_exact_model(n); models[n]=m
        x=verify_primal(cert,m); primals[n]=x
        verify_baseline_dual(cert,m)
        print(f"[PASS baseline n={n}] vars={m.nvar:,} rows={m.nrow:,} B_{n}={EXACT_B[n]}")
    for n,h,r,fname in CONTACTS:
        verify_secondary(cert,models[n],h,r,fname)
        wm=conditional_mean(models[n],primals[n],h)
        if wm != EXACT_B[r]:
            raise AssertionError(f"primal contact witness n={n} h={h}: {wm} != {EXACT_B[r]}")
        print(f"[PASS whole-face forcing] n={n} h={h}: E[B_h] <= B_{r}; subtree feasibility => equality")
    print("-"*78)
    print("ALL EXACT CERTIFICATES VERIFIED. QED for the stated finite-horizon claims.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
