#!/usr/bin/env sh
set -eu
python3 ./verify_exact.py --cert-dir ./certificates
