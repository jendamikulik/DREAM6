Bounded causal entropy tax

Main result: for finite P,Q with H(P) != H(Q),
C_n^causal = n max(H(P),H(Q)) + O(1).
This does NOT solve the equal-entropy logarithmic problem.

Explicit example: P uniform on eight symbols, Q=(1/3,2/3).
For every n, h_2(1/3)/8 <= C_n^causal-3n < 14.

Compile the LaTeX twice with pdflatex.
Run python3 verify_bounded_tax.py to reproduce the structural checks
and numerical values. Python 3.11+, standard library only.
All-horizon and adaptive correctness are proved in the document.
