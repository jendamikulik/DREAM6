"""Exact structural checks for the bounded causal entropy construction.

Python 3.11+, standard library only. The all-horizon proof is in the PDF;
this script checks integer partitions, an exact block coupling, and constants.
"""
from fractions import Fraction as F
from itertools import product
from math import log2, sqrt
import json
from pathlib import Path

def mountain(n):
    if n < 1:
        raise ValueError('n must be positive')
    if n == 1:
        return [1]
    k = (n+2).bit_length()-3
    s = 2**k
    tail = [2**j for j in range(k)]
    remaining = n-2*sum(tail)
    count = (remaining+s-1)//s
    a, r = divmod(remaining, count)
    return tail+[a+1]*r+[a]*(count-r)+tail[::-1]

def interval_coupling(a, b):
    """Exact common-uniform interval coupling as (row,column,mass) atoms."""
    a, b = list(a), list(b)
    i = j = 0
    atoms = []
    while i < len(a) and j < len(b):
        mass = min(a[i], b[j])
        if mass:
            atoms.append((i, j, mass))
        a[i] -= mass
        b[j] -= mass
        if a[i] == 0:
            i += 1
        if b[j] == 0:
            j += 1
    assert not any(a) and not any(b)
    return atoms

def entropy(probs):
    return -sum(float(p)*log2(float(p)) for p in probs if p)

def verify_block(p, q):
    a = [F(1,8**p)]*(8**p)
    b = []
    for word in product([0,1], repeat=q):
        b.append(F(2**sum(word), 3**q))
    atoms = interval_coupling(a,b)
    rows = [F(0)]*len(a)
    cols = [F(0)]*len(b)
    degrees = [0]*len(a)
    for i,j,mass in atoms:
        rows[i] += mass
        cols[j] += mass
        degrees[i] += 1
    assert rows == a and cols == b
    split = sum(d > 1 for d in degrees)
    assert split <= len(b)-1
    return {'p':p, 'q':q, 'split_cells':split,
            'joint_entropy':entropy([x[2] for x in atoms]),
            'proved_entropy_upper':3*p+q*2**(-q/2)}

for n in list(range(1,10001))+[10**6,10**12,10**50]:
    lengths = mountain(n)
    assert sum(lengths) == n
    assert lengths[0] == lengths[-1] == 1
    assert all(2*p >= q for q,p in zip(lengths,lengths[1:]))
    # To see both blocks in any coupled component takes n+2 actions.
    prefix = 0
    for q in lengths[:-1]:
        prefix += q
        assert (prefix+1)+(n-prefix+1) == n+2

# Rational certificates used in the analytic bound < 14.
assert F(1,2) < F(71,100)**2
assert F(71,100)+1+1+F(1,2)+F(1,16)+F(1,1024) < F(33,10)
assert 45**2 < 2*32**2  # 3/(2 sqrt(2)) < 16/15
assert 1+2*F(33,10)+6*F(16,15) == 14

hq = log2(3)-2/3
series = sum(2**j*2.0**(-2**j/2) for j in range(12))
out = {
    'structural_checks':'passed for 1..10000 and three large integer horizons',
    'exact_rational_certificates':'passed',
    'H_Q':hq, 'exact_E1_formula':'h_2(1/3)/8', 'E1_approx':hq/8,
    'uniform_upper_formula':'H(Q)+2*sum_j 2^j*2^(-2^j/2)+9/sqrt(2)',
    'uniform_upper_approx':hq+2*series+9/sqrt(2),
    'blocks':[verify_block(1,1),verify_block(1,2),verify_block(2,4)],
    'example_mountain_n100':mountain(100)
}
Path(__file__).with_name('verification.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
