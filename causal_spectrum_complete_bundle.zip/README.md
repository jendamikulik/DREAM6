# Exact causal sources — complete manuscript and reproducibility bundle

The standalone English manuscript contains 16 pages, a map of 11 primary references, and complete arguments for the full-history causal model. Compile `causal_spectrum_complete.tex` twice with `pdflatex`. The compiled PDF is under `output/pdf/`.

## Mathematical scope

* Global exact realization on finite controlled trees, with a stochastic information-spectrum sandwich and a Shannon gap at most log2(e).
* Simultaneous positive-order Rényi bounds, exact min-entropy, and a bounded compatibility cost relative to coupling ALL adaptive transcripts.
* Explicit Bellman comparison and the sharp square-root coefficient for any fixed finite equal-entropy action family, including zero-variance endpoints.
* W1 rigidity of near-optimal information spectra, greedy moment convergence, optimal quantile asymptotics, and a counterexample to variance rigidity for arbitrary near-optimal seeds.
* The equal-positive-variance O(log n) bound uses the stated external Fan–Grama–Liu theorem. Its universal constant is not numerically specified.
* Exact rational finite-horizon crash-pair enclosures and a small example with C_2 = 27/4 bits.

The controlled-variance limit profile has a predecessor in Peng–Zhou. Ordinary minimum-entropy coupling, information-spectrum converses, and Rényi approximations also have substantial prior literature. The manuscript separates these facts from the causal-tree realization and its consequences. It does not certify priority, independent peer review, or proof-assistant verification. A sharp logarithmic coefficient and a matching logarithmic lower bound remain open here.

## Reproduce (Python standard library only)

```sh
python3 causal_core.py
python3 verify_extensions.py
python3 certify_crash_pair.py
python3 causal_entropy_explained.py --help
python3 causal_entropy_explained.py --check results/toy_seed.json
```

`causal_core.py` proves the small rational instance by exhaustive history reconstruction and matching exact bounds. `verify_extensions.py` checks Rényi moment inequalities, min-entropy and shifted tails on three finite examples; it imports `causal_entropy_explained.py`. `certify_crash_pair.py` reproduces outward rational intervals and the manuscript table. JSON files record exact finite checks or interval calculations, not a machine verification of the universal analytic theorems. The crash table is an analytic enclosure of the optimum, not direct numerical optimization at those horizons.

No approximate replacement of the irrational crash law is used. Seeds may depend on the horizon. No infinite horizon-consistent seed or polynomial-time construction is claimed.
