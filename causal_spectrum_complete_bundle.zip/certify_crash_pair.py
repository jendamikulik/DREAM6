#!/usr/bin/env python3
"""Exact rational audit of constants and finite-n enclosures.

No third-party dependencies. This certifies the arithmetic in the analytic
bound, not the universal theorem in a proof assistant. It does NOT compute
optimal seeds at the displayed enormous horizons.
"""
from fractions import Fraction as F
from functools import lru_cache
from math import isqrt
from pathlib import Path
import json

DIGITS=48
SCALE=10**DIGITS
TERMS=64

def ln_unit(x):
    assert 1 <= x <= 2
    z=(x-1)/(x+1)
    z2=z*z
    power=z
    partial=F(0)
    for j in range(TERMS):
        partial+=2*power/F(2*j+1)
        power*=z2
    remainder=2*power/(F(2*TERMS+1)*(1-z2))
    return partial,partial+remainder

LN2=ln_unit(F(2))

@lru_cache(None)
def ln_bounds(x):
    assert x > 0
    k=0
    while x < 1:
        x*=2; k-=1
    while x > 2:
        x/=2; k+=1
    lo,hi=ln_unit(x)
    if k >= 0:
        return lo+k*LN2[0],hi+k*LN2[1]
    return lo+k*LN2[1],hi+k*LN2[0]

def log2_bounds(x):
    a,b=ln_bounds(x)
    vals=[a/LN2[0],a/LN2[1],b/LN2[0],b/LN2[1]]
    return min(vals),max(vals)

def entropy_bounds(q):
    lo=hi=F(0)
    for p in [q,q,1-2*q]:
        a,b=log2_bounds(p)
        lo-=p*b; hi-=p*a
    return lo,hi

def sqrt_bounds(x):
    assert x>=0
    k=isqrt(x.numerator*SCALE*SCALE//x.denominator)
    lo,hi=F(k,SCALE),F(k+1,SCALE)
    assert lo*lo <= x <= hi*hi
    return lo,hi

def atan_bounds(x,terms=48):
    assert 0<x<1
    s=sum(((-1)**k*x**(2*k+1)/F(2*k+1) for k in range(terms)),F(0))
    next_term=x**(2*terms+1)/F(2*terms+1)
    return (s,s+next_term) if terms%2==0 else (s-next_term,s)

def decimal_bound(x,places,up=False):
    scale=10**places
    y=x*scale
    k=-((-y.numerator)//y.denominator) if up else y.numerator//y.denominator
    sign='-' if k<0 else ''
    k=abs(k)
    return f'{sign}{k//scale}.{k%scale:0{places}d}'

def interval_text(lo,hi,places=40):
    return [decimal_bound(lo,places),decimal_bound(hi,places,True)]

def main():
    # Seed a narrow bracket using decimal candidates only. Both signs are
    # checked rigorously below; no trust in the proposed digits is required.
    q0=F('0.41003242818198554')
    # Rational bisection with rigorous sign bounds; 90 iterations gives
    # far more accuracy than the 12-place finite-n table requires.
    ql,qh=q0-F(1,10**16),q0+F(1,10**16)
    assert entropy_bounds(ql)[0] > F(3,2)
    assert entropy_bounds(qh)[1] < F(3,2)
    for _ in range(90):
        mid=(ql+qh)/2
        lo,hi=entropy_bounds(mid)
        if lo > F(3,2): ql=mid
        elif hi < F(3,2): qh=mid
        else: raise AssertionError('Increase logarithm precision')
    assert entropy_bounds(ql)[0] > F(3,2) > entropy_bounds(qh)[1]
    # h(q) decreases on (1/3,1/2), so the unique root is inside.
    rlo,rhi=ql/(1-2*ql),qh/(1-2*qh)
    llo=log2_bounds(rlo)[0]
    lhi=log2_bounds(rhi)[1]
    # 2q(1-2q) decreases in this bracket; logarithm increases.
    vlo=2*qh*(1-2*qh)*llo*llo
    vhi=2*ql*(1-2*ql)*lhi*lhi
    blo=sqrt_bounds(vlo)[0]
    bhi=sqrt_bounds(vhi)[1]
    ar5,ar239=atan_bounds(F(1,5)),atan_bounds(F(1,239))
    pi_lo=16*ar5[0]-4*ar239[1]
    pi_hi=16*ar5[1]-4*ar239[0]
    k_lo=sqrt_bounds(2/pi_hi)[0]
    k_hi=sqrt_bounds(2/pi_lo)[1]
    c_lo=k_lo*(F(1,2)-bhi)
    c_hi=k_hi*(F(1,2)-blo)
    assert F(9,20) < blo < bhi < F(1,2)
    # Validate the uniform constants B <= 1, m3 <= 1/4, C <= 1.
    for p in [F(1,2),F(1,4),ql,qh,1-2*ql,1-2*qh]:
        l,u=log2_bounds(p)
        assert max(abs(-u-F(3,2)),abs(-l-F(3,2))) < 1
    assert vhi<F(1,4) and pi_lo>2 and LN2[0]>F(2,3)
    C_upper=F(20,19)*(F(1,4)/(3*F(9,20)**2)+F(1,2))
    assert C_upper < 1
    log10=ln_bounds(F(10))
    rows=[]
    for exponent in [8,12,16,20,24,32,48]:
        assert exponent%4==0
        n=10**exponent
        root_n=10**(exponent//2)
        fourth_root=10**(exponent//4)
        tlo=sqrt_bounds(exponent*log10[0])[0]
        thi=sqrt_bounds(exponent*log10[1])[1]
        # Proven analytic error, upper-rounded with rational arithmetic.
        error=F(17,2)*thi/fourth_root+F(3,root_n)/tlo+F(2,root_n)
        lower=max(F(0),c_lo-error)
        upper=c_hi+error
        row={'n':str(n),'power_of_ten':exponent,
             'normalized_C_lower':decimal_bound(lower,12),
             'normalized_C_upper':decimal_bound(upper,12,True),
             'error_bound_upper':decimal_bound(error,12,True),
             'excludes_half_coefficient':lower > c_hi/2}
        rows.append(row)
        print(json.dumps(row),flush=True)
    result={'status':'PASS_EXACT_RATIONAL_ARITHMETIC',
      'scope':'Arithmetic certification of analytic enclosures, not direct computation of optimal seeds.',
      'q_interval':interval_text(ql,qh),
      'sigma_P_exact':'1/2','sigma_Q_interval':interval_text(blo,bhi),
      'variance_Q_interval':interval_text(vlo,vhi),
      'coefficient_interval':interval_text(c_lo,c_hi),
      'C_upper_exact':str(C_upper),
      'logarithm_terms':TERMS,'bisection_steps':90,
      'error_formula':'(17/2)*sqrt(ln(n))/n^(1/4) + 3/sqrt(n*ln(n)) + 2/sqrt(n), n>=16',
      'rows':rows}
    out=Path(__file__).resolve().parent
    (out/'crash_pair_certificate.json').write_text(json.dumps(result,indent=2)+'\n')
    table='\n'.join(f"$10^{{{r['power_of_ten']}}}$ & {r['normalized_C_lower']} & {r['normalized_C_upper']} \\\\" for r in rows)
    (out/'crash_table.tex').write_text(table+'\n')
    print('coefficient interval:',result['coefficient_interval'])
    print('sigma_Q interval:',result['sigma_Q_interval'])

if __name__=='__main__': main()
