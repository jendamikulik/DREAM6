#!/usr/bin/env python3
"""Exact finite checks for the spectral consequences.
Run beside causal_entropy_explained.py. Standard library only.
These finite checks do not replace the universal proofs in the LaTeX.
"""
from fractions import Fraction as F
from pathlib import Path
import json
import causal_entropy_explained as core


def main():
    cases = [
        ('binary', [[F(1,2)]*2, [F(1,3),F(2,3)]], 3),
        ('dyadic_equal_entropy', [[F(1,2)]+[F(1,32)]*16,
                                  [F(1,4)]*2+[F(1,16)]*8], 2),
        ('three_actions', [[F(1,2)]*2,[F(1,3)]*3,[F(1,6),F(5,6)]], 2),
    ]
    result=[]
    for name,laws,depth in cases:
        tree=core.make_tree(laws,depth)
        cards=core.make_seed(tree)
        core.check_seed(laws,depth,cards)
        env=core.profile(tree,cards)
        for alpha in [2,3,4,8,16]:
            mz=sum(jump*p**(alpha-1) for p,jump in env)
            mj=sum(c['weight']**alpha for c in cards)
            core.require(mz/alpha<=mj<=mz,'Renyi moment bounds failed')
        # For alpha=1/2, certify the upper moment bound with rational roots.
        mz_lo=sum(jump/core.sqrt_interval(p)[1] for p,jump in env)
        mj_hi=sum(core.sqrt_interval(c['weight'])[1] for c in cards)
        core.require(mj_hi<=2*mz_lo,'Renyi 1/2 upper bound failed')
        # Quantile precursor at every discontinuity for integer shifts 0..5.
        tails=0
        for shift in range(6):
            factor=2**shift
            thresholds={p for p,jump in env}|{c['weight']*factor for c in cards}
            for u in thresholds:
                lhs=sum(c['weight'] for c in cards if c['weight']<u/factor)
                rhs=sum(jump for p,jump in env if p<u)+F(1,factor)
                core.require(lhs<=rhs,'Shifted tail bound failed')
                tails+=1
        brute=None
        if name!='dyadic_equal_entropy':
            policies=core.all_policies(tree)
            brute=min(max(tree[v]['mass'] for v in leaves) for leaves in policies)
            core.require(max(c['weight'] for c in cards)==brute,'Min-entropy failed')
        row=dict(case=name,depth=depth,histories=len(tree),atoms=len(cards),
                 integer_renyi_orders=[2,3,4,8,16],
                 half_order_upper='PASS_RATIONAL',shifted_tail_knots=tails,
                 min_entropy_bruteforce=str(brute) if brute is not None else 'NOT_ENUMERATED',
                 status='PASS_EXACT_FINITE_CHECKS')
        result.append(row)
        print(json.dumps(row))
    Path(__file__).with_name('extension_checks.json').write_text(json.dumps(result,indent=2)+'\n')


if __name__=='__main__':
    main()
