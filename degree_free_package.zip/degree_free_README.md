# Univerzální horní mez bez omezení stupně

Výzkumný rukopis: `degree_free_ceiling.pdf` (5 stran).
Úplný LaTeX: `degree_free_ceiling.tex`.

Pro M(N), největší délku souvislého bloku přísných selhání log-konkavity
v polynomu nezávislosti libovolného lesa s nejvýše N vrcholy, rukopis dokazuje:

    M(N) < 8 N / log_2(log_2 N)   pro N >= 2^65536.

Tedy M(N)=o(N), a to BEZ omezení maximálního stupně. Stupeň může růst
libovolně s N. Jde o rozšíření dřívější horní meze pro každé pevné omezení
stupně na jednotnou horní mez přes všechny lesy.

Hlavní krok:

    sum_{u soused v} Corr(S_u,S_v)^2 <= lambda_v.

S_v je indikátor obsazení vrcholu v hard-core modelu. Z lokálního odhadu
plyne norma vážené matice sousednosti nejvýše 2 sqrt(Lambda), kde Lambda
omezuje aktivity. Krátké cesty se pak odhadují váženými procházkami,
dlouhé cesty geometrickým poklesem korelace. Kombinace s entropií a
přesnou identitou pro konvexní pravděpodobnostní okno dává uvedenou větu.

## Konečný práh pro libovolnou požadovanou proporci

Pro celé m>=1:

    Lambda_m=4^m
    B_m=2^(m+1)
    K_m=ceil(log_2(12m^2))
    R_m=(Lambda_m+1)K_m
    N_m=24m^3 B_m^R_m

Pak M(N)<N/m pro každé N>=N_m. Žádný maximální stupeň se v prahu nevyskytuje.

Rukopis dále dokazuje explicitní polynomiální úsporu pro bloky ve vzdálenosti
alespoň delta*alpha od horního konce. Proto se každý blok délky n^(1-o(1))
musí přibližovat k alpha i u rodin stromů s neomezeným stupněm.

## Reprodukce

Python 3.10+, pouze standardní knihovna:

    python verify_degree_free.py

Úspěšný běh vypíše:

    PASS: 16 universal algebra checks; 25 graph/activity cases;
    2230 covariance pairs; 8119 total checks.

A vytvoří `degree_free_certificate.json` se SHA-256 ověřovače, přesnými
prahy a rozsahem kontrol. Algebraické identity se kontrolují nad přesným
polynomiálním okruhem; pravděpodobnosti nad racionálními čísly. Výčtový audit
je pouze konečná nezávislá kontrola na pěti lesích a pěti volbách aktivit.
Univerzální tvrzení dokazuje psaný argument, nikoli konečné testování.
Nejde o formalizaci v důkazovém asistentu ani o nezávislou recenzi.

PDF lze znovu sestavit dvěma běhy `pdflatex degree_free_ceiling.tex`.

## Stav novosti

Samotný exponent jedna u subkubických stromů není předkládán jako objev.
Ten už uvádí preprint S. Christophera z 12. září 2026.
Zde je předmětem práce univerzální HORNÍ mez přes všechny lesy.
V prověřených primárních zdrojích nebyla tato horní mez nalezena.
Úplný Christopherův preprint však nebyl dostupný, takže jeho obsah nebyl
úplně porovnán. Prvenství této věty není potvrzené a rukopis je netvrdí.

Prověřené související zdroje:
- Efthymiou et al., arXiv:2307.07727.
- Chen et al., arXiv:2404.04668.
- Fang et al., arXiv:2609.20961v1.
- Christopher, Figshare 33684715 (indexovaný abstrakt).

28. září 2026.
