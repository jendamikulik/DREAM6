#!/usr/bin/env python3
"""Exact finite certificates for a genuine logarithmic causal overhead.

P: one 1/16 atom, ten 1/32 atoms, twelve 1/64 atoms, 56 1/128 atoms.
Q: sixteen 1/32 atoms and 64 1/128 atoms.
All exact checks use Python integers/Fraction. NumPy is optional for the
floating-point illustration. The all-horizon theorem is in the LaTeX/PDF.
"""
import argparse
from fractions import Fraction as F
import heapq
import json
from math import comb
from pathlib import Path

P_LENGTHS = [4]+[5]*10+[6]*12+[7]*56
Q_LENGTHS = [5]*16+[7]*64


def packing_map(source, target):
    """Fill labeled target bins with sorted source atoms, using integer masses."""
    finest = max(max(source), max(target))
    heap = [(-(1 << (finest-k)), j) for j, k in enumerate(target)]
    heapq.heapify(heap)
    assigned = [0]*len(target)
    mapping = []
    for k in source:
        mass = 1 << (finest-k)
        neg_capacity, j = heapq.heappop(heap)
        capacity = -neg_capacity
        assert mass <= capacity
        assigned[j] += mass
        mapping.append(j)
        if mass < capacity:
            heapq.heappush(heap, (mass-capacity, j))
    assert not heap
    assert assigned == [1 << (finest-k) for k in target]
    return mapping


def algebra_checks():
    distributions = []
    for lengths in (P_LENGTHS, Q_LENGTHS):
        total = sum((F(1, 2**k) for k in lengths), F(0))
        assert total == 1
        moments = [sum((F((k-6)**d, 2**k) for k in lengths), F(0))
                   for d in range(5)]
        distributions.append(moments)
    assert distributions[0][:4] == [1, 0, 1, F(-3, 8)]
    assert distributions[1][:4] == [1, 0, 1, 0]
    alpha = [F(1, 16), F(5, 16), F(3, 16), F(7, 16), F(0)]
    beta = [F(0), F(1, 2), F(0), F(1, 2), F(0)]
    assert [a-b for a, b in zip(alpha, beta)] == [F(1, 16), F(-3, 16), F(3, 16), F(-1, 16), 0]
    # On 0 <= t <= 1/4, (1-t^2/24)^3 >= (383/384)^3 > 1/2.
    assert F(383, 384)**3 > F(1, 2)
    assert F(3, 2)**2 > 2
    assert F(2)**3 > 6
    assert F(1)-F(3, 16)*2 == F(5, 8)
    assert F(16)/F(5, 8) == F(128, 5)
    assert (F(3, 2)/8)/F(5, 8) == F(3, 10)
    return [[str(x) for x in m] for m in distributions]


def exact_run(max_n):
    cdf, denominator = [1], 1
    prev_excess = F(0)
    harmonic = F(0)
    rows = []
    sources = {0: [0]}
    certificates = {
        'action_symbol_information_lengths': {'P': P_LENGTHS, 'Q': Q_LENGTHS},
        'decoding': 'Read t=maps[action][seed_atom], then '
                    'output,next_state=divmod(t,previous_atom_count).',
        'horizons': {}}
    for n in range(1, max_n+1):
        padded = [0]*4+cdf+[denominator]*4
        # Grid x=-2n,...,2n, centering information by 6n.
        # At the previous stage, padded[i+2] corresponds to x.
        a = [padded[i+4]+5*padded[i+3]+3*padded[i+2]+7*padded[i+1]
             for i in range(len(padded)-4)]
        b = [8*(padded[i+3]+padded[i+1])
             for i in range(len(padded)-4)]
        denominator *= 16
        cdf = [min(x, y) for x, y in zip(a, b)]
        assert cdf[-1] == denominator
        assert all(x <= y for x, y in zip(cdf, cdf[1:]))
        counts = {}
        prev_cdf = 0
        for i, value in enumerate(cdf):
            diff = value-prev_cdf
            prev_cdf = value
            if diff:
                counts[4*n+i] = diff << i
        total = sum((F(count, 2**k) for k, count in counts.items()), F(0))
        entropy = sum((F(k*count, 2**k) for k, count in counts.items()), F(0))
        assert total == 1
        excess = entropy-6*n
        increment = F(sum(abs(x-y) for x, y in zip(a, b)), 2*denominator)
        assert excess-prev_excess == increment
        assert increment >= F(1, 2048*n)
        harmonic += F(1, n)
        assert harmonic/2048 <= excess < F(128, 5)+F(3, 10)*harmonic
        prev_excess = excess
        rows.append({'n': n, 'excess_fraction': str(excess),
                     'excess_float': float(excess),
                     'increment_fraction': str(increment)})
        if n <= 2:
            source = [k for k, count in sorted(counts.items()) for _ in range(count)]
            prev = sources[n-1]
            maps = {}
            for name, lengths in [('P', P_LENGTHS), ('Q', Q_LENGTHS)]:
                target = [k+j for k in lengths for j in prev]
                maps[name] = packing_map(source, target)
            certificates['horizons'][str(n)] = {
                'seed_atom_information_lengths': source,
                'previous_atom_count': len(prev), 'maps': maps,
                'exact_product_partition_verified': True}
            sources[n] = source
    assert rows[0]['excess_fraction'] == '1/8'
    assert rows[1]['excess_fraction'] == '7/32'
    return rows, certificates


def floating_run(max_n):
    import numpy as np
    alpha = np.array([1, 5, 3, 7, 0], dtype=float)/16
    beta = np.array([0, 8, 0, 8, 0], dtype=float)/16
    cdf, excess = np.array([1.]), 0.
    rows = []
    checkpoints = {1, 2, 10, 100, 1000, 5000, 10000, max_n}
    for n in range(1, max_n+1):
        padded = np.r_[np.zeros(4), cdf, np.ones(4)]
        a, b = np.convolve(padded, alpha, 'valid'), np.convolve(padded, beta, 'valid')
        increment = .5*float(np.abs(a-b).sum())
        excess += increment
        cdf = np.minimum(a, b)
        if n in checkpoints:
            rows.append({'n': n, 'excess_approx': excess,
                         'increment_approx': increment,
                         'n_times_increment_approx': n*increment})
    return rows


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--exact-n', type=int, default=128)
    parser.add_argument('--float-n', type=int, default=10000,
                        help='0 skips the optional NumPy illustration.')
    args = parser.parse_args()
    if args.exact_n < 2:
        parser.error('--exact-n must be at least 2')
    moments = algebra_checks()
    rows, certificates = exact_run(args.exact_n)
    result = {'exact_checks': 'passed', 'centered_moments_orders_0_to_4': moments,
              'exact_horizons': args.exact_n, 'exact_rows': rows,
              'float_rows': floating_run(args.float_n) if args.float_n else [],
              'scope': 'The analytic all-horizon proof is in the accompanying '
                       'LaTeX/PDF. Finite computations are supplemental checks.'}
    base = Path(__file__).resolve().parent
    (base/'logarithmic_verification.json').write_text(json.dumps(result, indent=2)+'\n')
    (base/'logarithmic_decoder_n2.json').write_text(json.dumps(certificates, separators=(',', ':'))+'\n')
    print('Exact algebra, entropy increments, and dyadic partitions: passed.')
    print('Exact horizons:', args.exact_n)
    print('Decoder source sizes:', {n: len(c['seed_atom_information_lengths'])
                                    for n, c in certificates['horizons'].items()})
    for row in result['float_rows']:
        print(row)


if __name__ == '__main__':
    main()
