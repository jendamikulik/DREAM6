#!/usr/bin/env python3
"""Exact arithmetic audit accompanying entropy_bound.tex.

The universal graph theorem is proved in the manuscript. This program proves
the three rational comparisons that certify the infinite degree supremum,
encloses its logarithmic constant, audits all labelled simple graphs up to six
vertices, and verifies an explicit tree upper bound. No floating-point number
is used in a proof comparison. This is NOT a proof-assistant certificate.
"""
from fractions import Fraction as Q
from decimal import Decimal, localcontext
import json


def log_interval(x, terms=48):
    """Rational enclosure: log x = 2 sum y^(2k+1)/(2k+1), y=(x-1)/(x+1)."""
    assert x >= 1
    y = (x-1)/(x+1)
    lo = 2*sum((y**(2*k+1)/Q(2*k+1) for k in range(terms)), Q(0))
    tail = 2*y**(2*terms+1)/(Q(2*terms+1)*(1-y*y))
    return lo, lo+tail


def graph_statistics(n, edges):
    neighbors = [0]*n
    for u,v in edges:
        neighbors[u] |= 1 << v
        neighbors[v] |= 1 << u
    z, mass, alpha, witness = [0]*(1 << n), [0]*(1 << n), [0]*(1 << n), [0]*(1 << n)
    z[0] = 1
    for s in range(1, 1 << n):
        bit = s & -s
        v = bit.bit_length()-1
        absent = s ^ bit
        present = absent & ~neighbors[v]
        z[s] = z[absent]+z[present]
        mass[s] = mass[absent]+mass[present]+z[present]
        if alpha[absent] >= 1+alpha[present]:
            alpha[s], witness[s] = alpha[absent], witness[absent]
        else:
            alpha[s], witness[s] = 1+alpha[present], witness[present] | bit
    full = (1 << n)-1
    a = witness[full]
    e_b = sum(not(a >> u & 1) and not(a >> v & 1) for u,v in edges)
    remaining, components = full, 0
    while remaining:
        components += 1
        frontier = remaining & -remaining
        while frontier:
            bit = frontier & -frontier
            frontier ^= bit
            if not remaining & bit:
                continue
            remaining ^= bit
            frontier |= neighbors[bit.bit_length()-1] & remaining
    beta = len(edges)-n+components
    budget = alpha[full]-components+beta-e_b
    direct = sum((neighbors[v] & a).bit_count()-1 for v in range(n) if not(a >> v & 1))
    assert budget == direct >= 0
    b_mask = full ^ a
    b_size = b_mask.bit_count()
    weighted_numerator = 0
    subset = b_mask
    while True:
        if alpha[subset] == subset.bit_count():
            weighted_numerator += 4**(b_size-subset.bit_count())
        if subset == 0:
            break
        subset = (subset-1) & b_mask
    partition_ratio = Q(z[full]*4**b_size, weighted_numerator)
    correction = components+e_b-beta
    assert partition_ratio**3 >= Q(34,5)**alpha[full]*Q(20,17)**correction
    return z[full], mass[full], alpha[full], budget, beta


def upper_witness(factors):
    A, B, U, V, a0, a1, n = 1, 1, 0, 1, 0, 1, 1
    levels = []
    for b in factors:
        A, B, U, V, a0, a1, n = (
            (A+B)**b, A**b,
            b*(U+V)*(A+B)**(b-1), A**b+b*U*A**(b-1),
            b*max(a0,a1), 1+b*a0, 1+b*n)
        levels.append({'b': b, 'n': n, 'alpha': max(a0,a1)})
    return U+V, (A+B)*max(a0,a1), n, max(a0,a1), levels


def main():
    checks = [
        (10**3*17**2, 20**2*9**3),
        (40**3*17**4, 20**4*33**3),
        (5**3*17**5, 20**5*4**3),
    ]
    assert all(left < right for left,right in checks)
    l_lo, l_hi = log_interval(Q(2))
    r_lo, r_hi = log_interval(Q(20,17))
    gamma_lo, gamma_hi = r_lo/(6*l_hi), r_hi/(6*l_lo)
    c_lo, c_hi = Q(1,2)-gamma_hi, Q(1,2)-gamma_lo
    assert Q(4609224577271628,10**16) < c_lo
    assert c_hi < Q(4609224577271629,10**16)
    audits = []
    for n in range(1,7):
        possible = [(u,v) for u in range(n) for v in range(u+1,n)]
        forests = 0
        for mask in range(1 << len(possible)):
            edges = [e for k,e in enumerate(possible) if mask >> k & 1]
            z, mass, alpha, budget, beta = graph_statistics(n,edges)
            # gamma_lo <= gamma, so this tests a slightly STRONGER inequality.
            assert Q(mass,z)-Q(alpha,2)+gamma_lo*budget >= 0
            forests += beta == 0
        audits.append({'n': n, 'simple_graphs': 1 << len(possible), 'forests': forests,
                       'mean_and_partition_inequalities': 'PASS_EXACT'})
    factors = [2,1,3,9,6,9,8,5]
    P,Qden,n,alpha,levels = upper_witness(factors)
    assert (n,alpha) == (255286,177161)
    gap = 47330186*Qden-10**8*P
    assert gap > 0
    with localcontext() as ctx:
        ctx.prec = 55
        display = lambda r: str(Decimal(r.numerator)/Decimal(r.denominator))
        interval_display = [display(c_lo), display(c_hi)]
        upper_display = str(Decimal(P)/Decimal(Qden))
    report = {
        'status': 'PASS_EXACT', 'proof_assistant_certificate': False,
        'universal_proof_location': 'entropy_bound.tex, Theorems 1 and 5',
        'exact_infimum_determined': False,
        'constant': '1/2 - log(20/17)/(6 log 2)',
        'degree_supremum_integer_checks': checks,
        'constant_rational_enclosure': {
            'lower': str(c_lo), 'upper': str(c_hi),
            'decimal_display_only': interval_display},
        'all_labelled_graphs_audits': audits,
        'upper_witness': {'factors_bottom_up': factors, 'levels': levels,
            'n': n, 'alpha': alpha, 'ratio_display_only': upper_display,
            'rational_upper_bound': '47330186/100000000',
            'positive_integer_gap_bit_length': gap.bit_length()}
    }
    print(json.dumps(report,indent=2))


if __name__ == '__main__':
    main()
