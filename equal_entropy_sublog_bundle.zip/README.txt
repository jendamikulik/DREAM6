EXACT OPTIMAL EQUAL-ENTROPY CAUSAL SEED

Proved for the displayed 41/40-symbol pair of entropy 5:
1/2 <= C_n^causal - 5n = H(R_n)-5n = O(sqrt(log(n+1))).
The source is finite, entropy-optimal, and exact for every adaptive policy.
Bounded O(1) overhead is NOT proved.

More generally, for any finite dyadic action pair, the CDF recursion in
Theorem 4 computes the exact optimum over ALL discrete causal seeds.
Its optimality proof is elementary; the asymptotic rate uses Theorem 1.1
of Wu, Ma, Sang and Fan (2020), https://arxiv.org/abs/2002.00307.
All hypotheses are checked in the note.

Compile the LaTeX twice with pdflatex.

Exact checks only (Python 3.11+, standard library):
  python3 dyadic_causal_seed.py --exact-n 128 --float-n 0

Also run the numerical n=5000 experiment (requires NumPy):
  python3 dyadic_causal_seed.py

The JSON certificate contains complete maps for horizons 1 and 2.
For action a and source atom s at remaining horizon m:
  t = certificate['horizons'][str(m)]['maps'][a][s]
  output, next_state = divmod(t, previous_atom_count)
Source atom probabilities are 2**(-information_length).
All product output/continuation marginals are checked with integer arithmetic.
The float64 values are approximations, not exact numerical certificates.
