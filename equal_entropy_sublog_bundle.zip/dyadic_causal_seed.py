#!/usr/bin/env python3
"""Exact causal seed construction for the 41/40-symbol equal-entropy pair.

Standard library: exact integer CDFs, dyadic atom counts, and deterministic
decoder certificates through horizon 2. Optional NumPy: exploratory float64
entropy bounds through horizon 5000. The analytic rate proof is in the PDF.
"""
import argparse
from fractions import Fraction as F
import heapq
import json
from pathlib import Path

P_LENGTHS = [3]+[5]*24+[7]*16
Q_LENGTHS = [4]*8+[6]*32

def step(cdf, denominator):
    """CDF on [-2n,2n], after centering information by 5n.

    Previous CDF has denominator 8**(n-1); new denominator is 8**n.
    Returns numerator arrays for the source and the two target profiles.
    """
    padded = [0]*4+cdf+[denominator]*4
    a = [padded[i]+6*padded[i+2]+padded[i+4]
         for i in range(len(padded)-4)]
    b = [4*(padded[i+1]+padded[i+3])
         for i in range(len(padded)-4)]
    return [min(x,y) for x,y in zip(a,b)], a, b

def histogram(cdf, n):
    """Returns {information_length: integer_number_of_atoms} exactly."""
    previous = 0
    counts = {}
    for i, value in enumerate(cdf):
        length = 3*n+i
        mass_numerator = value-previous
        previous = value
        assert mass_numerator >= 0
        if mass_numerator:
            counts[length] = mass_numerator << (length-3*n)
    return counts

def atom_lengths(counts):
    return [k for k,count in sorted(counts.items()) for _ in range(count)]

def packing_map(source, target):
    """Partition dyadic source atoms into labeled dyadic target bins.

    Source and target lists contain negative log2 atom probabilities.
    The resulting map is deterministic; all checks use integer masses.
    """
    finest = max(max(source), max(target))
    heap = [(-(1 << (finest-k)), j) for j,k in enumerate(target)]
    heapq.heapify(heap)
    mapping = []
    assigned = [0]*len(target)
    for k in source:
        mass = 1 << (finest-k)
        neg_cap, j = heapq.heappop(heap)
        cap = -neg_cap
        assert cap >= mass
        mapping.append(j)
        assigned[j] += mass
        if cap > mass:
            heapq.heappush(heap, (-(cap-mass), j))
    assert not heap
    assert assigned == [1 << (finest-k) for k in target]
    return mapping

def exact_run(max_n):
    cdf, denominator = [1], 1
    rows = []
    small_sources = {0:[0]}
    certificates = {'description':'Decode t=maps[horizon][action][seed_atom]; '
                    'then output, next_seed_atom = divmod(t, previous_atom_count).',
                    'action_symbol_information_lengths':{'P':P_LENGTHS,'Q':Q_LENGTHS},
                    'horizons':{}}
    for n in range(1,max_n+1):
        cdf, a, b = step(cdf, denominator)
        denominator *= 8
        assert cdf[-1] == denominator
        assert all(x <= y for x,y in zip(cdf,cdf[1:]))
        assert all(x <= y and x <= z for x,y,z in zip(cdf,a,b))
        counts = histogram(cdf,n)
        # Independent exact normalization and entropy from atom counts.
        total = sum((F(count,1 << k) for k,count in counts.items()), F(0))
        ent = sum((F(k*count,1 << k) for k,count in counts.items()), F(0))
        assert total == 1
        excess = ent-5*n
        rows.append({'n':n, 'source_excess_fraction':str(excess),
                     'source_excess_float':float(excess)})
        if n <= 2:
            source = atom_lengths(counts)
            prev = small_sources[n-1]
            maps = {}
            for name, lengths in [('P',P_LENGTHS),('Q',Q_LENGTHS)]:
                target = [k+j for k in lengths for j in prev]
                maps[name] = packing_map(source,target)
            small_sources[n] = source
            certificates['horizons'][str(n)] = {
                'seed_atom_information_lengths':source,
                'previous_atom_count':len(prev),
                'maps':maps,
                'target_product_marginals_verified_exactly':True}
    assert rows[0]['source_excess_fraction'] == '1/2'
    assert rows[1]['source_excess_fraction'] == '9/16'
    return rows, certificates

def floating_run(max_n):
    import numpy as np
    p = np.array([1,0,6,0,1],dtype=float)/8
    q = np.array([0,4,0,4,0],dtype=float)/8
    cdf = np.array([1.0])
    excess = 0.0
    checkpoints = {1,2,5,10,20,50,100,200,500,1000,2000,5000,max_n}
    rows = []
    for n in range(1,max_n+1):
        padded = np.r_[np.zeros(4),cdf,np.ones(4)]
        a = np.convolve(padded,p,'valid')
        b = np.convolve(padded,q,'valid')
        increment = .5*float(np.sum(np.abs(a-b)))
        excess += increment
        cdf = np.minimum(a,b)
        if n in checkpoints:
            rows.append({'n':n,'source_excess_approx':excess,
                         'last_increment_approx':increment})
    return rows

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--exact-n',type=int,default=128)
    parser.add_argument('--float-n',type=int,default=5000,
                        help='Set to 0 to skip optional NumPy experiment.')
    args = parser.parse_args()
    if args.exact_n < 2:
        parser.error('--exact-n must be at least 2')
    base = Path(__file__).resolve().parent
    rows, cert = exact_run(args.exact_n)
    result = {'exact_checks':'passed', 'exact_histograms_through':args.exact_n,
              'exact_entropy_rows':rows,
              'float_rows':floating_run(args.float_n) if args.float_n else [],
              'scope':'The proof in the accompanying note shows these constructed '
                      'seed entropies are exactly optimal. Float rows are numerical '
                      'approximations, not exact certificates.'}
    (base/'seed_verification.json').write_text(json.dumps(result,indent=2)+'\n')
    (base/'decoder_certificate_n2.json').write_text(json.dumps(cert,separators=(',',':'))+'\n')
    print('Exact checks:',args.exact_n,'horizons; decoder maps: horizons 1 and 2.')
    for r in rows:
        if r['n'] in {1,2,5,10,50,100,args.exact_n}:
            print('exact',r['n'],r['source_excess_float'])
    for r in result['float_rows']:
        if r['n'] in {1000,2000,5000,args.float_n}:
            print('float',r)

if __name__ == '__main__':
    main()
