Run with Python 3 standard library:
python3 verify_finite_witness.py --max-order 7 --output audit.json

The general finite-witness theorem is proved in the PDF.
The script checks finite instances and the exact 5717-vertex construction.
It is not a proof-assistant certificate.
Enumeration cost grows factorially with --max-order.
