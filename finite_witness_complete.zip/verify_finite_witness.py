#!/usr/bin/env python3
"""Exact supplemental audit and finite enumeration for finite_witness.pdf.

Usage: python3 verify_finite_witness.py --max-order 7 --output certificate.json
All proof-relevant comparisons use integers or Fraction. Decimal displays are
explicitly supplementary. Exhaustive enumeration covers every unlabelled tree
shape, with duplicates, by all parent-before-child labelled rooted trees.
Cost is factorial in --max-order. This is NOT a proof-assistant certificate.
The universal approximation bound is proved in the accompanying manuscript.
"""
import argparse
from fractions import Fraction as F
from itertools import product
from math import isqrt
import json


def tree_stats(parents):
    """Independent absent/present DP on an explicitly expanded tree."""
    n=len(parents)+1
    children=[[] for _ in range(n)]
    for v,p in enumerate(parents,1):
        assert 0<=p<v
        children[p].append(v)
    rows=[None]*n
    for v in range(n-1,-1,-1):
        A,B,U,V,a0,a1=1,1,0,1,0,1
        for w in children[v]:
            a,b,u,z,q0,q1=rows[w]
            U,A=U*(a+b)+A*(u+z),A*(a+b)
            V,B=V*a+B*u,B*a
            a0+=max(q0,q1); a1+=q0
        rows[v]=(A,B,U,V,a0,a1)
    A,B,U,V,a0,a1=rows[0]
    return F(U+V,A+B),max(a0,a1),(A,B,U,V,a0,a1)


def separator(parents,K):
    """Postorder version of the disjoint-charge separator proof."""
    n=len(parents)+1
    active=[1]*n; removed=set()
    for v in range(n-1,-1,-1):
        if active[v]>K:
            removed.add(v); active[v]=0
        if v: active[parents[v-1]]+=active[v]
    assert (K+1)*len(removed)<=n
    adj=[[] for _ in range(n)]
    for v,p in enumerate(parents,1): adj[v].append(p); adj[p].append(v)
    seen=set(removed)
    for v in range(n):
        if v in seen: continue
        todo=[v];seen.add(v);size=0
        while todo:
            u=todo.pop();size+=1
            for w in adj[u]:
                if w not in seen: seen.add(w);todo.append(w)
        assert size<=K
    return removed


def enumerate_minima(K):
    best=None; witness=None; count=0; separator_checks=0; rows=[]
    for n in range(1,K+1):
        for ps in product(*(range(v) for v in range(1,n))):
            mu,alpha,_=tree_stats(ps)
            ratio=mu/alpha; count+=1
            if best is None or ratio<best: best=ratio; witness=list(ps)
            for k in range(1,min(n,7)+1):
                separator(ps,k);separator_checks+=1
        # A rational outward bound for 20/sqrt(n+1).
        radius=F(20,isqrt(n+1))
        rows.append({'max_order':n,'a_K':str(best),'witness_parent_array':witness,
                     'certified_interval_using_written_theorem':[str(best-radius),str(best)]})
    return {'enumerated_parent_arrays':count,'separator_checks':separator_checks,
            'coverage':'Every unlabelled tree shape of order at most K, with duplicates.',
            'rows':rows,
            'warning':'At small K the lower enclosure is vacuous; no high-precision global enclosure has been computed.'}


def exact_witness():
    factors=[2,2,3,4,4,4,4]
    A,B,U,V,a0,a1,n=1,1,0,1,0,1,1
    history=[]
    for b in factors:
        A,B,U,V,a0,a1,n=((A+B)**b,A**b,
            b*(U+V)*(A+B)**(b-1),A**b+b*U*A**(b-1),
            b*max(a0,a1),1+b*a0,1+b*n)
        history.append({'branching':b,'order':n,'alpha':max(a0,a1),
                        'ratio':str(F(U+V,(A+B)*max(a0,a1)))})
    # Independently expand the actual tree and run ordinary vertex-by-vertex DP.
    parents=[]
    def grow(level,parent=None):
        v=len(parents)+1 if parent is not None else 0
        if parent is not None: parents.append(parent)
        if level:
            for _ in range(factors[level-1]): grow(level-1,v)
    grow(len(factors))
    mu,alpha,expanded=tree_stats(parents)
    assert expanded==(A,B,U,V,a0,a1)
    assert len(parents)+1==n==5717 and alpha==3908
    P,Q=U+V,alpha*(A+B)
    rational_gap=473393*Q-10**6*P
    root_gap=17*(5*Q-8*P)**2-25*Q**2
    assert rational_gap>0 and 5*Q-8*P>0 and root_gap>0
    assert mu/alpha==F(P,Q)
    return {'order':n,'alpha':alpha,'branching_factors_bottom_up':factors,
      'history':history,'ratio_numerator':str(P),'ratio_denominator':str(Q),
      'decimal_display_only':float(F(P,Q)),
      'positive_rational_bound_gap':str(rational_gap),
      'positive_algebraic_bound_gap':str(root_gap),
      'expanded_tree_DP':'PASS_EXACT'}


def weighted_budget_audit():
    checks=0
    for n in range(1,6):
        for ps in product(*(range(v) for v in range(1,n))):
            edges=[(p,v) for v,p in enumerate(ps,1)]
            for pattern in range(3):
                lam=[F(1,2**((v+pattern)%3)) for v in range(n)]
                Z=F(0); one=[F(0)]*n; pairs=[[F(0)]*n for _ in range(n)]
                for mask in range(1<<n):
                    if any((mask>>u)&1 and (mask>>v)&1 for u,v in edges): continue
                    weight=F(1); occupied=[v for v in range(n) if (mask>>v)&1]
                    for v in occupied: weight*=lam[v]
                    Z+=weight
                    for v in occupied:
                        one[v]+=weight
                        for u in occupied: pairs[v][u]+=weight
                p=[v/Z for v in one]; var=[v*(1-v) for v in p]
                cov=[[pairs[v][u]/Z-p[v]*p[u] for u in range(n)] for v in range(n)]
                for v in range(n):
                    neighbours=[u if w==v else w for u,w in edges if v in (u,w)]
                    assert sum((cov[v][u]**2/(var[v]*var[u]) for u in neighbours),F(0))<=F(1,2)
                # Verify the weaker rational covariance bound Cov <= 12 diag(Var)
                # by exact LDL/Schur-complement elimination (positive definite).
                M=[[(12*var[v] if v==u else 0)-cov[v][u] for u in range(n)] for v in range(n)]
                for k in range(n):
                    pivot=M[k][k];assert pivot>0
                    for i in range(k+1,n):
                        for j in range(k+1,n): M[i][j]-=M[i][k]*M[k][j]/pivot
                checks+=1
    return {'activity_patterns_checked':checks,'local_squared_correlation_budget':'PASS_EXACT',
            'rational_covariance_PSD_checks':'PASS_EXACT'}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--max-order',type=int,default=7)
    parser.add_argument('--output')
    args=parser.parse_args()
    if args.max_order<1: parser.error('--max-order must be positive')
    out={'status':'PASS_EXACT','proof_assistant_certificate':False,
      'universal_theorem_verified_by_this_program':False,
      'universal_theorem_source':'Sections 2-4 of finite_witness.pdf give the general proof.',
      'finite_enumeration':enumerate_minima(args.max_order),
      'weighted_audit':weighted_budget_audit(),'improved_upper_bound':exact_witness()}
    text=json.dumps(out,indent=2)
    if args.output:
        with open(args.output,'w') as f: f.write(text+'\n')
        print(json.dumps({'status':out['status'],'enumerated_parent_arrays':out['finite_enumeration']['enumerated_parent_arrays'],
          'separator_checks':out['finite_enumeration']['separator_checks'],
          'weighted_audit':out['weighted_audit'],
          'witness_order':5717,'witness_alpha':3908,
          'witness_ratio_decimal':out['improved_upper_bound']['decimal_display_only']}))
    else: print(text)
if __name__=='__main__': main()
