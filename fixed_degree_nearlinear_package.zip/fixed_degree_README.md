# Near-linear runs at maximum degree 65

The manuscript proves, for the extremal number of consecutive strict
log-concavity failures among trees with at most N vertices and maximum
degree at most 65,

    lim log M_65(N) / log N = 1.

The construction begins with an even path on 2s vertices and repeatedly
attaches 64 copies to a new root. Only the initial path changes with the
desired exponent; the degree bound remains 65.

## Files

- `fixed_degree_nearlinear.pdf`: nine-page manuscript.
- `fixed_degree_nearlinear.tex`: complete LaTeX source.
- `verify_fixed_degree.py`: executable interval-arithmetic verifier.
- `fixed_degree_certificate.json`: output of the executed verifier.

## Reproduce the finite certificate

```sh
python -m pip install python-flint==0.9.0
python verify_fixed_degree.py
```

The verified numerical instance is s = 2 (the four-vertex path).
For every integer height h >= 512 it gives a consecutive run of length
at least 2^(-209) N^(9/10), at indices below 0.997 alpha. The normalized
curvature interval has center 7/40 and radius 2^(-200), and the second
derivative of the logarithm of the exact lattice interpolant is at least
2048 throughout it.

The successful execution passed 855 checks. These include a complete
64,512-cell Fourier-annulus covering and 768 validated integration
segments. The JSON records the verifier's SHA-256 hash.

## Exact verification scope

The all-s near-linear theorem has a written analytic proof, including
the finite-height local limit theorem through two derivatives. Numerical
values of its curvature intervals and starting heights are supplied only
for s = 2. The numerical verifier does not claim to certify these values
for all s, nor does it enumerate the resulting trees or their coefficients.

The manuscript's recurrence, Fourier propagation, and lattice arguments
transfer the finite numerical certificate to every h >= 512. They remain
ordinary mathematical proofs, not formally checked proof-assistant code.
The distance from the top, run constant and starting height may depend on
the desired exponent. No linear-size run or uniform bulk separation as
the exponent tends to one is claimed.

This is a research draft prepared for Jan Mikulik with ChatGPT. The
literature comparison is based on the primary sources listed in the
manuscript and does not establish exhaustive publication priority.
