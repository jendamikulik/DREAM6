#!/usr/bin/env python3
"""Validated certificate for the P4 seed, b=64, all heights h>=512.

Run: python -m pip install python-flint==0.9.0
     python verify_fixed_degree.py

Uses Arb/Acb ball arithmetic, including validated integration. The companion
proof supplies the probabilistic identities and the all-height implications;
this is not a Lean-style formal verification of those analytic arguments.
No binary floating-point decision is used to certify an inequality.
"""
from fractions import Fraction as F
from pathlib import Path
import json
import hashlib
import sys

try:
    import flint
    from flint import arb, acb, ctx
except ImportError:
    raise SystemExit("Install the dependency: python -m pip install python-flint==0.9.0")

ctx.prec = 512
B, ORDER, DEPTH = 64, 32, 5
T, ANNULUS_END, CELL = 8192, 524288, 8
H, H0 = 512, 192
I = acb(0, 1)
checks = []


def check(name, condition):
    if not condition:
        raise AssertionError(name)
    checks.append(name)


def two(n):
    return F(2)**n


def ball(x):
    if isinstance(x, F):
        return arb(x.numerator) / x.denominator
    return arb(x)


def enclose(x, error):
    return x + arb(0, ball(error))


eta = arb(1)/128+arb(0,arb(1)/128)
for _ in range(12):
    lam=(2-eta)*(3-eta)**64
    eta=(5*lam+2)/(lam*lam+3*lam+1)
q, rho = (2-eta)/(3-eta),64*(2-eta)/(3-eta)


# Root existence is proved in the manuscript for all even paths.
check('root_bracket',eta>0 and eta<ball(F(1,64)))
check('root_map_invariant', eta < ball(F(1,2**99)))
lam=(2-eta)*(3-eta)**64
qlo=F(127,191);rholo=64*qlo
check('rho_lower',rho>ball(F(85,2)))
check('rho_upper',rho<43)
Z=1+3*lam+lam**2
mu0=(3*lam+2*lam**2)/Z
mu1=1+2*lam/(1+2*lam)
D0=mu1-mu0
theta=1/(1+rho);a0=D0-theta
check('initial_mean_gap',D0>0 and D0<arb(2)**-99)
check('initial_scale_lower',-a0>arb(2)**-6)
check('initial_scale_upper',-a0<arb(2)**-5)
check('initial_theta_ratio',theta/(-a0)<2)
V0=(3*lam+4)/Z-((3*lam+2)/Z)**2
V1=2*lam/(1+2*lam)**2
check('initial_normalized_variance0',V0/a0**2<arb(2)**-42)
check('initial_normalized_variance1',V1/a0**2<arb(2)**-42)
check('seed_adjacent_mass0',(lam**2/Z)*(3*lam/Z)>arb(2)**-108)
check('seed_adjacent_mass1',2*lam/(1+2*lam)**2>arb(2)**-108)
check('variance_proxy', F(25,384)/(4*(1-F(25,384)))<F(1,50))
check('initial_w2',F(1,7)+two(-21)<F(1,6))
check('w2_series',F(1,6)+F(8,7)<2)
check('w2_contraction',F(8,31)<F(1,3))
check('first_absolute_moment0',F(5,256)<F(1,49))
check('first_absolute_moment_mixture',F(5,256)+F(1,4)<F(9,25))

def convolution(a, b, n):
    c = [arb(0) for _ in range(n+1)]
    for i in range(min(len(a), n+1)):
        for j in range(min(len(b), n+1-i)):
            c[i+j] += a[i]*b[j]
    return c


def power(a, exponent, n):
    result = [arb(1)]+[arb(0)]*n
    while exponent:
        if exponent & 1:
            result = convolution(result, a, n)
        exponent //= 2
        if exponent:
            a = convolution(a, a, n)
    return result


# Exponential-moment coefficients E[(Y^s)^k]/k!, k=0,...,31.
# Coefficients k=1 vanish by centering. Each subsequent pair is obtained
# by solving the exact triangular fixed-point moment equations.
A, C = [arb(1), arb(0)], [arb(1), arb(0)]
for k in range(2, ORDER):
    A.append(arb(0))
    C.append(arb(0))
    e0, e1 = [arb(1)], [arb(1)]
    for j in range(1, k+1):
        e0.append(e0[-1]*(-q)/j)
        e1.append(e1[-1]*(1-q)/j)
    a, c = convolution(A, e0, k), convolution(C, e1, k)
    z = [(1-q)*x+q*y for x,y in zip(a,c)]
    R, S = power(z,64,k)[k], power(A,64,k)[k]
    s = (-1/rho)**k
    w = 64*s
    denominator = 1-w*(1-q)-w*w*q
    check(f"moment_denominator_{k}", denominator > ball(F(9,10)))
    A[k] = (s*R+w*q*s*S)/denominator
    C[k] = w*A[k]+s*S

# sigma^2 <1/50, Taylor order32.
# E|Y|^32/32! <= 6/10^32.
check('scaled_argument', F(524288,42**5)<F(1,200))
epsilon=F(6,2000**32)
check('taylor_error',2*64**5*epsilon<two(-300))
E=two(-300)

def polynomial(coefficients, z):
    value = acb(0)
    for c in reversed(coefficients):
        value = value*z+c
    return value


def conditional_approximants(t):
    """Entire approximants P_0,P_1; error <=2^-300 for real |t|<=524288."""
    u = t/((-rho)**DEPTH)
    a, c = polynomial(A,I*u), polynomial(C,I*u)
    for _ in range(DEPTH):
        next_a = ((1-q)*a*(-I*q*u).exp()+q*c*(I*(1-q)*u).exp())**64
        c, a = a**64, next_a
        u *= -rho
    return a, c


def mixture(t):
    a,c = conditional_approximants(t)
    return (1-q)*a*(-I*q*t).exp()+q*c*(I*(1-q)*t).exp()


# Complete interval covering, with last-layer Lipschitz padding.
max_bound,worst_cell=arb(0),None
for start in range(T,ANNULUS_END,CELL):
 u=-arb(start+CELL//2)/rho
 a,c=conditional_approximants(acb(u))
 z=(1-q)*a*(-I*q*u).exp()+q*c*(I*(1-q)*u).exp()
 b0=(abs(z)+ball(E)+ball(F(3,5)*F(4,42)))**64
 b1=(abs(a)+ball(E)+ball(F(1,7)*F(4,42)))**64
 if not (b0<arb(2)**-240 and b1<arb(2)**-240):
  raise AssertionError(('annulus',start,str(b0),str(b1)))
 upper=max(b0.upper(),b1.upper())
 if upper>max_bound:max_bound,worst_cell=upper,start
checks.append('all_64512_annulus_cells')
print('PASS: 64512 full annulus cells',flush=True)
check('finite_annulus',two(-240)+F(2*ANNULUS_END,3**H0)<two(-238))

x0=F(7,40);integrals=[]
for j in range(3):
 total=acb(0)
 def integrand(t,analytic):return (-I*t)**j*mixture(t)*(-I*ball(x0)*t).exp()
 for start in range(0,T,32):
  value=acb.integral(integrand,start,start+32,abs_tol=arb(2)**-180,rel_tol=arb(2)**-180,eval_limit=100000)
  check(f'integral_{j}_{start}',value.is_finite())
  total+=value
 integrals.append(total.real/arb.pi())
 print(f'PASS: integral {j}: {integrals[-1]}',flush=True)

U=two(-238)
tails=[two(19*(j+1)+1-238) for j in range(4)]
for j in range(4):
 check(f'annular_ratio_{j}',64**(j+1)*U**63<F(1,2))
 check(f'global_derivative_{j}',F(T**(j+1),3*(j+1))+tails[j]<2**(13*(j+1)))
check('high_frequency_tail',2**(6*H-2390)>24*H+508)
check('high_frequency_monotonicity',63*2**(6*H-2390)>24)
check('physical_threshold',T<2*two(-6)*42**H0)

density=[enclose(integrals[j],E*T**(j+1)+tails[j]) for j in range(3)]
targets=[(F(24,10**19),F(26,10**19)),(F(83,10**17),F(85,10**17)),(F(50,10**14),F(52,10**14))]
for j,(lo,hi) in enumerate(targets):
 check(f'density_{j}',density[j]>ball(lo) and density[j]<ball(hi))
R=[two(-216),two(-197),two(-178)]
for j in range(3):
 error=F(3,3**H)*T**(j+2)+2*tails[j]+two(-500)
 check(f'C2_error_{j}',error<R[j])
radius=two(-200)
flo,fhi=targets[0];fphi=targets[1][1];fpphi=targets[2][1]
check('point_W',flo*targets[2][0]-fphi**2>two(-101))
check('interval_W',two(-101)-two(66)*radius>two(-102))
check('interval_f_lower',flo-two(26)*radius>two(-59))
check('interval_f_upper',fhi+two(26)*radius<two(-58))
check('interval_fp',fphi+two(39)*radius<two(-50))
check('interval_fpp',fpphi+two(52)*radius<two(-40))
check('finite_f_lower',two(-59)-R[0]>two(-60))
check('finite_f_upper',two(-58)+R[0]<two(-57))
check('finite_fpp',two(-40)+R[2]<two(-39))
check('fp_sum',2*two(-50)+R[1]<two(-48))
Werr=R[0]*two(-39)+two(-58)*R[2]+R[1]*two(-48)
check('finite_W',two(-102)-Werr>two(-103))
check('curvature',two(-103)/two(-57)**2>=2048)
check('lattice_count',two(-206)*42**H>=4)
check('interval_location',-1<x0-radius<x0+radius<1)
A2=2+F(64,4095)
check('bulk_upper',2+F(2,315)+2*F(2,3)**H<F(997,1000)*(A2-F(1,64**H)))
check('bulk_lower',mu0>1)
check('exponent',(F(85,2))**10>64**9)
check('order_factor',4+F(1,63)<5<8)
report={
 'status':'PASS','scope':'P4 seed; branching 64; every integer height h>=512',
 'arithmetic':'Arb/Acb validated ball arithmetic and exact rational checks',
 'python_flint_version':flint.__version__,'precision_bits':ctx.prec,
 'H':H,'annulus_start_height':H0,'maximum_degree':65,
 'q':str(q),'rho':str(rho),'initial_scale':str(a0),
 'x0':str(x0),'radius':'2^-200','annulus':[T,ANNULUS_END],
 'annulus_cells':(ANNULUS_END-T)//CELL,
 'annulus_limit_bound':'2^-240','annulus_finite_bound':'2^-238',
 'annulus_largest_upper':str(max_bound),'annulus_worst_left':worst_cell,
 'CF_approximation_error':'2^-300',
 'density_derivatives':[str(v) for v in density],
 'density_rational_enclosures':[[str(a),str(b)] for a,b in targets],
 'C2_errors':['2^-216','2^-197','2^-178'],
 'curvature_lower':2048,
 'run_bound':'|I_h| >= 2^-206 rho^h >= 2^-209 N_h^(9/10)',
 'bulk_location':'0 < k < (997/1000) alpha_h',
 'checks_passed':len(checks),'checks':checks,
 'proof_dependency':'fixed_degree_nearlinear.tex, especially the explicit P4 certificate section',
 'scope_limit':'The general even-path theorem has an analytic proof; this numerical certificate covers s=2 only. Not a formal proof-assistant verification.',
 'verifier_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
}
out=Path(__file__).with_name('fixed_degree_certificate.json')
out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(f'PASS: {len(checks)} checks; h>=512; curvature>=2048; exponent 9/10')
