# Moment thresholds for exact causal randomness

Research manuscript, 26 September 2026.

The PDF is the primary reading copy. `moment_thresholds.tex` is the complete
LaTeX source; its sole external typesetting dependency in this package is
`coefficient_evidence.pdf`. No BibTeX pass is needed.

## Mathematical status

The manuscript supplies proofs of the moment classification of finite
centered adaptive envelopes and its exact realization for pure dyadic
causal simulation. These are manuscript proofs, not independently refereed
results. The sharp logarithmic coefficient is explicitly a conjecture.
The sufficient remainder criterion is a conditional proposition. Numerical
agreement is evidence about the conjecture, not a proof of it. Literature
priority is not asserted.

A pure dyadic law means that every positive atom is exactly a power of two.
The causal construction uses one initial seed for a fixed horizon, with
history-dependent deterministic decoders and no later randomness. It does
not construct one consistent infinite source.

## Reproduce the supplied experiments

Requires Python 3, NumPy and Matplotlib. Tested versions appear in
`numerical_results.json`; install the versions in `requirements.txt` to
match the numerical environment.

```sh
python3 experiments.py --n 10000 --exact-n 128
python3 logarithmic_seed.py --exact-n 128 --float-n 0
pdflatex -interaction=nonstopmode -halt-on-error moment_thresholds.tex
pdflatex -interaction=nonstopmode -halt-on-error moment_thresholds.tex
```

The first command regenerates numerical JSON/CSV, the table fragment, and
PDF/PNG figures. The manuscript embeds the checked default table directly;
if changing the numerical horizon, also update its table, caption, and
reported horizon. The exact computation checks rational profiles, moments,
normalization, integer seed multiplicities and entropy increments through
128 rounds for all seven families. The floating-point recursion uses the
complete grid and does not truncate tails. There is no Monte Carlo sampling
or fitted coefficient.

The second command regenerates the explicit cubic pair's exact verification
and full decoder certificates through horizon two. These checks use only
standard-library integer and rational arithmetic. The expanded seed sizes
are 84 and 6,984; long-horizon checks store multiplicities instead of
expanding every atom.

`longdouble` precision is platform-dependent. Its mantissa length and its
comparison with float64 are recorded in the JSON report.

## Files

- `moment_thresholds.pdf`, `moment_thresholds.tex`: manuscript.
- `experiments.py`: seven-family exact and floating-point study.
- `numerical_results.json`, `.csv`: parameters, exact certificates, versions,
  checkpoints, predicted coefficients, and precision check.
- `numerical_table.tex`: regenerated table rows.
- `coefficient_evidence.pdf`, `.png`: vector and raster figures.
- `logarithmic_seed.py`: explicit action laws and exact finite decoder checks.
- `logarithmic_verification.json`: exact rational excesses and increments.
- `logarithmic_decoder_n2.json`: complete finite decoder maps.
- `requirements.txt`: numerical environment.
- `SHA256SUMS`: checksums of package files, excluding this checksum file itself.
