#!/usr/bin/env python3
"""Deterministic profile experiments for Moment thresholds for exact causal randomness.
No simulation, fitted coefficient, or tail truncation. Run: python experiments.py
"""
from fractions import Fraction as F
from pathlib import Path
import argparse, csv, json, math, platform
import numpy as np

A = {-2:F(1,16), -1:F(5,16), 0:F(3,16), 1:F(7,16)}
B = {-1:F(1,2), 1:F(1,2)}
J = {-2:F(1,8), 0:F(3,4), 2:F(1,8)}
def mix(p,q,t): return {k:t*p.get(k,0)+(1-t)*q.get(k,0) for k in p.keys()|q.keys()}
def conv(p,q):
    out={}
    for x,a in p.items():
        for y,b in q.items(): out[x+y]=out.get(x+y,F(0))+a*b
    return out
CASES = [('cubic', A,B), ('half',mix(A,B,F(1,2)),B), ('quartic',A,J),
         ('reflection',A,{-k:p for k,p in A.items()}), ('noise',conv(A,B),conv(B,B)),
         ('skew',mix(A,B,F(1,4)),mix(A,B,F(3,4))),
         ('dilation',{2*k:p for k,p in A.items()},{2*k:p for k,p in B.items()})]
LABELS = {'cubic':r'$\alpha,\beta$', 'half':r'$(\alpha+\beta)/2,\beta$',
          'quartic':r'$\alpha,\gamma$', 'reflection':r'$\alpha,\check\alpha$',
          'noise':r'$\alpha*\beta,\beta*\beta$',
          'skew':r'$(\alpha+3\beta)/4,(3\alpha+\beta)/4$',
          'dilation':r'$2\alpha,2\beta$'}
def parameters(p,q):
    K=max(abs(k) for k in p.keys()|q.keys())
    d=math.lcm(*(w.denominator for w in list(p.values())+list(q.values())))
    assert d&(d-1)==0
    s=d.bit_length()-1
    moments=[[sum(w*k**r for k,w in law.items()) for r in range(5)] for law in (p,q)]
    assert moments[0][:3]==moments[1][:3] and moments[0][:2]==[1,0]
    v=moments[0][2]; delta=moments[0][3]-moments[1][3]
    assert v>0 and delta!=0
    c=float(abs(delta)/v)/(3*math.sqrt(2*math.pi*math.e))
    h=s+K
    # Realize each information mass w at length h+k by w*2^(h+k) atoms.
    for law in (p,q):
        counts={h+k:w*2**(h+k) for k,w in law.items()}
        assert all(w.denominator==1 for w in counts.values())
        assert sum(F(w,2**length) for length,w in counts.items())==1
    return K,d,h,moments,c

def exact(p,q,N):
    K,d,h,_,_=parameters(p,q)
    weights=[[int(law.get(k,0)*d) for k in range(-K,K+1)] for law in (p,q)]
    cdf=[1]; denominator=1; total=F(0)
    for n in range(1,N+1):
        pad=[0]*(2*K)+cdf+[denominator]*(2*K)
        cs=[[sum(w*pad[i+2*K-j] for j,w in enumerate(ws))
             for i in range(len(cdf)+2*K)] for ws in weights]
        denominator*=d
        cdf=[min(x,y) for x,y in zip(*cs)]
        inc=F(sum(abs(x-y) for x,y in zip(*cs)),2*denominator)
        total+=inc
        mass=[cdf[0]]+[b-a for a,b in zip(cdf,cdf[1:])]
        assert all(x>=0 for x in mass) and sum(mass)==denominator
        mean=F(sum((i-K*n)*w for i,w in enumerate(mass)),denominator)
        assert total==mean
        # Integer multiplicities of an actual dyadic seed, without expansion.
        s=d.bit_length()-1
        counts=[w << (n*h+i-K*n-n*s) for i,w in enumerate(mass)]
        assert sum(F(w,2**(n*h+i-K*n)) for i,w in enumerate(counts))==1
    return {'n':N,'excess':str(total),'increment':str(inc)}

def floating(p,q,N,dtype=np.float64):
    K,d,h,moments,c=parameters(p,q)
    ws=[np.array([float(law.get(k,0)) for k in range(-K,K+1)],dtype=dtype) for law in (p,q)]
    cdf=np.ones(1,dtype=dtype); excess=dtype(0); rows=[]
    keep={1,2,10,100,128,1000,5000,N}|set(np.unique(np.geomspace(20,N,180).astype(int)))
    for n in range(1,N+1):
        pad=np.concatenate((np.zeros(2*K,dtype=dtype),cdf,np.ones(2*K,dtype=dtype)))
        a,b=(np.convolve(pad,w,'valid') for w in ws)
        inc=np.abs(a-b).sum(dtype=dtype)/2
        excess+=inc
        cdf=np.minimum(a,b)
        if n in keep:
            rows.append({'n':n,'excess':float(excess),'increment':float(inc),
                         'n_increment':float(n*inc),'ratio':float(n*inc)/c,
                         'remainder':float(excess)-c*math.log(n)})
    assert abs(float(cdf[-1])-1)<1e-10 and float(np.min(np.diff(cdf)))>-1e-12
    return rows

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--n',type=int,default=10000)
    parser.add_argument('--exact-n',type=int,default=128)
    args=parser.parse_args()
    if args.n<128: parser.error('--n must be at least 128')
    out=Path(__file__).resolve().parent
    results={'environment':{'python':platform.python_version(),'numpy':np.__version__,
                            'longdouble_mantissa':int(np.finfo(np.longdouble).nmant)},
             'horizon':args.n,'exact_horizon':args.exact_n,'cases':{}}
    table=[]; flat=[]
    for name,p,q in CASES:
        K,d,h,moments,c=parameters(p,q)
        cert=exact(p,q,args.exact_n)
        rows=floating(p,q,args.n)
        # Independent exact reference at the same finite horizon.
        ref=floating(p,q,args.exact_n)[-1]
        error=abs(ref['excess']-float(F(cert['excess'])))
        assert error<1e-10
        results['cases'][name]={'p':{str(k):str(v) for k,v in p.items()},
            'q':{str(k):str(v) for k,v in q.items()},'realization_entropy':h,
            'moments':[[str(x) for x in row] for row in moments],
            'predicted_coefficient':c,'exact_certificate':cert,
            'exact_float_error':error,'rows':rows}
        flat.extend(dict(case=name,**r) for r in rows)
        last=rows[-1]
        table.append(f"{LABELS[name]} & {float(moments[0][2]):g} & {float(abs(moments[0][3]-moments[1][3])):g} & {c:.8f} & {last['n_increment']:.8f} & {1e4*(last['ratio']-1):.3f} \\\\")
        print(name, 'c=',c,'n inc=',last['n_increment'],'ratio=',last['ratio'],flush=True)
    long=floating(A,B,args.n,np.longdouble)[-1]
    base=results['cases']['cubic']['rows'][-1]
    results['precision_check']={'float64':base,'longdouble':long,
        'excess_difference':abs(base['excess']-long['excess']),
        'n_increment_difference':abs(base['n_increment']-long['n_increment'])}
    assert results['precision_check']['n_increment_difference']<1e-6
    (out/'numerical_results.json').write_text(json.dumps(results,indent=2)+'\n')
    (out/'numerical_table.tex').write_text('\n'.join(table)+'\n')
    with (out/'numerical_results.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(flat[0]));writer.writeheader();writer.writerows(flat)
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.family':'serif','font.size':9,'axes.spines.top':False,
                         'axes.spines.right':False,'pdf.fonttype':42})
    fig,axs=plt.subplots(1,2,figsize=(6.6,2.65),layout='constrained')
    colors=['#143e59','#aa5a26','#427d72','#754f85','#6b7b29','#ba4555','#68737d']
    styles=['-','--','-.',':','-','--',':']
    for (name,_,_),col,style in zip(CASES,colors,styles):
        rows=[r for r in results['cases'][name]['rows'] if r['n']>=100]
        x=[r['n'] for r in rows]
        axs[0].plot(x,[r['ratio'] for r in rows],color=col,ls=style,lw=1.1,label=name)
        if name in ('cubic','half','noise'):
            axs[1].plot(x,[r['remainder'] for r in rows],color=col,lw=1.2,label=name)
    axs[0].axhline(1,color='black',ls=':',lw=.8)
    axs[0].set_ylabel(r'$n(e_n-e_{n-1})/c$');axs[0].set_ylim(.998,1.037)
    axs[1].set_ylabel(r'$e_n-c\ln n$ (bits)')
    for ax in axs:
        ax.set_xscale('log');ax.set_xlabel('Horizon $n$');ax.grid(alpha=.15)
    axs[0].legend(fontsize=6.8,ncol=2,frameon=False,loc='upper right')
    axs[1].legend(fontsize=7,frameon=False)
    fig.savefig(out/'coefficient_evidence.pdf')
    fig.savefig(out/'coefficient_evidence.png',dpi=180)
    print('Precision check:',results['precision_check'],flush=True)
if __name__=='__main__': main()
