#!/usr/bin/env python3
"""Supplementary exact finite audit; not a proof-assistant certificate.
Run: python3 verify_peak_transfer.py > peak_transfer_audit.json
Uses only the Python standard library.
"""
from fractions import Fraction as Q
from itertools import product
import json

def add(a,b):
    c=[0]*max(len(a),len(b))
    for i,x in enumerate(a): c[i]+=x
    for i,x in enumerate(b): c[i]+=x
    while len(c)>1 and not c[-1]: c.pop()
    return c

def mul(a,b):
    c=[0]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b): c[i+j]+=x*y
    return c

def power(a,r):
    out=[1]
    for _ in range(r): out=mul(out,a)
    return out

def brute(n,edges):
    out=[0]*(n+1)
    for mask in range(1<<n):
        if all(not ((mask>>u)&1 and (mask>>v)&1) for u,v in edges):
            out[mask.bit_count()]+=1
    while len(out)>1 and not out[-1]: out.pop()
    return out

def forest_dp(n,edges):
    adj=[[] for _ in range(n)]
    for u,v in edges: adj[u].append(v); adj[v].append(u)
    seen=set()
    def visit(v,parent):
        seen.add(v); absent=[1]; present=[0,1]
        for w in adj[v]:
            if w==parent: continue
            assert w not in seen, 'input is not a forest'
            a,b=visit(w,v)
            absent=mul(absent,add(a,b)); present=mul(present,a)
        return absent,present
    out=[1]
    for v in range(n):
        if v not in seen:
            a,b=visit(v,-1); out=mul(out,add(a,b))
    return out

def stats(poly,n):
    z=sum(poly); mu=Q(sum(k*x for k,x in enumerate(poly)),z)
    var=Q(sum(k*k*x for k,x in enumerate(poly)),z)-mu*mu
    assert var<3*n
    modes=[k for k,x in enumerate(poly) if x==max(poly)]
    for m in modes:
        # |m-mu| < 6*n^(3/4), checked with rational fourth powers.
        assert (m-mu)**4 < 6**4*n**3
    return mu,var,modes

def hub(h,edges,v,r,s):
    out=[(u+j*h,w+j*h) for j in range(r) for u,w in edges]
    c=r*h
    out += [(c,j*h+v) for j in range(r)]
    out += [(c,c+1+j) for j in range(s)]
    return c+1+s,out

def remove_vertex(n,edges,v):
    verts=[u for u in range(n) if u!=v]; idx={u:i for i,u in enumerate(verts)}
    return n-1,[(idx[u],idx[w]) for u,w in edges if v not in (u,w)]

def decorated(t):
    return 3*t,[(i,i+1) for i in range(2*t-1)]+[(2*i,2*t+i) for i in range(t)]

def transfer_full(t):
    a,b=[1],[0]
    for _ in range(t):
        for leaves in (1,0):
            a,b=mul(add(a,b),[1,1] if leaves else [1]),mul(a,[0,1])
    return add(a,b)

small=0
# All increasing-parent rooted trees through order 7, with exact enumeration.
for n in range(1,8):
    for parents in product(*(range(v) for v in range(1,n))):
        edges=[(v,parents[v-1]) for v in range(1,n)]
        p=brute(n,edges); assert p==forest_dp(n,edges)
        stats(p,n); small+=1
hub_cases=0
for h,edges in [(1,[]),(2,[(0,1)]),(3,[(0,1),(1,2)]),(4,[(0,1),(0,2),(0,3)])]:
    z=brute(h,edges)
    for v in range(h):
        nv,ev=remove_vertex(h,edges,v); w=brute(nv,ev)
        for r in range(1,4):
            for s in range(h):
                n,ee=hub(h,edges,v,r,s)
                rhs=add(mul(power([1,1],s),power(z,r)),[0]+power(w,r))
                assert rhs==brute(n,ee)==forest_dp(n,ee)
                assert len(rhs)-1==max(r*(len(z)-1)+s,1+r*(len(w)-1))
                mu,_,_=stats(rhs,n)
                base=r*stats(z,h)[0]+Q(s,2)
                theta=Q(sum(w),sum(z))
                assert abs(mu-base)<=n*theta**r
                hub_cases+=1
rows=[]
for t in (1,2,3,5,10,20,50,100):
    n,edges=decorated(t); p=forest_dp(n,edges)
    assert p==transfer_full(t) and len(p)-1==2*t
    mu,var,modes=stats(p,n)
    rows.append({'t':t,'n':n,'alpha':2*t,'mean_over_alpha':str(mu/(2*t)),
                 'decimal_mean_over_alpha':float(mu/(2*t)), 'modes':modes})
print(json.dumps({'status':'PASS_EXACT','proof_assistant_certificate':False,
  'small_tree_instances':small,'hub_instances':hub_cases,
  'decorated_path_instances':rows,
  'scope':'Finite exact audits supplement the general written proof; novelty and optimality are not certified.'},indent=2))
