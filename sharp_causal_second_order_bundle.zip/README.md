# Sharp second-order causal entropy

The standalone proof establishes, for finite equal-entropy laws P and Q,

    C_n^causal = n h + sqrt(2/pi) |sigma_P-sigma_Q| sqrt(n) + o(sqrt(n)).

It includes zero varentropy. For equal positive varentropies it also
proves C_n^causal - n h = O(log(n+1)). If both varentropies are zero,
C_n^causal = n h exactly.

The square-root proof is self-contained: finite greedy causal
realization within log_2(e) bits of the Bellman profile, explicit
finite-horizon Taylor barriers, and uniformly integrable tails.
The equal-variance logarithmic refinement uses Fan--Grama--Liu,
Theorem 2.1, arXiv:1608.05217. All its hypotheses are verified in the note.

## Files

- `sharp_causal_second_order_proved.tex`: standalone LaTeX source.
- `output/pdf/sharp_causal_second_order_proved.pdf`: complete proof.
- `verify_causal_greedy.py`: standard-library exact arithmetic audits of
  the finite causal construction, its tail inequalities and a rational
  bracket for the irrational crash-test parameter.
- `verification_results.json`: results for eighteen finite instances.
- `decoder_certificate_n3.json`: explicit rational depth-three decoder.
- `check_bellman_limit.py`: NumPy float diagnostics of the limiting
  coefficient for positive and zero lower variance.
- `bellman_limit_diagnostics.json`: diagnostics through n=8000.

Run:

    python verify_causal_greedy.py
    python check_bellman_limit.py

The second script needs NumPy; the first needs only Python's standard
library. The finite checks are not a proof-assistant verification of the
universal theorem. All numerical entropy and limit tables are labeled as
floating-point illustrations. The proof does not extrapolate from them.

The seed construction may have exponentially many histories. No efficient
implementation, single infinite-horizon seed, sharp logarithmic coefficient,
independent peer review, or literature priority is claimed.

This is a replacement proof of the supplied theorem, not a validation of
the supplied fiber-recycling argument. The original attachment is unchanged.
