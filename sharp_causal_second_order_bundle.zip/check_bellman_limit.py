#!/usr/bin/env python3
"""Float diagnostics of the proved Bellman limit, not a proof certificate.

The two increment pairs can be realized as centered surprisal laws of
finite pure-dyadic distributions (the proof itself does not need dyadicity).
Requires NumPy. See the accompanying PDF for the universal proof.
"""
import json
from pathlib import Path
import numpy as np

def run(name, p, q, a, b, limit_n=8000):
    p,q=np.asarray(p,dtype=float),np.asarray(q,dtype=float)
    radius=(len(p)-1)//2
    values=np.arange(-radius,radius+1)
    assert p.sum()==q.sum()==1
    assert abs(p@values)<1e-15 and abs(q@values)<1e-15
    assert abs(p@(values**2)-a*a)<1e-15
    assert abs(q@(values**2)-b*b)<1e-15
    cdf=np.ones(1)
    mean=0.
    rows=[]
    for n in range(1,limit_n+1):
        padded=np.pad(cdf,(2*radius,2*radius),constant_values=(0,1))
        pa=np.convolve(padded,p,'valid')
        qa=np.convolve(padded,q,'valid')
        mean+=.5*np.abs(pa-qa).sum()
        cdf=np.minimum(pa,qa)
        if n in {10,100,1000,4000,limit_n}:
            row=dict(case=name,n=n,excess=float(mean),
                     scaled_excess=float(mean/np.sqrt(n)),
                     proved_limit=float(np.sqrt(2/np.pi)*(a-b)))
            rows.append(row)
            print(json.dumps(row),flush=True)
    return rows

if __name__=='__main__':
    results=run('positive_variances',[.5,0,0,0,.5],[0,.5,0,.5,0],2,1)
    results+=run('zero_lower_variance',[.5,0,.5],[0,1,0],1,0)
    Path(__file__).with_name('bellman_limit_diagnostics.json').write_text(
        json.dumps({'arithmetic':'float64; numerical illustration only','results':results},indent=2)+'\n')
