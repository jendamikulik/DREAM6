#!/usr/bin/env python3
"""Exact finite audits of the causal greedy realization theorem.

Only the standard library is required. Flow, decoder, bottleneck and profile
checks use integers/Fraction; logarithms are used ONLY for reported entropies.
This program is not a proof-assistant certificate of the universal theorem.
"""
from fractions import Fraction as F
from collections import Counter
from pathlib import Path
import json
import math


def log2_interval(x, terms=8):
    """Rational bounds, using ln x = 2 atanh((x-1)/(x+1))."""
    def ln_unit(v):
        z=(v-1)/(v+1)
        s=sum((2*z**(2*j+1)/F(2*j+1) for j in range(terms)),F(0))
        tail=2*z**(2*terms+1)/(F(2*terms+1)*(1-z*z))
        return s,s+tail
    k=0
    while x < 1:
        x*=2; k-=1
    while x >= 2:
        x/=2; k+=1
    lo,hi=ln_unit(x)
    l2,u2=ln_unit(F(2))
    return F(k)+lo/u2,F(k)+hi/l2


def crash_bracket():
    def entropy_interval(q):
        lo=hi=F(0)
        for p in (q,q,1-2*q):
            a,b=log2_interval(p)
            lo-=p*b; hi-=p*a
        return lo,hi
    lo,hi=F(410,1000),F(411,1000)
    at_lo,at_hi=entropy_interval(lo),entropy_interval(hi)
    assert at_lo[0] > F(3,2) > at_hi[1]
    assert F(1500077,10**6) < at_lo[0] <= at_lo[1] < F(1500078,10**6)
    assert F(1497682,10**6) < at_hi[0] <= at_hi[1] < F(1497683,10**6)
    # H(q,q,1-2q) is strictly decreasing for q > 1/3.
    ratio=hi/(1-2*hi)
    assert ratio**4 < 32             # log2(ratio) < 5/4, exactly.
    variance_upper=(2*hi)*(1-2*lo)*F(25,16)
    assert variance_upper < F(1,4)
    return {'q_interval':[str(lo),str(hi)],
            'entropy_at_lower_minus_3_over_2_lower':str(at_lo[0]-F(3,2)),
            '3_over_2_minus_entropy_at_upper_lower':str(F(3,2)-at_hi[1]),
            'varentropy_upper':str(variance_upper),'status':'PASS_EXACT'}


def build(depth, laws, denominator, varying=False):
    nodes = []
    def add(h, numerator, history):
        i = len(nodes)
        nodes.append({'p': numerator, 'edges': [], 'history': history})
        if h:
            local = laws
            if varying:
                # Truly history-dependent stochastic kernels, all positive.
                shift = sum((a+1)*(y+2) for a, y in history)
                local = [(1+shift % 5, denominator-1-shift % 5),
                         (2+shift % 3, 1, denominator-3-shift % 3)]
            assert all(sum(row) == denominator for row in local)
            for a, row in enumerate(local):
                nodes[i]['edges'].append([
                    add(h-1, numerator*w//denominator, history+[(a,y)])
                    for y,w in enumerate(row)])
        return i
    total = denominator**depth
    add(depth, total, [])
    return nodes, total


def evaluate(nodes, leaf_values, output_op, action_op):
    scores = [0]*len(nodes)
    for i in range(len(nodes)-1, -1, -1):
        edges = nodes[i]['edges']
        scores[i] = action_op(output_op(scores[j] for j in row)
                              for row in edges) if edges else leaf_values[i]
    return scores


def greedy(nodes, total, audit_each=True):
    residual = [x['p'] for x in nodes]
    atoms = []
    previous = total
    while residual[0]:
        b = evaluate(nodes, residual, max, min)
        weight = b[0]
        assert 0 < weight <= previous
        previous = weight
        chosen, visited = {}, []
        def select(i):
            visited.append(i)
            if nodes[i]['edges']:
                choices = []
                for row in nodes[i]['edges']:
                    y = max(range(len(row)), key=lambda y: b[row[y]])
                    choices.append(y)
                    select(row[y])
                chosen[i] = choices
        select(0)
        assert all(residual[i] >= weight for i in visited)
        assert any(not nodes[i]['edges'] and residual[i] == weight
                   for i in visited)
        for i in visited:
            residual[i] -= weight
        if audit_each:
            assert all(v >= 0 for v in residual)
            for i,node in enumerate(nodes):
                assert all(sum(residual[j] for j in row) == residual[i]
                           for row in node['edges'])
        atoms.append((weight, chosen))
    assert not any(residual)
    assert sum(w for w,_ in atoms) == total
    assert len(atoms) <= sum(not node['edges'] for node in nodes)
    return atoms


def audit_decoder(nodes, atoms, total):
    # Each compatible history is checked, including all counterfactual actions.
    reconstructed = [0]*len(nodes)
    for weight, decoder in atoms:
        def visit(i):
            reconstructed[i] += weight
            for a,row in enumerate(nodes[i]['edges']):
                y = decoder[i][a]
                assert 0 <= y < len(row)
                visit(row[y])
        visit(0)
    assert reconstructed == [node['p'] for node in nodes]


def profile_and_tail_audit(nodes, atoms, total):
    leaf_p = {x['p'] for x in nodes if not x['edges']}
    # Information levels are ordered by decreasing path probability.
    envelope, last = [], 0
    for threshold in sorted(leaf_p, reverse=True):
        terminal = [x['p'] if x['p'] >= threshold else 0 for x in nodes]
        cdf = evaluate(nodes, terminal, sum, min)[0]
        assert cdf >= last
        if cdf > last:
            envelope.append((threshold, cdf-last))
        last = cdf
    assert last == total
    weights = Counter(w for w,_ in atoms)
    for delta in sorted(weights):
        tail = sum(w*k for w,k in weights.items() if w <= delta)
        # The policy-cut bound and exponential smoothing are exact rationals.
        clipped = evaluate(nodes, [min(x['p'], delta) for x in nodes], sum, max)[0]
        smooth = sum((F(m)*min(F(1), F(delta,p)) for p,m in envelope), F(0))
        assert tail <= clipped <= smooth
    for threshold in sorted(leaf_p | set(weights)):
        source_cdf = sum(w*k for w,k in weights.items() if w >= threshold)
        target_cdf = evaluate(nodes, [x['p'] if x['p'] >= threshold else 0
                                      for x in nodes], sum, min)[0]
        assert source_cdf <= target_cdf
    mean = sum(float(F(m,total))*math.log2(total/p) for p,m in envelope)
    entropy = sum(float(F(w*k,total))*math.log2(total/w) for w,k in weights.items())
    assert -1e-10 <= entropy-mean <= math.log2(math.e)+1e-10
    return mean, entropy, envelope


def bottleneck_by_policies(nodes, residual, i=0):
    """Brute force all realized policies, only used at depth <= 2."""
    from itertools import product
    if not nodes[i]['edges']:
        return [(residual[i],)]
    out=[]
    for row in nodes[i]['edges']:
        for child_lists in product(*(bottleneck_by_policies(nodes,residual,j) for j in row)):
            out.append(tuple(x for block in child_lists for x in block))
    return out


def run():
    cases = [
        ('rational_three_symbol', [(50,25,25),(41,41,18)],100,False,4),
        ('dyadic_two_actions', [(2,1,1),(1,1,1,1)],4,False,3),
        ('three_actions', [(3,3),(2,2,2),(1,5)],6,False,3),
        ('history_dependent', [(5,7),(3,1,8)],12,True,4),
        ('deterministic_and_random', [(4,),(1,3)],4,False,4),
    ]
    rows=[]
    certificate=None
    for name,laws,D,varying,max_depth in cases:
        for n in range(1,max_depth+1):
            nodes,total=build(n,laws,D,varying)
            atoms=greedy(nodes,total)
            audit_decoder(nodes,atoms,total)
            mean,entropy,env=profile_and_tail_audit(nodes,atoms,total)
            if n <= 2:
                remaining=[x['p'] for x in nodes]
                for weight,decoder in atoms:
                    brute=min(max(v) for v in bottleneck_by_policies(nodes,remaining))
                    assert brute == evaluate(nodes,remaining,max,min)[0] == weight
                    def subtract(i):
                        remaining[i]-=weight
                        for a,row in enumerate(nodes[i]['edges']):
                            subtract(row[decoder[i][a]])
                    subtract(0)
            row={'case':name,'n':n,'nodes':len(nodes),'seed_atoms':len(atoms),
                 'envelope_mean_float':mean,'seed_entropy_float':entropy,
                 'gap_float':entropy-mean,'exact_flow_decoder_tail_checks':'PASS'}
            rows.append(row)
            print(json.dumps(row),flush=True)
            if name=='rational_three_symbol' and n==3:
                certificate={'denominator':total,'nodes':nodes,
                             'atoms':[{'numerator':w,'decoder':d} for w,d in atoms],
                             'note':'Rational Q=(41,41,18)/100, NOT the irrational equal-entropy Q.'}
    target=Path(__file__).resolve().parent
    bracket=crash_bracket()
    print('Irrational crash-test bracket and variance separation: PASS_EXACT')
    (target/'verification_results.json').write_text(json.dumps({'cases':rows,
        'irrational_crash_test_bracket':bracket,
        'arithmetic':'All structural checks exact; reported entropies use float64.',
        'universal_proof':'See causal_global_realization.pdf, not proved by finite tests.'},indent=2)+'\n')
    (target/'decoder_certificate_n3.json').write_text(json.dumps(certificate,separators=(',',':'))+'\n')


if __name__=='__main__':
    run()
