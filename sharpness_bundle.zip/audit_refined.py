#!/usr/bin/env python3
"""Independent finite audit using enumerated leaf-incidence sets.
No bottom-up bottleneck implementation; no floating point arithmetic.
Finite tests supplement, not replace, the universal proof in the audit note.
"""
from fractions import Fraction as F
from itertools import product
from random import Random
from pathlib import Path
import json

def need(p,message):
    if not p:raise ArithmeticError(message)

def build(depth,rng,fixed=None):
    leaves=[]
    def rec(d,p):
        if d==0:
            i=len(leaves);leaves.append(p)
            return [frozenset([i])],[frozenset([i])]
        branches=[]
        for a in range(2):
            weights=fixed if fixed is not None else (rng.randrange(4),rng.randrange(4))
            if sum(weights)==0:weights=(0,1)
            branches.append([rec(d-1,p*F(w,sum(weights))) for w in weights])
        # Strategy chooses one output per action and keeps both action branches.
        per_action=[[s for strategies,policies in row for s in strategies] for row in branches]
        strategies=[frozenset().union(*items) for items in product(*per_action)]
        # Policy chooses one action and keeps every output branch of that action.
        policies=[]
        for row in branches:
            policies += [frozenset().union(*items) for items in product(*(pol for st,pol in row))]
        return strategies,policies
    strategies,policies=rec(depth,F(1))
    return leaves,strategies,policies

def audit(p,strategies,policies):
    need(all(len(s&t)==1 for s in strategies for t in policies),'Strategy-policy intersection')
    need(all(sum(p[i] for i in t)==1 for t in policies),'Policy normalization')
    r=list(p);atoms=[];cuts=0
    while sum(r[i] for i in policies[0]):
        bottlenecks=[min(r[i] for i in s) for s in strategies]
        k=max(range(len(strategies)),key=lambda k:bottlenecks[k]);w=bottlenecks[k]
        cut=min(max(r[i] for i in t) for t in policies)
        need(w==cut and w>0,'Enumerated max-min / min-max identity');cuts+=1
        if atoms:need(w<=atoms[-1][0],'Nonincreasing weights')
        zeros=sum(x==0 for x in r)
        for i in strategies[k]:r[i]-=w
        need(min(r)>=0 and sum(x==0 for x in r)>zeros,'Extraction / termination')
        atoms.append((w,strategies[k]))
        need(len({sum(r[i] for i in t) for t in policies})==1,'Residual policy mass')
    need(not any(r),'Zero root with nonzero leaves')
    need(len(atoms)<=len(p),'Support bound')
    need(sum(w for w,s in atoms)==1,'Seed normalization')
    need(all(sum(w for w,s in atoms if i in s)==p[i] for i in range(len(p))),'Reconstruction')
    # Envelope is computed directly from EVERY enumerated policy.
    prev=F(0);env=[]
    for threshold in sorted(set(p)-{F(0)},reverse=True):
        cdf=min(sum(p[i] for i in t if p[i]>=threshold) for t in policies)
        need(cdf>=prev,'CDF monotonicity')
        if cdf>prev:env.append((threshold,cdf-prev))
        prev=cdf
    need(prev==1,'CDF normalization')
    for alpha in [2,3,4,8]:
        mz=sum(m*prob**(alpha-1) for prob,m in env)
        mj=sum(w**alpha for w,s in atoms)
        factor=F(1,2)+F(1,alpha*2**alpha)
        need(mz*factor<=mj<=mz,'Refined Renyi moment inequality')
    knots={F(0),F(1)}|set(p)|{w for w,s in atoms}
    original=sorted(knots);knots|={(a+b)/2 for a,b in zip(original,original[1:])}
    for delta in sorted(knots):
        tail=sum(w for w,s in atoms if w<=delta)
        clipped=max(sum(min(p[i],delta) for i in t) for t in policies)
        smooth=sum(m*min(F(1),delta/prob) for prob,m in env)
        need(tail<=clipped<=smooth,'Soft tail / jumps')
        def phi(prob):
            return prob if prob<=delta else min(delta,prob-delta)
        def psi(u):
            return F(1) if u>=1 else min(u,F(1,2))
        advanced=max(sum(phi(p[i]) for i in t) for t in policies)
        refined=sum(m*psi(delta/prob) for prob,m in env)
        need(tail<=advanced<=refined<=smooth,'Refined atom-aware tail')
        # strict probability threshold corresponds to a strict information tail.
        source=sum(w for w,s in atoms if w>=delta)
        envelope=min(sum(p[i] for i in t if p[i]>=delta) for t in policies)
        need(source<=envelope,'Universal spectrum converse')
    return dict(leaves=len(p),strategies=len(strategies),policies=len(policies),
                atoms=len(atoms),residual_minimax_checks=cuts,threshold_checks=len(knots))

def main():
    rng=Random(271828);results=[]
    for fixed in [(0,1),(1,0),(1,1),(1,2),(2,1)]:
        for d in [0,1,2]:results.append(audit(*build(d,rng,fixed)))
    for k in range(150):results.append(audit(*build(2,rng)))
    p=[F(1,2),F(1,2),F(1,3),F(1,3),F(1,3)]
    st=[frozenset([i,2+j]) for i in range(2) for j in range(3)]
    pol=[frozenset([0,1]),frozenset([2,3,4])]
    results.append(audit(p,st,pol))
    report=dict(status='PASS_EXACT_REFINED_TAIL_AUDIT',cases=len(results),
                residual_minimax_checks=sum(r['residual_minimax_checks'] for r in results),
                threshold_checks=sum(r['threshold_checks'] for r in results),
                includes_zero_edges=True,includes_depth_zero=True,
                floating_point_used=False,proof_assistant_certificate=False,
                method='Enumerate leaf-incidence sets, not the manuscript bottleneck recursion',
                results=results)
    (Path(__file__).parent/'audit_results.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='results'}))
if __name__=='__main__':main()
