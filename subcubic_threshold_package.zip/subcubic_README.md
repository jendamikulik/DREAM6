# Extremální exponent jedna: důkaz a konečný certifikát

`subcubic_threshold.pdf` je desetistránkový anglický matematický text;
`subcubic_threshold.tex` je jeho úplný zdroj.

Pro M_Δ(N), maximální délku souvislého bloku přísných selhání log-konkavity
v polynomu nezávislosti stromu s nejvýše N vrcholy a maximálním stupněm Δ,
text dokazuje:

- pro každý pevný Δ ≥ 3 platí lim log M_Δ(N) / log N = 1;
- pro Δ ≤ 2 je M_Δ(N) = 0;
- pro každý pevný Δ je M_Δ(N) = o(N).

Konstrukce používá binární větvení a koncové stromy G_t. G_0 je hrana
zakořeněná v koncovém vrcholu. G_(t+1) má nový kořen, jeho jediného syna
a dvě kopie G_t připojené pod tohoto syna. Koncový strom má 2^(t+2)-2
vrcholů a limitní kořenové odds A_0=1, A_(t+1)=(1+A_t)^2.

Pro každý pevný ε > 0 lze tak zvolit semeno velikosti O(log(1/ε)) a získat
Ω_ε(N^(1-ε)) po sobě jdoucích selhání. Konstanty a počáteční výška obecné
rodiny závisejí na ε; dokument netvrdí jejich jednotný numerický certifikát.

## Explicitně certifikovaná instance

Semeno G_2 má 14 vrcholů. Nad ním se opakovaně větví binárně.
Pro KAŽDÉ celé h ≥ 1024 je N_h=15·2^h−1 a konstrukce má souvislý blok I_h:

    |I_h| ≥ 2^(-82) ρ^h ≥ 2^(-86) N_h^(47/50),
    0 < k < 0.99 α_h  pro k v I_h,
    log(i_(k-1) i_(k+1) / i_k^2) ≥ 400 / |a_h|^2 > 0.

Kořenové odds jsou vymezeny přesnou racionální bisekcí; ρ≈1.92293167368.
Interval normované souřadnice má střed −2/5 a poloměr 2^(-80).

## Reprodukce

Vyžaduje Python 3 a Python-FLINT 0.9.0:

    python -m pip install python-flint==0.9.0
    python verify_subcubic.py

Program používá přesná racionální čísla a rigorózní Arb/Acb intervalovou
aritmetiku s přesností 512 bitů. Žádná důkazová nerovnost se nerozhoduje
pomocí běžné binární plovoucí řádové čárky.

Úspěšný běh provede 733 kontrol včetně 256 pokrytých celých intervalů
Fourierova mezikruží a 384 validovaných integračních úseků. Vytvoří
`subcubic_certificate.json` s mezemi, kontrolami a SHA-256 ověřovače.
Certifikát je součástí psaného důkazu; univerzální kvantifikátory přenášejí
analytické odhady v textu. Nejde o formalizaci v důkazovém asistentu ani
o nezávislou recenzi. Stromy astronomické velikosti se neenumerují.

PDF lze znovu vytvořit dvěma běhy:

    pdflatex subcubic_threshold.tex
    pdflatex subcubic_threshold.tex

## Priorita a literatura

Při rešerši byl nalezen preprint Setha Christophera ze 12. září 2026,
„Independent Sets on Trees: Consecutive Log-Concavity Failures and an Exact
Covariance Threshold“, Figshare 33684715. Jeho indexovaný abstrakt už uvádí
téměř lineární bloky ve stromech stupně nejvýše 3 s koncovými cestami.
Samotný exponent jedna proto NENÍ zde vydáván za první objev. Úplný důkaz
tohoto preprintu nebyl v této práci auditován. Přiložený text podává vlastní
důkaz, úspornou konstrukci koncových stromů a výše specifikovaný certifikát.

https://figshare.com/articles/preprint/Independent_Sets_on_Trees_Consecutive_Log-Concavity_Failures_and_an_Exact_Covariance_Threshold/33684715

Stav: výzkumný rukopis, 28. září 2026.
