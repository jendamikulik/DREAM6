#!/usr/bin/env python3
"""Computer-assisted proof component: binary branching, 14-vertex seed G_2.
Every integer h>=1024. Requires python-flint==0.9.0.
All proof decisions use exact rationals or Arb/Acb validated balls.
See subcubic_threshold.tex for the analytic and all-height implications.
"""
from fractions import Fraction as F
from pathlib import Path
import json, hashlib
import flint
from flint import arb, acb, ctx
ctx.prec=512
B,ORDER,DEPTH=2,32,24
T,H,H0=2048,1024,128
I=acb(0,1)
checks=[]
def check(name,condition):
 if not condition: raise AssertionError(name)
 checks.append(name)
def two(n): return F(2)**n
def ball(x):
 return arb(x.numerator)/x.denominator if isinstance(x,F) else arb(x)
def enclose(x,error):return x+arb(0,ball(error))
def seed_odds(lam):
 r=lam/(1+lam)
 for _ in range(2):r=lam*(1+r)**2/(lam+(1+r)**2)
 return r
def residual(r):return seed_odds(r*(1+r)**2)-r
lo,hi=F(24),F(25)
check('root_left_sign',residual(lo)>0)
check('root_right_sign',residual(hi)<0)
for _ in range(400):
 mid=(lo+hi)/2
 if residual(mid)>0:lo=mid
 else:hi=mid
check('root_bracket_final',residual(lo)>0 and residual(hi)<0)
r=enclose(ball((lo+hi)/2),(hi-lo)/2)
lam=r*(1+r)**2
q=r/(1+r);p=1-q;rho=2*q
check('lambda_bounds',lam>2**14 and lam<2**15)
check('q_bounds',q>ball(F(24,25)) and q<ball(F(25,26)))
check('rho_bounds',rho>ball(F(48,25)) and rho<2)
# Compute conditional seed means and variances via normalized deficiency.
def conv_int(a,b):
 c=[0]*(len(a)+len(b)-1)
 for i,x in enumerate(a):
  for j,y in enumerate(b):c[i+j]+=x*y
 return c
def add_int(a,b):return [(a[i] if i<len(a) else 0)+(b[i] if i<len(b) else 0) for i in range(max(len(a),len(b)))]
P0,P1=[1,1],[0,1]
for _ in range(2):
 S=conv_int(add_int(P0,P1),add_int(P0,P1))
 P0,P1=add_int(S,[0]+conv_int(P0,P0)),[0]+S
check('seed_degrees',len(P0)==8 and len(P1)==8)
def seed_moments(c):
 weights=[ball(c[7-j])*lam**(-j) for j in range(8)]
 Z=sum(weights);m=sum(j*w for j,w in enumerate(weights))/Z
 v=sum(j*j*w for j,w in enumerate(weights))/Z-m*m
 return 7-m,v
mu0,V0=seed_moments(P0);mu1,V1=seed_moments(P1)
D0=mu1-mu0;theta=1/(1+rho);a0=D0-theta
check('seed_gap',D0>0 and D0<ball(F(1,100)))
check('initial_scale',-a0>ball(F(1,4)) and -a0<1)
check('theta_ratio',theta/(-a0)<2)
check('seed_mean',mu0>6)
check('normalized_seed_variance0',V0/a0**2<1)
check('normalized_seed_variance1',V1/a0**2<1)
t=2/rho**2
v0=t*q*p/(1-t*p-q*t*t);v1=t*v0
check('fixed_variances',v0<ball(F(1,16)) and v1<ball(F(1,16)))
check('variance_proxy',t/(4*(1-t))<ball(F(1,3)))
check('w2_contraction',2/ball(F(48,25))**2<ball(F(9,16)))
check('w2_initial',F(1)+F(1,4)<2)
check('w2_series',2+1/(1-arb(2).sqrt()/2)<6)
check('cf_lipschitz_conditional',v0<ball(F(1,16)) and v1<ball(F(1,16)))
check('cf_lipschitz_mixture',p*v0+q*v1+p*q<ball(F(1,4)))
def convolution(a, b, n):
    c = [arb(0) for _ in range(n+1)]
    for i in range(min(len(a), n+1)):
        for j in range(min(len(b), n+1-i)):
            c[i+j] += a[i]*b[j]
    return c


def power(a, exponent, n):
    result = [arb(1)]+[arb(0)]*n
    while exponent:
        if exponent & 1:
            result = convolution(result, a, n)
        exponent //= 2
        if exponent:
            a = convolution(a, a, n)
    return result


# Exponential-moment coefficients E[(Y^s)^k]/k!, k=0,...,31.
# Coefficients k=1 vanish by centering. Each subsequent pair is obtained
# by solving the exact triangular fixed-point moment equations.
A, C = [arb(1), arb(0)], [arb(1), arb(0)]
for k in range(2, ORDER):
    A.append(arb(0))
    C.append(arb(0))
    e0, e1 = [arb(1)], [arb(1)]
    for j in range(1, k+1):
        e0.append(e0[-1]*(-q)/j)
        e1.append(e1[-1]*(1-q)/j)
    a, c = convolution(A, e0, k), convolution(C, e1, k)
    z = [(1-q)*x+q*y for x,y in zip(a,c)]
    R, S = power(z,2,k)[k], power(A,2,k)[k]
    s = (-1/rho)**k
    w = 2*s
    denominator = 1-w*(1-q)-w*w*q
    check(f"moment_denominator_{k}", denominator > ball(F(1,2)))
    A[k] = (s*R+w*q*s*S)/denominator
    C[k] = w*A[k]+s*S

# Subgaussian proxy <1/3 gives E exp(2|Y|)<4.
check('scaled_argument', F(T,1)/(F(48,25)**DEPTH)<F(1,1000))
epsilon=F(4,2000**ORDER)
check('taylor_error',2*2**DEPTH*epsilon<two(-300))
E=two(-300)

def polynomial(coefficients, z):
    value = acb(0)
    for c in reversed(coefficients):
        value = value*z+c
    return value


def conditional_approximants(t):
    """Entire approximants P_0,P_1; error <=2^-300 for real |t|<=2048."""
    u = t/((-rho)**DEPTH)
    a, c = polynomial(A,I*u), polynomial(C,I*u)
    for _ in range(DEPTH):
        next_a = ((1-q)*a*(-I*q*u).exp()+q*c*(I*(1-q)*u).exp())**2
        c, a = a**2, next_a
        u *= -rho
    return a, c


def mixture(t):
    a,c = conditional_approximants(t)
    return (1-q)*a*(-I*q*t).exp()+q*c*(I*(1-q)*t).exp()


# Entire annulus [64,128], cells of width 1/4; last-layer padding.
max_bound=arb(0)
for j in range(256):
 center=F(64)+F(2*j+1,8)
 u=-ball(center)/rho
 a,c=conditional_approximants(acb(u))
 z=p*a*(-I*q*u).exp()+q*c*(I*p*u).exp()
 b0=(abs(z)+ball(E)+ball(F(1,2)*F(1,8)/F(48,25)))**2
 b1=(abs(a)+ball(E)+ball(F(1,4)*F(1,8)/F(48,25)))**2
 check(f'annulus_cell_{j}',b0<ball(F(1,8)) and b1<ball(F(1,8)))
 upper=max(b0.upper(),b1.upper())
 if upper>max_bound:max_bound=upper
print('PASS: 256 complete annulus cells',flush=True)
check('finite_annulus',F(1,8)+6*128*F(3,4)**H0<F(1,4))
# Tail after T=2048 begins inside shell n>=5, since 64 rho^5<2048.
U=F(1,4)
tails=[two(12*(j+1)+1-64) for j in range(4)]
for j in range(4):
 check(f'annular_ratio_{j}',2**(j+1)*U**32<F(1,2))
 check(f'global_derivative_{j}',F(T**(j+1),3*(j+1))+tails[j]<2**(11*(j+1)))
check('physical_cutoff',T<ball(F(1,4))*ball(F(48,25))**H0)
# Each conditional law has adjacent atoms >=(1+lambda)^-14 >2^-224.
check('adjacent_atom_activity',1+lam<2**16)
# |a_H0|<2^128, cutoff 64/|a_H0|>2^-122.
# Q_0(v)<=exp(-2^-452 v^2); hence high-frequency exp(-2^(h-696)).
check('high_frequency_base',2**(H-696)>4*H+400)
check('high_frequency_step',2**(H-696)>4)
x0=F(-2,5);integrals=[]
for j in range(3):
 total=acb(0)
 def integrand(u,analytic):return (-I*u)**j*mixture(u)*(-I*ball(x0)*u).exp()
 for start in range(0,T,16):
  z=acb.integral(integrand,start,start+16,abs_tol=arb(2)**-80,rel_tol=arb(2)**-80,eval_limit=100000)
  check(f'integral_{j}_{start}',z.is_finite())
  total+=z
 integrals.append(total.real/arb.pi())
 print(f'PASS: integral {j}: {integrals[-1]}',flush=True)
density=[enclose(integrals[j],E*T**(j+1)+tails[j]) for j in range(3)]
targets=[(F(45,1000),F(46,1000)),(F(-88,1000),F(-86,1000)),(F(249,10),F(25))]
for j,(lo_,hi_) in enumerate(targets):check(f'density_{j}',density[j]>ball(lo_) and density[j]<ball(hi_))
R=[two(-49),two(-37),two(-25)]
for j in range(3):
 error=7*F(3,4)**H*T**(j+2)+2*tails[j]+two(-390)
 check(f'C2_error_{j}',error<R[j])
radius=two(-80)
check('point_W',F(45,1000)*F(249,10)-F(88,1000)**2>1)
check('interval_W',1-two(56)*radius>F(99,100))
check('interval_f_lower',F(45,1000)-two(22)*radius>F(44,1000))
check('interval_f_upper',F(46,1000)+two(22)*radius<F(47,1000))
check('interval_fp',F(88,1000)+two(33)*radius<F(9,100))
check('interval_fpp',25+two(44)*radius<26)
check('finite_f_lower',F(44,1000)-R[0]>F(43,1000))
check('finite_f_upper',F(47,1000)+R[0]<F(48,1000))
check('finite_fpp',26+R[2]<27)
check('finite_fp_sum',2*F(9,100)+R[1]<F(1,5))
check('finite_W',F(99,100)-27*R[0]-F(47,1000)*R[2]-F(1,5)*R[1]>F(98,100))
check('curvature',F(98,100)/F(48,1000)**2>400)
check('lattice_count',two(-82)*F(48,25)**H>=4)
check('interval_location',-1<x0-radius<x0+radius<1)
check('bulk_upper',F(15,2)+4*F(25,26)**H<F(99,100)*(F(23,3)-two(-H)))
check('bulk_lower',6-F(25,26)**H>0)
check('exponent',F(48,25)**50>2**47)
# General seed and small-p valley algebra: simple rational witnesses.
check('general_variance_denominator',1-F(1,2)*F(100,99)**2*F(1,100)-F(1,4)*F(100,99)**4>F(7,10))
check('general_variance_ratio',F(1,2)*F(100,99)**2<F(7,10))
check('valley_left',1-F(16,2048)>F(1,2))
check('valley_right',F(2047,2048)*(1-F(16,2048))>F(1,2))
check('valley_strict',F(256,2048)<F(1,4))
report={
 'status':'PASS','scope':'G_2 seed (14 vertices), binary branching, every integer h>=1024',
 'maximum_degree':3,'height':H,'finite_annulus_height':H0,
 'precision_bits':ctx.prec,'python_flint_version':flint.__version__,
 'r':str(r),'lambda':str(lam),'q':str(q),'rho':str(rho),'a0':str(a0),
 'seed_root0_coefficients':P0,'seed_root1_coefficients':P1,
 'root_bracket':[str(lo),str(hi)],
 'annulus':[64,128],'annulus_cells':256,'annulus_max_upper':str(max_bound),
 'annulus_limit_bound':'1/8','annulus_finite_bound':'1/4','integration_cutoff':T,
 'CF_approximation_error':'2^-300','derivative_enclosures':[str(x) for x in density],
 'C2_errors':['2^-49','2^-37','2^-25'],'x0':'-2/5','radius':'2^-80',
 'curvature_lower':400,'run_bound':'|I_h| >= 2^-82 rho^h >= 2^-86 N_h^(47/50)',
 'bulk_location':'0 < k < (99/100) alpha_h',
 'checks_passed':len(checks),'checks':checks,
 'scope_limit':'Computer-assisted component of the accompanying written proof, not a proof-assistant formalization. The general near-linear theorem is analytically proved, with seed-dependent constants.',
 'verifier_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
Path(__file__).with_name('subcubic_certificate.json').write_text(json.dumps(report,indent=2)+'\n')
print(f'PASS: {len(checks)} checks, h>=1024, degree 3, exponent 47/50',flush=True)
