# A universal sublinear ceiling for consecutive failures

For every fixed maximum degree Delta >= 3, the maximum consecutive run
length in forest independence polynomials is o(N). The proof gives

    M_Delta(N) < 6 N / log_2(log_(Delta-1)(N))

for every N >= (Delta-1)^(2^14), where M maximizes over forests with
at most N vertices. For degree 65 this starting order is 2^98304.

A more useful parameterized finite threshold is:

    Lambda = 4^m
    K = ceil(log_2(12 m^2))
    R = (Lambda + 1) K
    N >= 36 m^3 (Delta - 1)^R  ==>  M_Delta(N) < N/m.

All these are closed formulas. The paper also proves an explicit
polynomial saving for a run whose midpoint stays a fixed proportion
below the independence number.

## Reproduce

```sh
python verify_sublinear_ceiling.py
```

Python 3.10 or newer; standard library only. No floating-point decisions.
The program regenerates `sublinear_ceiling_certificate.json`.

The universal algebraic check is the quartic positive dual identity
in Section 2. The program checks it as a polynomial in indeterminates,
not by sampling window lengths. It also checks induction witnesses
for the explicit threshold envelope. A separate finite audit enumerates
small forests to check the covariance formula independently.

Execution result: 18 universal algebra/constant checks; 1,364 ordered
covariance pairs audited exactly; 5,245 checks in total.

## Scope

The certificate verifies the algebraic parts and finite audits. Universal
probabilistic and entropy arguments are supplied by the complete written
proof; this is not a proof-assistant formalization or an exhaustive
enumeration of all forests.

The upper bound is independent of the earlier construction. Combining
it with `fixed_degree_nearlinear.tex` gives both

    log M_65^tree(N) / log N -> 1
    M_65^tree(N) / N -> 0.

The present package contains the new upper-bound proof, not the earlier
companion proof of the lower bound. No sharp asymptotic subpolynomial
factor, publication priority, or independent peer review is claimed.
