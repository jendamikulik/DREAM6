#!/usr/bin/env python3
"""Exact algebra certificate and independent finite audit.

Run with Python 3.10+: python verify_sublinear_ceiling.py
Standard library only. No floating-point inequality is used.

The polynomial checks are identities in Q[d,k,m,x,y,z], not samples.
The finite graph audit checks the probability identities independently by
enumeration; it is not an enumeration of all forests. The companion proof
supplies the probabilistic arguments and their universal quantifiers.
"""
from fractions import Fraction as F
from collections import deque
from pathlib import Path
import hashlib
import json

NAMES = ('d', 'k', 'm', 'x', 'y', 'z')
ZERO = (0,) * len(NAMES)
checks = []


class P:
    """Small exact multivariate polynomial ring, stored as sparse dicts."""
    def __init__(self, value=0):
        if isinstance(value, P):
            self.a = value.a.copy()
        elif isinstance(value, dict):
            self.a = {e: F(c) for e, c in value.items() if c}
        else:
            self.a = {ZERO: F(value)} if value else {}

    def __add__(self, other):
        out = self.a.copy()
        for e, c in P(other).a.items():
            out[e] = out.get(e, F(0)) + c
        return P(out)

    __radd__ = __add__

    def __neg__(self):
        return P({e: -c for e, c in self.a.items()})

    def __sub__(self, other):
        return self + (-P(other))

    def __rsub__(self, other):
        return P(other) - self

    def __mul__(self, other):
        out = {}
        for a, x in self.a.items():
            for b, y in P(other).a.items():
                e = tuple(u + v for u, v in zip(a, b))
                out[e] = out.get(e, F(0)) + x*y
        return P(out)

    __rmul__ = __mul__

    def __pow__(self, n):
        assert isinstance(n, int) and n >= 0
        out, base = P(1), self
        while n:
            if n & 1:
                out = out*base
            base = base*base
            n //= 2
        return out

    def sub(self, name, value):
        index = NAMES.index(name)
        out = P()
        for e, c in self.a.items():
            remainder = list(e)
            remainder[index] = 0
            out += P({tuple(remainder): c}) * P(value)**e[index]
        return out

    def __eq__(self, other):
        return self.a == P(other).a


def variable(name):
    e = list(ZERO)
    e[NAMES.index(name)] = 1
    return P({tuple(e): 1})


def check(name, condition):
    if not condition:
        raise AssertionError(name)
    checks.append(name)


d, k, m, x, y, z = map(variable, NAMES)
C = k*(k+1)*(d-k)*(d-k+1)
w12 = 12*k*k - 12*d*k + 2*d*(d-1)
check('quartic_dual_interior_identity', C.sub('k', k-1)-2*C+C.sub('k', k+1) == w12)
check('quartic_dual_left_boundary', C.sub('k', 1) == w12.sub('k', 0))
check('quartic_dual_right_boundary', C.sub('k', d-1) == w12.sub('k', d))
check('quartic_dual_zero_boundaries', C.sub('k', 0) == 0 and C.sub('k', d) == 0)
check('logconvex_implies_convex_identity', (x+z)**2-4*y*y == (x-z)**2+4*(x*z-y*y))
check('outside_variance_margin', (d+2)**2*F(1,4)-d*(d+2)*F(1,12) == (d+2)*(d+3)*F(1,6))

# Universal induction witnesses, each with nonnegative coefficients after
# the substitution m=x+1 (x>=0).
positive_polynomials = {
    'K_m_induction': (16*m*m-(m+1)**2).sub('m', x+1),
    'm_le_two_to_m_induction': (2*m-(m+1)).sub('m', x+1),
    'threshold_exponent_induction': (8*(6+3*m)-(6+3*(m+1))).sub('m', x+1),
}
for name, polynomial in positive_polynomials.items():
    check(name, bool(polynomial.a) and all(c >= 0 for c in polynomial.a.values()))
check('K_m_base', 12 <= 2**4)
check('m_le_two_to_m_base', 1 <= 2)
check('threshold_prefactor', 36 <= 2**6)
check('threshold_exponent_base', 6+3 <= 2**6)
check('variance_contradiction', F(1,48)+F(1,48) == F(1,24) < F(1,12))
check('loglog_floor_margin', ((x-7)*F(1,3)-x*F(1,6)).sub('x', y+14) == y*F(1,6))
# Ball bound: b>=2, u=b^R>=1.
ball_margin = 3*x*(d-1)-((d-1)+(d+1)*(x-1))
check('ball_count_identity', ball_margin == (2*d-4)*x+2)
check('ball_count_positivity', all(c >= 0 for c in ball_margin.sub('d', y+2).sub('x', z+1).a.values()))
check('universal_degree65_start_exponent', 6*2**14 == 98304)
symbolic_count = len(checks)

thresholds = []
for mm in (1, 2, 4, 8, 16, 32, 64):
    lam = 4**mm
    kk = (12*mm*mm-1).bit_length()  # ceil(log2(12m^2)) exactly
    rr = (lam+1)*kk
    check(f'threshold_{mm}_dyadic_padding', 2**kk >= 12*mm*mm)
    check(f'threshold_{mm}_binomial_witness', 1+F(lam+1,lam) > 2)
    check(f'threshold_{mm}_K_bound', kk <= 4*mm)
    check(f'threshold_{mm}_R_bound', rr <= 2**(3*mm+3))
    check(f'threshold_{mm}_total_exponent', rr+6+3*mm <= 2**(3*mm+4))
    thresholds.append({
        'm': mm, 'Lambda': str(lam), 'K': kk, 'R': str(rr),
        'n_threshold_exact_order': f'{36*mm**2} * (Delta-1)^{rr}',
        'N_threshold_order_at_most': f'{36*mm**3} * (Delta-1)^{rr}',
        'conclusion': 'M_Delta(N) < N/m',
    })


def distances(n, edges, root):
    adj = [[] for _ in range(n)]
    for u, v in edges:
        adj[u].append(v)
        adj[v].append(u)
    parent, dist = [None]*n, [None]*n
    dist[root] = 0
    queue = deque([root])
    while queue:
        u = queue.popleft()
        for v in adj[u]:
            if dist[v] is None:
                dist[v], parent[v] = dist[u]+1, u
                queue.append(v)
    return parent, dist


graphs = [
    ('path8', 8, [(j,j+1) for j in range(7)]),
    ('star8', 8, [(0,j) for j in range(1,8)]),
    ('binary7', 7, [((j-1)//2,j) for j in range(1,7)]),
    ('broom10', 10, [(j,j+1) for j in range(5)]+[(5,j) for j in range(6,10)]),
    ('forest8', 8, [(0,1),(1,2),(3,4),(3,5)]),
]
audited_pairs = 0
for name, n, edges in graphs:
    masks = [v for v in range(1 << n) if not any((v >> a & 1) and (v >> b & 1) for a,b in edges)]
    degrees = [sum(v in e for e in edges) for v in range(n)]
    branching = max(2,max(degrees)-1)
    for lam in (F(1,7), F(1), F(7), F(64)):
        weights = [lam**mask.bit_count() for mask in masks]
        total = sum(weights)
        probabilities = [w/total for w in weights]
        marginals = [sum(p for mask,p in zip(masks,probabilities) if mask>>v&1) for v in range(n)]
        mean = sum(F(mask.bit_count())*p for mask,p in zip(masks,probabilities))
        variance = sum((F(mask.bit_count())-mean)**2*p for mask,p in zip(masks,probabilities))
        qmax = lam/(1+lam)
        for u in range(n):
            parent, distance = distances(n,edges,u)
            for v in range(n):
                joint = sum(p for mask,p in zip(masks,probabilities) if mask>>u&1 and mask>>v&1)
                actual = joint-marginals[u]*marginals[v]
                if distance[v] is None:
                    predicted = F(0)
                else:
                    predicted = marginals[u]*(1-marginals[u])*(-1)**distance[v]
                    w = v
                    while w != u:
                        par = parent[w]
                        cavity = marginals[w]/(1-marginals[par])
                        check(f'cavity_{name}_{lam}_{u}_{v}_{w}', cavity <= qmax)
                        predicted *= cavity
                        w = par
                    check(f'decay_{name}_{lam}_{u}_{v}', abs(actual) <= F(1,4)*qmax**distance[v])
                check(f'covariance_{name}_{lam}_{u}_{v}', actual == predicted)
                audited_pairs += 1
        for rr in range(4):
            check(f'variance_{name}_{lam}_{rr}', variance <= F(3*n*branching**rr,4)+F(n*n,4)*qmax**rr)

report = {
    'status':'PASS',
    'arithmetic':'Exact rational numbers and symbolic polynomial identities; Python standard library only',
    'universal_symbolic_checks':symbolic_count,
    'exact_enumeration_graph_activity_cases':len(graphs)*4,
    'exact_enumeration_ordered_pairs':audited_pairs,
    'checks_passed':len(checks),
    'symbolic_checks':checks[:symbolic_count],
    'thresholds':thresholds,
    'dual_coefficient':'k(k+1)(d-k)(d-k+1)/12',
    'universal_upper_bound':'M_Delta(N) < 6 N / log_2(log_(Delta-1)(N)) for N >= (Delta-1)^(2^14)',
    'degree65_threshold':'N >= 2^98304',
    'scope':'Symbolic identities hold for all parameter values. Enumeration is a finite independent audit. Universal probability, entropy, positivity and induction arguments are written in sublinear_ceiling.tex; this is not a proof-assistant formalization.',
    'verifier_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
}
out = Path(__file__).with_name('sublinear_ceiling_certificate.json')
out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(f'PASS: {symbolic_count} universal algebra/constant checks; {audited_pairs} exactly audited covariance pairs; {len(checks)} checks total.')
print('Certificate:',out.name)
